﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using IFS.BusinessLayer;
using IFS.BusinessLayer.OrderManagementSystem;
using IFS.Interfaces.Common;
using IFS.Interfaces.Common.Enums;
using IFS.Interfaces.Rounding;
using Microsoft.Security.Application;


public partial class pages_popups_TradeOrderHistoryPopup : CBasePage
{

    private BaseTradeOrder _clientTradeOrder;
    private const string KEY = "ALL_TRADESTATUSES";

    public int TradeOrderID
    {
        get
        {
            string sTradeOrderID = Request.Params["tradeOrderID"];
            if (string.IsNullOrEmpty(sTradeOrderID))
                sTradeOrderID = "-1";
            return int.Parse(sTradeOrderID);
        }
    }

    private BaseTradeOrder ClientTradeOrder
    {
        get
        {
            if (_clientTradeOrder == null && TradeOrderID > 0)
                _clientTradeOrder = TradeOrderHelper.GetTradeOrderFromPorfolio(null, TradeOrderID);
            return _clientTradeOrder;
        }
        set { _clientTradeOrder = value; }
    }

    private int TradeOrderInvestmentId { get; set; }
    private InvestableFund TradeOrderInvestableFund { get; set; }


    protected void Page_Load(object sender, EventArgs e)
    {
        var dtTradeOrderHistory = TradeOrderHelper.GetTradeOrderHistory(ClientTradeOrder);

        InitializeTradeOrderInvestableFund(dtTradeOrderHistory);

        bgvTradeHistory.DataSource = dtTradeOrderHistory;
        bgvTradeHistory.DataBind();

        if (bgvTradeHistory.HeaderRow != null)
        {
            bgvTradeHistory.HeaderRow.Style.Add("top", "expression(this.offsetParent.scrollTop)");
            bgvTradeHistory.HeaderRow.Style.Add("position", "relative");
        }
    }

    private void InitializeTradeOrderInvestableFund(DataSet tradeOrderHistory)
    {
        var historyRows = tradeOrderHistory.Tables[0].Rows;

        if (historyRows.Count == 0)
            return;

        var investmentId = int.Parse((string)historyRows[historyRows.Count - 1]["TradeInvestmentId"]);

        foreach (var p in CSession.Portfolios)
        {
            var tradeOrderInvestment = p.Investments.Find(inv => inv.InvestmentID == investmentId) ?? p.BasefundInvestments.Find(inv => inv.InvestmentID == investmentId);
          
            if (tradeOrderInvestment != null)
            {
                TradeOrderInvestmentId = investmentId;
                TradeOrderInvestableFund = InvestableFund.Loader.GetById(tradeOrderInvestment.FundID);
                return;
            }
        }
    }

    // If some class/series is assigned to trade order, base fund investment is already deleted and we have to take BaseFundName here.
    private bool IsBaseFundHistoryRecord(int investmentId)
    {
        return (TradeOrderInvestmentId != investmentId);
    }

    protected void bgvTradeHistory_OnRowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
            ProcessRow(e.Row);
    }

    private void ProcessRow(GridViewRow row)
    {
        Literal litSecurity = (Literal)row.FindControl("litSecurity");
        Literal litClearer = (Literal)row.FindControl("litClearer");
        Literal litStatus = (Literal)row.FindControl("litStatus");
        Literal litEnteredBy = (Literal)row.FindControl("litEnteredBy");
        Literal litUpdatedBy = (Literal)row.FindControl("litUpdatedBy");
        Literal litUpdatedDate = (Literal)row.FindControl("litUpdatedDate");
        Literal litUserAction = (Literal)row.FindControl("litUserAction");
        Literal litTradeEnteredAs = (Literal)row.FindControl("litTradeEnteredAs");

        Literal litTradeDate = (Literal)row.FindControl("litTradeDate");
        Literal litTradeDateReceived = (Literal)row.FindControl("litTradeDateReceived");
        Literal litTradePaymentDate = (Literal)row.FindControl("litTradePaymentDate");
        Literal litTradeDueDate = (Literal)row.FindControl("litTradeDueDate");

        Literal litTradePctage = (Literal)row.FindControl("litTradePctage");
        Literal litAmount = (Literal)row.FindControl("litAmount");
        Literal litQuantity = (Literal)row.FindControl("litQuantity");

        DateTime updatedDate = DateTime.MinValue;
        var userAction = DataBinder.Eval(row.DataItem, "UserAction").ToString();
        var approvalAction = DataBinder.Eval(row.DataItem, "TradeApprovalAction").ToString();
        litUserAction.Text = string.IsNullOrEmpty(approvalAction) || approvalAction =="NULL" ? userAction : approvalAction;

        DateTime.TryParse(DataBinder.Eval(row.DataItem, "TradeLastModifiedDate").ToString(), out updatedDate);
        //DateTime.TryParse(DataBinder.Eval(row.DataItem, "TradeDate").ToString(), out tradeDate);
      
        if (TradeOrderInvestableFund != null)
        {
            var investmentId = int.Parse(DataBinder.Eval(row.DataItem, "TradeInvestmentId").ToString());
            var securityName = IsBaseFundHistoryRecord(investmentId)
                                   ? InvestableFund.Loader.GetById(TradeOrderInvestableFund.BasefundId).FullName
                                   : TradeOrderInvestableFund.FullName;
            litSecurity.Text = Encoder.HtmlEncode(securityName);
        }

        litStatus.Text = DataBinder.Eval(row.DataItem, "CurrentState").ToString();
        litEnteredBy.Text = Encoder.HtmlEncode(IFS.BusinessLayer.User.Loader.GetById(int.Parse(DataBinder.Eval(row.DataItem, "TradeUserID").ToString())).UserFullName);
        litUpdatedBy.Text = Encoder.HtmlEncode(IFS.BusinessLayer.User.Loader.GetById(int.Parse(DataBinder.Eval(row.DataItem, "TradeLastModifiedUserID").ToString())).UserFullName);
        litClearer.Text = Encoder.HtmlEncode(EnumValue.GetEnumValueName(int.Parse(DataBinder.Eval(row.DataItem, "TradeClearerID").ToString())));
        litUpdatedDate.Text = updatedDate == DateTime.MinValue ? string.Empty : updatedDate.ToString();
        //Entered As
        AllocationEnteredAs enteredAs;
        enteredAs = (AllocationEnteredAs)int.Parse(DataBinder.Eval(row.DataItem, "TradeEnteredAs").ToString());
        litTradeEnteredAs.Text = Enum.GetName(typeof (AllocationEnteredAs), enteredAs);
        //Dates
        DateTime tradeDate = DateTime.MinValue;
        DateTime tradeDateReceived = DateTime.MinValue;
        DateTime tradePaymentDate = DateTime.MinValue;
        DateTime tradeMoneyMoveDate = DateTime.MinValue;
        DateTime tradeDueDate = DateTime.MinValue;

        DateTime.TryParse(DataBinder.Eval(row.DataItem, "TradeDate").ToString(), out tradeDate);
        DateTime.TryParse(DataBinder.Eval(row.DataItem, "TradeDateReceived").ToString(), out tradeDateReceived);
        DateTime.TryParse(DataBinder.Eval(row.DataItem, "TradePaymentDate").ToString(), out tradePaymentDate);
        DateTime.TryParse(DataBinder.Eval(row.DataItem, "MoneyMoveDate").ToString(), out tradeMoneyMoveDate);
        DateTime.TryParse(DataBinder.Eval(row.DataItem, "TradeDueDate").ToString(), out tradeDueDate);

        litTradeDate.Text = tradeDate == DateTime.MinValue ? string.Empty : tradeDate.ToShortDateString();
        litTradeDateReceived.Text = tradeDateReceived == DateTime.MinValue ? string.Empty : tradeDateReceived.ToShortDateString();
        litTradePaymentDate.Text = tradePaymentDate == DateTime.MinValue ? 
            tradeMoneyMoveDate == DateTime.MinValue? string.Empty : tradeMoneyMoveDate.ToShortDateString()
            : tradePaymentDate.ToShortDateString();

        litTradeDueDate.Text = tradeDueDate == DateTime.MinValue ? string.Empty : tradeDueDate.ToShortDateString();

        //Amount/ qty/ pct
        double tradePct;//double.Parse(DataBinder.Eval(row.DataItem, "TradePctage").ToString());
        CQuantity quantity;
        CAmount amount;
        CQuantity.TryParse(DataBinder.Eval(row.DataItem, "TradeQuantity").ToString(), out quantity);
        CAmount.TryParse(DataBinder.Eval(row.DataItem, "TradeAmount").ToString(), out amount);
        double.TryParse(DataBinder.Eval(row.DataItem, "TradePercentage").ToString(), out tradePct);
        
        litTradePctage.Text = double.IsNaN(tradePct) ? string.Empty : tradePct + "%";
        litAmount.Text = CAmount.IsNaN(amount) ? string.Empty : amount.ToString(CAmount.FORMAT_STRING);
        litQuantity.Text = CQuantity.IsNaN(quantity) ? string.Empty : quantity.ToString(CQuantity.FORMAT_STRING);
        
    }
    
}
