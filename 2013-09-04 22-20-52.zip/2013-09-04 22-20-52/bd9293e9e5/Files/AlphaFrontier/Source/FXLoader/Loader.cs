using System;
using System.Configuration;
using Common.Logging;
using IFS.BusinessLayer.CloudServices;
using IFS.BusinessLayer.Utilities;
using IFS.Interfaces.CloudContracts;
using IFS.Interfaces.CloudContracts.DataContracts;

namespace FXLoader
{
    class Loader
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(IFS.BusinessLayer.FxRates.FXLoader));

        #region Main
        static void Main(string[] args)
        {
            try
            {
                var parameters = InitializeParameters(args);
                var loader = GetService();
                var result = loader.LoadRates(parameters);
                if (result.Failed)
                    _log.Error(result.InnerException);
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                _log.Error(ex);
                Environment.Exit(1);
            }
        }

        private static FXLoaderParameters InitializeParameters(string[] args)
        {
            var parameters = new FXLoaderParameters();
            int daysToAdd = 0;
            if (args.Length > 0)
            {
                daysToAdd = int.Parse(args[0]);
            }
            bool useCloud = false;
            if (args.Length > 1)
            {
                useCloud = args[1] == "useCloud";
            }
            parameters.Date = DateTime.Today.AddDays(daysToAdd);
            parameters.UseCloud = useCloud;
            if (useCloud)
            {
                parameters.CloudServiceUrl = ConfigurationManager.AppSettings["cloudSericeUrl"];
                parameters.Resource = ConfigurationManager.AppSettings["cloudResource"];
                parameters.UserName = ConfigurationManager.AppSettings["cloudUserName"];
            }
            else
            {
                parameters.ClosePriceUrl = ConfigurationManager.AppSettings["closePriceSericeUri"];
                parameters.SpotPriceUrl = ConfigurationManager.AppSettings["spotPriceSericeUri"];
                parameters.Resource = ConfigurationManager.AppSettings["modsResource"];
                parameters.UserName = ConfigurationManager.AppSettings["modsUserName"];
            }

            return parameters;
        }

        private static IFXLoaderService GetService()
        {
            return SpringUtil.GetObject<IFXLoaderService>(ServiceNames.FXLOADER_SERVICE_SPRING_NAME);
        }
        #endregion
    }
}