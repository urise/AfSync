namespace IFS.BusinessLayer.CloudServices
{
    public static class ServiceNames
    {
        public const string CACHE_SERVICE_SPRING_NAME = "cacheService";
        public const string COMMON_SERVICE_SPRING_NAME = "commonService";
        public const string DASHBOARD_SERVICE_SPRING_NAME = "dashboardService";
        public const string REPORT_TRANSACTIONS_SERVICE_SPRING_NAME = "reportTransactionsService";
        public const string HISTORICAL_TRANSACTIONS_REPORT_SERVICE_SPRING_NAME = "historicalTransactionsReport";
        public const string REPORT_SIDE_POCKETS_SERVICE_SPRING_NAME = "reportSidePocketsService";
        public const string REPORT_FUND_OF_FUNDS_SERVICE_SPRING_NAME = "reportFundOfFundsService";
        public const string REPORT_CUSTODY_SERVICE_SPRING_NAME = "reportCustodyService";
        public const string REPORT_IA_AND_FOF_SERVICE_SPRING_NAME = "reportIaAndFofService";
        public const string REPORT_CASH_PROJECTION_SERVICE_SPRING_NAME = "reportCashProjectionService";
        public const string REPORT_QUOTES_SERVICE_SPRING_NAME = "reportQuotesService";
        public const string REPORT_HOLDINGS_SERVICE_SPRING_NAME = "reportHoldingsService";
        public const string CLOUD_INNER_REPORT_HOLDINGS_SERVICE_SPRING_NAME = "CloudInnerReportHoldingsService";
        public const string REPORT_LIQUIDITY_SERVICE_SPRING_NAME = "reportLiquidityService";
        public const string REPORT_INVESTMENT_ANALYSIS_SERVICE_SPRING_NAME = "reportInvestmentAnalysisService";
        public const string PRICING_COMPARISON_REPORT_SERVICE_SPRING_NAME = "reportPricingComparisonService";
        public const string REPORT_HISTORICAL_RETURNS_SERVICE_SPRING_NAME = "reportHistoricalReturnsService";
        public const string REPORT_MV_COMPARISON_SERVICE_SPRING_NAME = "reportMvComparisonService";
        public const string REPORT_PRICE_VARIANCE_SERVICE_SPRING_NAME = "reportPriceVarianceService";
        public const string REPORT_PRICING_HISTORY_SERVICE_SPRING_NAME = "reportPricingHistoryService";
        public const string REPORT_PRICE_VARIANCE_LOCKED_DOWN_SERVICE_SPRING_NAME = "reportPriceVarianceLockedDownService";
        public const string REPORT_GSM_OFFER_PRICE_CHANGE_SPRING_NAME = "reportGsmOfferPriceChangeService";
        public const string REPORT_CONTACTS_SERVICE_SPRING_NAME = "reportContactsService";
        public const string REPORT_GLOBAL_CONTACTS_SERVICE_SPRING_NAME = "reportGlobalContactsService";
        public const string REPORT_CORPORATE_ACTION_TRACKER_SPRING_NAME = "reportCorporateActionTrackerService";
        public const string REPORT_CORPORATE_ACTION_TRACKER_SCHEDULED = "reportCorporateActionTrackerScheduledService";
        public const string REPORT_QUARTERLY_SERVICE_SPRING_NAME = "reportQuarterlyService";
        public const string CLOUD_INNER_REPORT_QUARTERLY_SERVICE_SPRING_NAME = "CloudInnerReportQuarterlyService";
        public const string REPORT_PVT_EQTY_CONTROL_SPRING_NAME = "reportPvtEqtyControlService";
        public const string REPORT_BENCHMARK_PERFORMANCE_SERVICE_SPRING_NAME = "reportBenchmarkPerformanceService";
        public const string REPORT_CREDIT_SERVICE_SPRING_NAME = "reportCreditService";
        public const string REPORT_CP_EXCEPTION_SPRING_NAME = "reportCpExceptionService";
        public const string REPORT_HOMEPAGE_SPRING_NAME = "reportHomepageService";
        public const string TRADE_HEDGE_FUND_SPRING_NAME = "tradeHedgeFundService";
        public const string TRADE_PVT_EQTY_FUND_SPRING_NAME = "tradePvtEqtyFundService";
        public const string TRADE_CASH_DISTRIBUTION_SPRING_NAME = "tradeCashDistributionService";
        public const string REPORT_GSM_CP_EXCEPTION_SPRING_NAME = "reportGsmCpExceptionService";
        public const string REPORT_MERGED_ESTIMATES = "reportMergedEstimateRecReport";
        public const string REPORT_MERGED_FINALS = "reportMergedFinalRecReport";
        public const string REPORT_CLIENT_SPECIFIC_SECURITY = "reportClientSpecificSecurityService";
        public const string REPORT_HOLDINGS_HELPER = "reportHoldingsHelperService";
        public const string CLOUD_INNER_REPORT_MERGED_FINALS = "CloudInnerReportMergedFinalRecReport";
        public const string CLOUD_INNER_REPORT_GSM_CP_EXCEPTION_SERVICE_SPRING_NAME = "CloudInnerReportGsmCpExceptionService";
        public const string REPORT_TRADE_BLOTTER = "reportTradeBlotterService";
        public static string SUBSCRIPTION_SERVICE_SPRING_NAME = "subscriptionService";
        public static string REDEMPTION_SERVICE_SPRING_NAME = "redemptionService";
        public static string WEBFOLIO_SERVICE_SPRING_NAME = "webfolioService";
        public static string WEBFOLIO_TRADE_UPLOAD_SERVICE_SPRING_NAME = "webfolioTradeUploadService";
        public static string WEBFOLIO_TRADE_DOWNLOAD_SERVICE_SPRING_NAME = "webfolioTradeDownloadService";
        public static string PVT_EQUITY_SUBSCRIPTION_SERVICE_SPRING_NAME = "pvtEquitySubscriptionService";
        public static string FEES_AND_TERMS_BULK_SERVICE_SPRING_NAME = "feesAndTermsBulkService";
        public static string REPORT_SERVICE_DETAILS_NIGHTLY = "reportServiceDetailsNightly";
        public static string REPORT_PRICE_ENTRY_DETAILS = "reportPriceEntryDetailsService";
        public static string REPORT_BENCHMARK_FILES_UPLOAD = "reportBenchmarkFilesUpload";
        public static string FXLOADER_SERVICE_SPRING_NAME = "fXLoaderService";
    }
}
