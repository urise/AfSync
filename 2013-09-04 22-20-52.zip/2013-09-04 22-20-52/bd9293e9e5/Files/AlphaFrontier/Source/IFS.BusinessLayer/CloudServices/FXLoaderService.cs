﻿using System;
using IFS.Interfaces.CloudContracts;
using IFS.Interfaces.CloudContracts.DataContracts;

namespace IFS.BusinessLayer.CloudServices
{
    public class FXLoaderService : CloudServiceBase, IFXLoaderService
    {
        public FabricRequestResult LoadRates(FXLoaderParameters parameters)
        {
            return Execute(null, () =>
                                     {
                                         var result = new FabricRequestResult();
                                         try
                                         {
                                             var loader = new FxRates.FXLoader();
                                             loader.LoadRates(parameters);
                                         }
                                         catch (Exception ex)
                                         {
                                             result.InnerException = ex;
                                         }

                                         return result;
                                     });
        }
    }
}