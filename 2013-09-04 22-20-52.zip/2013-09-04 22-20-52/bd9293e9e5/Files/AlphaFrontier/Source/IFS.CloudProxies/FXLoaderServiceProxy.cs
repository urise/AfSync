﻿using IFS.Interfaces.CloudContracts;
using IFS.Interfaces.CloudContracts.DataContracts;

namespace IFS.CloudProxies
{
    public class FXLoaderServiceProxy : CloudProxyBase, IFXLoaderService
    {
        private const string LOAD_RATES_FLOW = "FXLoaderService_LoadRates";

        public FabricRequestResult LoadRates(FXLoaderParameters parameters)
        {
            return Execute<FabricRequestResult>(parameters, null, LOAD_RATES_FLOW);
        }
    }
}
