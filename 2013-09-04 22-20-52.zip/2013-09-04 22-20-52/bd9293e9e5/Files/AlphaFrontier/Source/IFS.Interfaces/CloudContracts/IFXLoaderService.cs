﻿using IFS.Interfaces.CloudContracts.DataContracts;

namespace IFS.Interfaces.CloudContracts
{
    public interface IFXLoaderService
    {
        FabricRequestResult LoadRates(FXLoaderParameters parameters);
    }
}