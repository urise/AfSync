﻿using System;

namespace IFS.Interfaces.Common
{
    [Serializable]
    public class FeesAndTermsErrorItem
    {
        public string CsvLine { get; set; }
        public string ErrorText { get; set; }
    }
}
