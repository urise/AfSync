﻿using System;
using System.Collections.Generic;
using IFS.Interfaces.Common;

namespace IFS.Interfaces.CloudContracts.DataContracts.FeesAndTermsBulk
{
    [Serializable]
    public class FeesAndTermsUploadResult : FabricRequestResult
    {
        public List<FeesAndTermsErrorItem> ErrorItems { get; set; }

        public FeesAndTermsUploadResult()
        {
            ErrorItems = new List<FeesAndTermsErrorItem>();
        }
    }
}
