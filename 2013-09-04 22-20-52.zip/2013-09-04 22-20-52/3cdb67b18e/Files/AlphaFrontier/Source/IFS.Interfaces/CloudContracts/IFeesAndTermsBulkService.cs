﻿using IFS.Interfaces.CloudContracts.DataContracts.FeesAndTermsBulk;
using IFS.Interfaces.CloudContracts.DataContracts;

namespace IFS.Interfaces.CloudContracts
{
    public interface IFeesAndTermsBulkService
    {
        ExportResult Download(FeesAndTermsBulkDownloadParameters parameters);
        FeesAndTermsUploadResult Upload(string csvFileContent);
    }
}
