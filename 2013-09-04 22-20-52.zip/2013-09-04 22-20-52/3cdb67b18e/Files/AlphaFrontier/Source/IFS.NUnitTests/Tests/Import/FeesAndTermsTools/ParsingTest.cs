﻿using IFS.BusinessLayer;
using IFS.BusinessLayer.Import.FeesAndTermsTools;
using NUnit.Framework;
using System;

namespace IFS.NUnitTests.Tests.Import.FeesAndTermsTools
{
    public class ParsingTest
    {
        #region Get items string from file without header rows

        [Test]
        public void TestIncorrectHeaderRowsCount()
        {
            const string csvFileContent = "invalid_format";
            var parser = new FeesAndTermsToolsCsvParser();

            var validationException = Assert.Throws<ValidationException>(() => parser.GetItemsStringFromFile(csvFileContent));
            Assert.AreEqual("Header rows not found.", validationException.Message);
        }

        [Test]
        public void TestEmptyFile()
        {
            var csvFileContent = "row1" + Environment.NewLine + "row2";
            var parser = new FeesAndTermsToolsCsvParser();

            var validationException = Assert.Throws<ValidationException>(() => parser.GetItemsStringFromFile(csvFileContent));
            Assert.AreEqual("Empty file.", validationException.Message);
        }

        [Test]
        public void TestInvalidHeaders()
        {
            var csvFileContent = "row1" + Environment.NewLine + "row2" + Environment.NewLine + "row3";
            var parser = new FeesAndTermsToolsCsvParser();

            var validationException = Assert.Throws<ValidationException>(() => parser.GetItemsStringFromFile(csvFileContent));
            Assert.AreEqual("Header rows should contain 84 columns.", validationException.Message);
        }

        [Test]
        public void TestValidHeaders()
        {
            var headerRow1 = GetColumnsValidString();
            var headerRow2 = GetColumnsValidString();
            const string itemRow = "itemRow";

            var csvFileContent = string.Concat(headerRow1, Environment.NewLine, headerRow2, Environment.NewLine, itemRow);
            var parser = new FeesAndTermsToolsCsvParser();

            var items = parser.GetItemsStringFromFile(csvFileContent);
            Assert.AreEqual(1, items.Length);
            Assert.AreEqual(itemRow, items[0]);
        }

        private static string GetColumnsValidString()
        {
            return new String(',', FeesAndTermsToolsCsvParser.COLUMNS_COUNT - 1);
        }

        #endregion

        #region Item string parsing

        [Test]
        public void TestItemParsingWithInvalidColumnsCount()
        {
            const string csvFileContent = "invalid_format";
            var parser = new FeesAndTermsToolsCsvParser();

            var validationException = Assert.Throws<ValidationException>(() => parser.ParseCsvLine(csvFileContent));
            Assert.AreEqual("Columns count is 1, but expected 84.", validationException.Message);
        }

        [Test]
        public void TestParsingValid()
        {
            var templateItem = FeesAndTermsHelper.TemplateItem;
            var csvFileContent = FeesAndTermsHelper.GetCsvStringFromTemplateItem();
            var parser = new FeesAndTermsToolsCsvParser();

            var item = parser.ParseCsvLine(csvFileContent);

            // TODO: consider using reflection or override equals for FeesAndTermsToolsItem

            Assert.AreEqual(templateItem.BasicInformation.Client, item.BasicInformation.Client);
            Assert.AreEqual(templateItem.BasicInformation.Fund, item.BasicInformation.Fund);
            Assert.AreEqual(templateItem.BasicInformation.ClassOnly, item.BasicInformation.ClassOnly);
            Assert.AreEqual(templateItem.BasicInformation.Id.String, item.BasicInformation.Id.String);
            Assert.AreEqual(templateItem.BasicInformation.SidePocket.String, item.BasicInformation.SidePocket.String);

            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.LockupTerm.String, item.RedemptionPolicy.RedemptionPolicyGroup.LockupTerm.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Schedule, item.RedemptionPolicy.RedemptionPolicyGroup.Schedule);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.CustomDate.String, item.RedemptionPolicy.RedemptionPolicyGroup.CustomDate.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Liquidity.String, item.RedemptionPolicy.RedemptionPolicyGroup.Liquidity.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.AsOf.String, item.RedemptionPolicy.RedemptionPolicyGroup.AsOf.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.FirstRedAfterLockupExp.String, item.RedemptionPolicy.RedemptionPolicyGroup.FirstRedAfterLockupExp.String);

            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].LockupType, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].LockupType);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].FeeType, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].FeeType);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].FeeNumber.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].FeeNumber.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].Years.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].Years.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].Months.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].Months.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].Days.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].Days.String);

            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].LockupType, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].LockupType);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].FeeType, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].FeeType);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].FeeNumber.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].FeeNumber.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].Years.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].Years.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].Months.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].Months.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].Days.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].Days.String);

            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].LockupType, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].LockupType);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].FeeType, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].FeeType);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].FeeNumber.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].FeeNumber.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].Years.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].Years.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].Months.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].Months.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].Days.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].Days.String);

            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].LockupType, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].LockupType);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].FeeType, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].FeeType);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].FeeNumber.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].FeeNumber.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].Years.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].Years.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].Months.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].Months.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].Days.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].Days.String);

            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].LockupType, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].LockupType);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].FeeType, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].FeeType);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].FeeNumber.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].FeeNumber.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].Years.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].Years.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].Months.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].Months.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].Days.String, item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].Days.String);

            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.NoticePeriodFullDays.String, item.RedemptionPolicy.RedemptionPolicyGroup.NoticePeriodFullDays.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.NoticePeriodFullMethod.String, item.RedemptionPolicy.RedemptionPolicyGroup.NoticePeriodFullMethod.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.NoticePeriodPartialDays.String, item.RedemptionPolicy.RedemptionPolicyGroup.NoticePeriodPartialDays.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.NoticePeriodPartialMethod.String, item.RedemptionPolicy.RedemptionPolicyGroup.NoticePeriodPartialMethod.String);

            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.MinRedemption.Type, item.RedemptionPolicy.RedemptionPolicyGroup.MinRedemption.Type);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.MinRedemption.Value.String, item.RedemptionPolicy.RedemptionPolicyGroup.MinRedemption.Value.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.MaxRedemption.Type, item.RedemptionPolicy.RedemptionPolicyGroup.MaxRedemption.Type);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.MaxRedemption.Value.String, item.RedemptionPolicy.RedemptionPolicyGroup.MaxRedemption.Value.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.MinBalance.Type, item.RedemptionPolicy.RedemptionPolicyGroup.MinBalance.Type);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.MinBalance.Value.String, item.RedemptionPolicy.RedemptionPolicyGroup.MinBalance.Value.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.GeneralRedFee.Type, item.RedemptionPolicy.RedemptionPolicyGroup.GeneralRedFee.Type);
            Assert.AreEqual(templateItem.RedemptionPolicy.RedemptionPolicyGroup.GeneralRedFee.Value.String, item.RedemptionPolicy.RedemptionPolicyGroup.GeneralRedFee.Value.String);

            Assert.AreEqual(templateItem.RedemptionPolicy.DistrDeclaration.String, item.RedemptionPolicy.DistrDeclaration.String);
            Assert.AreEqual(templateItem.RedemptionPolicy.Gate.String, item.RedemptionPolicy.Gate.String);

            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.Schedule, item.RedemptionPaymentSchedule.Schedule);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.ExpectedAuditMonth.String, item.RedemptionPaymentSchedule.ExpectedAuditMonth.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.ExpectedAuditDay.String, item.RedemptionPaymentSchedule.ExpectedAuditDay.String);

            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Rows[0].Percent.String, item.RedemptionPaymentSchedule.FullRedemption.Rows[0].Percent.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Rows[0].Days.String, item.RedemptionPaymentSchedule.FullRedemption.Rows[0].Days.String);

            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Rows[1].Percent.String, item.RedemptionPaymentSchedule.FullRedemption.Rows[1].Percent.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Rows[2].Percent.String, item.RedemptionPaymentSchedule.FullRedemption.Rows[2].Percent.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Rows[3].Percent.String, item.RedemptionPaymentSchedule.FullRedemption.Rows[3].Percent.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Rows[4].Percent.String, item.RedemptionPaymentSchedule.FullRedemption.Rows[4].Percent.String);

            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Rows[1].Days.String, item.RedemptionPaymentSchedule.FullRedemption.Rows[1].Days.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Rows[2].Days.String, item.RedemptionPaymentSchedule.FullRedemption.Rows[2].Days.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Rows[3].Days.String, item.RedemptionPaymentSchedule.FullRedemption.Rows[3].Days.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Rows[4].Days.String, item.RedemptionPaymentSchedule.FullRedemption.Rows[4].Days.String);

            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Holdback.Percent.String, item.RedemptionPaymentSchedule.FullRedemption.Holdback.Percent.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Holdback.ReceivedDays.String, item.RedemptionPaymentSchedule.FullRedemption.Holdback.ReceivedDays.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.FullRedemption.Holdback.ReceivedAfter.String, item.RedemptionPaymentSchedule.FullRedemption.Holdback.ReceivedAfter.String);

            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Rows[0].Percent.String, item.RedemptionPaymentSchedule.PartialRedemption.Rows[0].Percent.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Rows[0].Days.String, item.RedemptionPaymentSchedule.PartialRedemption.Rows[0].Days.String);

            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Rows[1].Percent.String, item.RedemptionPaymentSchedule.PartialRedemption.Rows[1].Percent.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Rows[2].Percent.String, item.RedemptionPaymentSchedule.PartialRedemption.Rows[2].Percent.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Rows[3].Percent.String, item.RedemptionPaymentSchedule.PartialRedemption.Rows[3].Percent.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Rows[4].Percent.String, item.RedemptionPaymentSchedule.PartialRedemption.Rows[4].Percent.String);

            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Rows[1].Days.String, item.RedemptionPaymentSchedule.PartialRedemption.Rows[1].Days.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Rows[2].Days.String, item.RedemptionPaymentSchedule.PartialRedemption.Rows[2].Days.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Rows[3].Days.String, item.RedemptionPaymentSchedule.PartialRedemption.Rows[3].Days.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Rows[4].Days.String, item.RedemptionPaymentSchedule.PartialRedemption.Rows[4].Days.String);

            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Holdback.Percent.String, item.RedemptionPaymentSchedule.PartialRedemption.Holdback.Percent.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Holdback.ReceivedDays.String, item.RedemptionPaymentSchedule.PartialRedemption.Holdback.ReceivedDays.String);
            Assert.AreEqual(templateItem.RedemptionPaymentSchedule.PartialRedemption.Holdback.ReceivedAfter.String, item.RedemptionPaymentSchedule.PartialRedemption.Holdback.ReceivedAfter.String);
        }

        #endregion
    }
}
