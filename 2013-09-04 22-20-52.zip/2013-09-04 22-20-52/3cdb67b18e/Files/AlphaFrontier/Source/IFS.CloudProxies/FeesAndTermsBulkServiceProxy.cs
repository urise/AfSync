﻿using IFS.Interfaces.CloudContracts;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.FeesAndTermsBulk;

namespace IFS.CloudProxies
{
    public class FeesAndTermsBulkServiceProxy : CloudProxyBase, IFeesAndTermsBulkService
    {
        private const string DOWNLOAD_FLOW = "FeesAndTermsBulkService_Download";
        private const string UPLOAD_FLOW = "FeesAndTermsBulkService_Upload";

        public ExportResult Download(FeesAndTermsBulkDownloadParameters parameters)
        {
            return Execute<ExportResult>(parameters, null, DOWNLOAD_FLOW);
        }

        public FeesAndTermsUploadResult Upload(string csvFileContent)
        {
            return Execute<FeesAndTermsUploadResult>(csvFileContent, null, UPLOAD_FLOW);
        }
    }
}
