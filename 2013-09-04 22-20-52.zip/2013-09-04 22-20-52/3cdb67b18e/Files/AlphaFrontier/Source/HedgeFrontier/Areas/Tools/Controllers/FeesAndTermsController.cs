﻿using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HedgeFrontier.CommonMvc;
using IFS.BusinessLayer;
using IFS.BusinessLayer.CloudServices;
using IFS.BusinessLayer.Models.Tools;
using IFS.BusinessLayer.Utilities;
using IFS.Interfaces.CloudContracts;
using IFS.Interfaces.CloudContracts.DataContracts.FeesAndTermsBulk;
using IFS.BusinessLayer.Export;
using System.Text;
using IFS.Interfaces.Common.Enums;

namespace HedgeFrontier.Areas.Tools.Controllers
{
    public class FeesAndTermsController : Controller
    {
        private static IFeesAndTermsBulkService GetService()
        {
            return SpringUtil.GetObject<IFeesAndTermsBulkService>(ServiceNames.FEES_AND_TERMS_BULK_SERVICE_SPRING_NAME);
        }

        [Permissions(Component.TOOLS_FEES_AND_TERMS)]
        public ActionResult Index()
        {
            var model = new FeesAndTermsModel { FeesAndTermsTypeList = CEnumHelper.ConvertToDictionary<FeesAndTermsType>() };
            return View(model);
        }

        [HttpPost]
        public FileResult DownloadTemplate(FeesAndTermsModel model)
        {
            var parameters = new FeesAndTermsBulkDownloadParameters
                                 {
                                     OrganizationId = CSession.OrganizationID,
                                     AsOfDate = model.AsOfDate,
                                     FeesAndTermsType = model.FeesAndTermsType
                                 };

            var exportResult = GetService().Download(parameters);
            if (exportResult.Failed)
            {
                ModelState.AddModelError(string.Empty, exportResult.InnerException.Message);
                // TODO: add error handler
                //return View("Index");
            }

            return File(exportResult.Exported, AfOpenExcelHelper.EXCEL_EXPORT_CONTENT_TYPE, exportResult.FileName);
        }

        [HttpPost]
        public ActionResult Upload(HttpPostedFileBase file)
        {
            if (file != null && file.ContentLength > 0)
            {
                var fileContent = new StreamReader(file.InputStream, Encoding.Unicode).ReadToEnd();
                var uploadResult = GetService().Upload(fileContent);

                //if (uploadResult.Failed || uploadResult.InnerCollection.Any())
                {
                    // TODO: add error handler
                }
            }
            return RedirectToAction("Index");
        }

    }

}
