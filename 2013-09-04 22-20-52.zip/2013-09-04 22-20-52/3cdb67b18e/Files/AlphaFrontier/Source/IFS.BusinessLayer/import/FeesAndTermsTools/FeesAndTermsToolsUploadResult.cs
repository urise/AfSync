using IFS.BusinessLayer.Import.FeesAndTermsTools.ItemWrapper;
using System.Collections.Generic;
using System.Linq;
using IFS.Interfaces.Common;

namespace IFS.BusinessLayer.Import.FeesAndTermsTools
{
    public class FeesAndTermsToolsUploadResult
    {
        public List<FeesAndTermsToolsItem> ValidItems { get; set; }
        public List<FeesAndTermsErrorItem> ErrorItems { get; set; }
        public bool HasErrors { get { return ErrorItems.Any(); } }

        public FeesAndTermsToolsUploadResult()
        {
            ValidItems = new List<FeesAndTermsToolsItem>();
            ErrorItems = new List<FeesAndTermsErrorItem>();
        }
    }
}