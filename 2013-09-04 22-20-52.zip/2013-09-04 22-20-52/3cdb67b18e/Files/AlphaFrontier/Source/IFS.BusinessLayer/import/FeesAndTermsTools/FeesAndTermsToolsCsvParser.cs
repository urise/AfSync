﻿using System;
using System.Linq;
using IFS.BusinessLayer.Import.FeesAndTermsTools.ItemWrapper;

namespace IFS.BusinessLayer.Import.FeesAndTermsTools
{
    public class FeesAndTermsToolsCsvParser
    {
        #region Csv column index

        private const int CLIENT = 0;
        private const int FUND = 1;
        private const int CLASS_ONLY = 2;
        private const int ID = 3;
        private const int SIDE_POCKET = 4;
        private const int LOCKUP_TERM = 5;
        private const int RED_POLICY_SCHEDULE = 6;
        private const int CUSTOM_DATE = 7;
        private const int LIQUIDITY = 8;
        private const int AS_OF = 9;
        private const int FIRST_REDEMPTION_EVENT_AFTER_LOCK_UP_EXPRIES = 10;

        private const int REDEMPTION_FEE_FOR_INTERVAL1_LOCKUP_TYPE = 11;
        private const int REDEMPTION_FEE_FOR_INTERVAL1_FEE_TYPE = 12;
        private const int REDEMPTION_FEE_FOR_INTERVAL1_FEE_NUMBER = 13;
        private const int REDEMPTION_FEE_FOR_INTERVAL1_YEARS = 14;
        private const int REDEMPTION_FEE_FOR_INTERVAL1_MONTHS = 15;
        private const int REDEMPTION_FEE_FOR_INTERVAL1_DAYS = 16;

        private const int REDEMPTION_FEE_FOR_INTERVAL2_LOCKUP_TYPE = 17;
        private const int REDEMPTION_FEE_FOR_INTERVAL2_FEE_TYPE = 18;
        private const int REDEMPTION_FEE_FOR_INTERVAL2_FEE_NUMBER = 19;
        private const int REDEMPTION_FEE_FOR_INTERVAL2_YEARS = 20;
        private const int REDEMPTION_FEE_FOR_INTERVAL2_MONTHS = 21;
        private const int REDEMPTION_FEE_FOR_INTERVAL2_DAYS = 22;

        private const int REDEMPTION_FEE_FOR_INTERVAL3_LOCKUP_TYPE = 23;
        private const int REDEMPTION_FEE_FOR_INTERVAL3_FEE_TYPE = 24;
        private const int REDEMPTION_FEE_FOR_INTERVAL3_FEE_NUMBER = 25;
        private const int REDEMPTION_FEE_FOR_INTERVAL3_YEARS = 26;
        private const int REDEMPTION_FEE_FOR_INTERVAL3_MONTHS = 27;
        private const int REDEMPTION_FEE_FOR_INTERVAL3_DAYS = 28;

        private const int REDEMPTION_FEE_FOR_INTERVAL4_LOCKUP_TYPE = 29;
        private const int REDEMPTION_FEE_FOR_INTERVAL4_FEE_TYPE = 30;
        private const int REDEMPTION_FEE_FOR_INTERVAL4_FEE_NUMBER = 31;
        private const int REDEMPTION_FEE_FOR_INTERVAL4_YEARS = 32;
        private const int REDEMPTION_FEE_FOR_INTERVAL4_MONTHS = 33;
        private const int REDEMPTION_FEE_FOR_INTERVAL4_DAYS = 34;

        private const int REDEMPTION_FEE_FOR_INTERVAL5_LOCKUP_TYPE = 35;
        private const int REDEMPTION_FEE_FOR_INTERVAL5_FEE_TYPE = 36;
        private const int REDEMPTION_FEE_FOR_INTERVAL5_FEE_NUMBER = 37;
        private const int REDEMPTION_FEE_FOR_INTERVAL5_YEARS = 38;
        private const int REDEMPTION_FEE_FOR_INTERVAL5_MONTHS = 39;
        private const int REDEMPTION_FEE_FOR_INTERVAL5_DAYS = 40;

        private const int NOTICE_PERIOD_FULL_DAYS = 41;
        private const int NOTICE_PERIOD_FULL_METHOD = 42;
        private const int NOTICE_PERIOD_PARTIAL_DAYS = 43;
        private const int NOTICE_PERIOD_PARTIAL_METHOD = 44;
        private const int MIN_REDEMPTION_TYPE = 45;
        private const int MIN_REDEMPTION = 46;
        private const int MAX_REDEMPTION_TYPE = 47;
        private const int MAX_REDEMPTION = 48;
        private const int MIN_BALANCE_TYPE = 49;
        private const int MIN_BALANCE = 50;
        private const int GENERAL_RED_FEE_TYPE = 51;
        private const int GENERAL_RED_FEE = 52;
        private const int DISTR_DECLARATION = 53;
        private const int GATE = 54;
        private const int RED_PAYMENT_SCHEDULE = 55;
        private const int EXPECTED_AUDIT_MONTH_MM = 56;
        private const int EXPECTED_AUDIT_DAY_DD = 57;

        private const int FULL_RED_PMT1 = 58;
        private const int FULL_RED_PMT_DAYS1 = 59;

        private const int FULL_RED_PMT2 = 60;
        private const int FULL_RED_PMT3 = 61;
        private const int FULL_RED_PMT4 = 62;
        private const int FULL_RED_PMT5 = 63;

        private const int FULL_RED_PMT_DAYS2 = 64;
        private const int FULL_RED_PMT_DAYS3 = 65;
        private const int FULL_RED_PMT_DAYS4 = 66;
        private const int FULL_RED_PMT_DAYS5 = 67;

        private const int FULL_RED_HOLDBACK = 68;
        private const int FULL_RED_HOLDBACK_RECEIVED_DAYS = 69;
        private const int FULL_RED_HOLDBACK_RECEIVED_AFTER = 70;

        private const int PARTIAL_RED_PMT1 = 71;
        private const int PARTIAL_RED_PMT_DAYS1 = 72;

        private const int PARTIAL_RED_PMT2 = 73;
        private const int PARTIAL_RED_PMT3 = 74;
        private const int PARTIAL_RED_PMT4 = 75;
        private const int PARTIAL_RED_PMT5 = 76;

        private const int PARTIAL_RED_PMT_DAYS2 = 77;
        private const int PARTIAL_RED_PMT_DAYS3 = 78;
        private const int PARTIAL_RED_PMT_DAYS4 = 79;
        private const int PARTIAL_RED_PMT_DAYS5 = 80;

        private const int PARTIAL_RED_HOLDBACK = 81;
        private const int PARTIAL_RED_HOLDBACK_RECEIVED_DAYS = 82;
        private const int PARTIAL_RED_HOLDBACK_RECEIVED_AFTER = 83;

        #endregion

        public const int COLUMNS_COUNT = 84;
        private const int HEADER_ROWS_COUNT = 2;

        public string[] GetItemsStringFromFile(string csvFileContent)
        {
            var lines = csvFileContent.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);

            if (lines.Length < HEADER_ROWS_COUNT)
                throw new ValidationException("Header rows not found.");

            if (lines.Length == HEADER_ROWS_COUNT)
                throw new ValidationException("Empty file.");

            if (GetColumnsCount(lines[0]) != COLUMNS_COUNT || GetColumnsCount(lines[1]) != COLUMNS_COUNT)
                throw new ValidationException("Header rows should contain " + COLUMNS_COUNT + " columns.");

            return lines.Skip(HEADER_ROWS_COUNT).ToArray();
        }

        public FeesAndTermsToolsItem ParseCsvLine(string csvLine)
        {
            var csvLineSplit = CImport.SplitCsv(csvLine);

            if (csvLineSplit.Length != COLUMNS_COUNT)
                throw new ValidationException("Columns count is " + csvLineSplit.Length + ", but expected " + COLUMNS_COUNT + ".");

            var item = new FeesAndTermsToolsItem();

            item.BasicInformation.Client = csvLineSplit[CLIENT];
            item.BasicInformation.Fund = csvLineSplit[FUND];
            item.BasicInformation.ClassOnly = csvLineSplit[CLASS_ONLY];
            item.BasicInformation.Id.String = csvLineSplit[ID];
            item.BasicInformation.SidePocket.String = csvLineSplit[SIDE_POCKET];

            item.RedemptionPolicy.RedemptionPolicyGroup.LockupTerm.String = csvLineSplit[LOCKUP_TERM];
            item.RedemptionPolicy.RedemptionPolicyGroup.Schedule = csvLineSplit[RED_POLICY_SCHEDULE];
            item.RedemptionPolicy.RedemptionPolicyGroup.CustomDate.String = csvLineSplit[CUSTOM_DATE];
            item.RedemptionPolicy.RedemptionPolicyGroup.Liquidity.String = csvLineSplit[LIQUIDITY];
            item.RedemptionPolicy.RedemptionPolicyGroup.AsOf.String = csvLineSplit[AS_OF];
            item.RedemptionPolicy.RedemptionPolicyGroup.FirstRedAfterLockupExp.String = csvLineSplit[FIRST_REDEMPTION_EVENT_AFTER_LOCK_UP_EXPRIES];

            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].LockupType = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL1_LOCKUP_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].FeeType = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL1_FEE_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].FeeNumber.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL1_FEE_NUMBER];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].Years.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL1_YEARS];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].Months.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL1_MONTHS];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[0].Days.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL1_DAYS];

            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].LockupType = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL2_LOCKUP_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].FeeType = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL2_FEE_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].FeeNumber.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL2_FEE_NUMBER];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].Years.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL2_YEARS];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].Months.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL2_MONTHS];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[1].Days.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL2_DAYS];

            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].LockupType = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL3_LOCKUP_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].FeeType = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL3_FEE_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].FeeNumber.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL3_FEE_NUMBER];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].Years.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL3_YEARS];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].Months.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL3_MONTHS];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[2].Days.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL3_DAYS];

            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].LockupType = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL4_LOCKUP_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].FeeType = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL4_FEE_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].FeeNumber.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL4_FEE_NUMBER];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].Years.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL4_YEARS];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].Months.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL4_MONTHS];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[3].Days.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL4_DAYS];

            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].LockupType = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL5_LOCKUP_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].FeeType = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL5_FEE_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].FeeNumber.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL5_FEE_NUMBER];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].Years.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL5_YEARS];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].Months.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL5_MONTHS];
            item.RedemptionPolicy.RedemptionPolicyGroup.Lockups[4].Days.String = csvLineSplit[REDEMPTION_FEE_FOR_INTERVAL5_DAYS];

            item.RedemptionPolicy.RedemptionPolicyGroup.NoticePeriodFullDays.String = csvLineSplit[NOTICE_PERIOD_FULL_DAYS];
            item.RedemptionPolicy.RedemptionPolicyGroup.NoticePeriodFullMethod.String = csvLineSplit[NOTICE_PERIOD_FULL_METHOD];
            item.RedemptionPolicy.RedemptionPolicyGroup.NoticePeriodPartialDays.String = csvLineSplit[NOTICE_PERIOD_PARTIAL_DAYS];
            item.RedemptionPolicy.RedemptionPolicyGroup.NoticePeriodPartialMethod.String = csvLineSplit[NOTICE_PERIOD_PARTIAL_METHOD];

            item.RedemptionPolicy.RedemptionPolicyGroup.MinRedemption.Type = csvLineSplit[MIN_REDEMPTION_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.MinRedemption.Value.String = csvLineSplit[MIN_REDEMPTION];
            item.RedemptionPolicy.RedemptionPolicyGroup.MaxRedemption.Type = csvLineSplit[MAX_REDEMPTION_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.MaxRedemption.Value.String = csvLineSplit[MAX_REDEMPTION];
            item.RedemptionPolicy.RedemptionPolicyGroup.MinBalance.Type = csvLineSplit[MIN_BALANCE_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.MinBalance.Value.String = csvLineSplit[MIN_BALANCE];
            item.RedemptionPolicy.RedemptionPolicyGroup.GeneralRedFee.Type = csvLineSplit[GENERAL_RED_FEE_TYPE];
            item.RedemptionPolicy.RedemptionPolicyGroup.GeneralRedFee.Value.String = csvLineSplit[GENERAL_RED_FEE];

            item.RedemptionPolicy.DistrDeclaration.String = csvLineSplit[DISTR_DECLARATION];
            item.RedemptionPolicy.Gate.String = csvLineSplit[GATE];

            item.RedemptionPaymentSchedule.Schedule = csvLineSplit[RED_PAYMENT_SCHEDULE];
            item.RedemptionPaymentSchedule.ExpectedAuditMonth.String = csvLineSplit[EXPECTED_AUDIT_MONTH_MM];
            item.RedemptionPaymentSchedule.ExpectedAuditDay.String = csvLineSplit[EXPECTED_AUDIT_DAY_DD];

            item.RedemptionPaymentSchedule.FullRedemption.Rows[0].Percent.String = csvLineSplit[FULL_RED_PMT1];
            item.RedemptionPaymentSchedule.FullRedemption.Rows[0].Days.String = csvLineSplit[FULL_RED_PMT_DAYS1];

            item.RedemptionPaymentSchedule.FullRedemption.Rows[1].Percent.String = csvLineSplit[FULL_RED_PMT2];
            item.RedemptionPaymentSchedule.FullRedemption.Rows[2].Percent.String = csvLineSplit[FULL_RED_PMT3];
            item.RedemptionPaymentSchedule.FullRedemption.Rows[3].Percent.String = csvLineSplit[FULL_RED_PMT4];
            item.RedemptionPaymentSchedule.FullRedemption.Rows[4].Percent.String = csvLineSplit[FULL_RED_PMT5];

            item.RedemptionPaymentSchedule.FullRedemption.Rows[1].Days.String = csvLineSplit[FULL_RED_PMT_DAYS2];
            item.RedemptionPaymentSchedule.FullRedemption.Rows[2].Days.String = csvLineSplit[FULL_RED_PMT_DAYS3];
            item.RedemptionPaymentSchedule.FullRedemption.Rows[3].Days.String = csvLineSplit[FULL_RED_PMT_DAYS4];
            item.RedemptionPaymentSchedule.FullRedemption.Rows[4].Days.String = csvLineSplit[FULL_RED_PMT_DAYS5];

            item.RedemptionPaymentSchedule.FullRedemption.Holdback.Percent.String = csvLineSplit[FULL_RED_HOLDBACK];
            item.RedemptionPaymentSchedule.FullRedemption.Holdback.ReceivedDays.String = csvLineSplit[FULL_RED_HOLDBACK_RECEIVED_DAYS];
            item.RedemptionPaymentSchedule.FullRedemption.Holdback.ReceivedAfter.String = csvLineSplit[FULL_RED_HOLDBACK_RECEIVED_AFTER];

            item.RedemptionPaymentSchedule.PartialRedemption.Rows[0].Percent.String = csvLineSplit[PARTIAL_RED_PMT1];
            item.RedemptionPaymentSchedule.PartialRedemption.Rows[0].Days.String = csvLineSplit[PARTIAL_RED_PMT_DAYS1];

            item.RedemptionPaymentSchedule.PartialRedemption.Rows[1].Percent.String = csvLineSplit[PARTIAL_RED_PMT2];
            item.RedemptionPaymentSchedule.PartialRedemption.Rows[2].Percent.String = csvLineSplit[PARTIAL_RED_PMT3];
            item.RedemptionPaymentSchedule.PartialRedemption.Rows[3].Percent.String = csvLineSplit[PARTIAL_RED_PMT4];
            item.RedemptionPaymentSchedule.PartialRedemption.Rows[4].Percent.String = csvLineSplit[PARTIAL_RED_PMT5];

            item.RedemptionPaymentSchedule.PartialRedemption.Rows[1].Days.String = csvLineSplit[PARTIAL_RED_PMT_DAYS2];
            item.RedemptionPaymentSchedule.PartialRedemption.Rows[2].Days.String = csvLineSplit[PARTIAL_RED_PMT_DAYS3];
            item.RedemptionPaymentSchedule.PartialRedemption.Rows[3].Days.String = csvLineSplit[PARTIAL_RED_PMT_DAYS4];
            item.RedemptionPaymentSchedule.PartialRedemption.Rows[4].Days.String = csvLineSplit[PARTIAL_RED_PMT_DAYS5];

            item.RedemptionPaymentSchedule.PartialRedemption.Holdback.Percent.String = csvLineSplit[PARTIAL_RED_HOLDBACK];
            item.RedemptionPaymentSchedule.PartialRedemption.Holdback.ReceivedDays.String = csvLineSplit[PARTIAL_RED_HOLDBACK_RECEIVED_DAYS];
            item.RedemptionPaymentSchedule.PartialRedemption.Holdback.ReceivedAfter.String = csvLineSplit[PARTIAL_RED_HOLDBACK_RECEIVED_AFTER];

            return item;
        }

        private static int GetColumnsCount(string csvLine)
        {
            return CImport.SplitCsv(csvLine).Length;
        }

    }
}
