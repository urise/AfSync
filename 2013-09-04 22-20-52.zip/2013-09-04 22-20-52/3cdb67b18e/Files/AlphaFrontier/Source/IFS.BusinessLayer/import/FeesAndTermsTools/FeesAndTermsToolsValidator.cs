﻿using IFS.BusinessLayer.Import.FeesAndTermsTools.Validation;
using IFS.Interfaces.Common;

namespace IFS.BusinessLayer.Import.FeesAndTermsTools
{
    public class FeesAndTermsToolsValidator
    {
        private readonly FeesAndTermsToolsCsvParser _parser = new FeesAndTermsToolsCsvParser();
        private string[] _feesAndTermsItems;

        public FeesAndTermsToolsUploadResult ParseAndValidateItems(string csvFileContent)
        {
            var uploadResult = InitFeesAndTermsItems(csvFileContent);

            if (!uploadResult.HasErrors)
            {
                uploadResult = ValidateItems();
            }
            return uploadResult;
        }

        private FeesAndTermsToolsUploadResult ValidateItems()
        {
            var uploadResult = new FeesAndTermsToolsUploadResult();
            foreach (var csvLine in _feesAndTermsItems)
            {
                try
                {
                    var feesAndTermsItem = _parser.ParseCsvLine(csvLine);

                    var itemValidator = new FeesAndTermsToolsItemValidator(feesAndTermsItem);
                    itemValidator.Validate();

                    uploadResult.ValidItems.Add(feesAndTermsItem);
                }
                catch (ValidationException ex)
                {
                    uploadResult.ErrorItems.Add(new FeesAndTermsErrorItem { CsvLine = csvLine, ErrorText = ex.Message });
                }
            }
            return uploadResult;
        }

        private FeesAndTermsToolsUploadResult InitFeesAndTermsItems(string csvFileContent)
        {
            var uploadResult = new FeesAndTermsToolsUploadResult();
            try
            {
                _feesAndTermsItems = _parser.GetItemsStringFromFile(csvFileContent);
            }
            catch (ValidationException ex)
            {
                uploadResult.ErrorItems.Add(new FeesAndTermsErrorItem { ErrorText = ex.Message });
            }
            return uploadResult;
        }

    }
}
