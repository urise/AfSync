﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IFS.BusinessLayer.Import.FeesAndTermsTools.ItemWrapper;

namespace IFS.BusinessLayer.Import.FeesAndTermsTools
{
    public class FeesAndTermsToolsImport
    {
        public FeesAndTermsToolsUploadResult Import(List<FeesAndTermsToolsItem> items)
        {
            return new FeesAndTermsToolsUploadResult();
        }

        private void Import(FeesAndTermsToolsItem item)
        {

        }
        
    }
}
