﻿using IFS.BusinessLayer.Import.FeesAndTermsTools.ItemWrapper;

namespace IFS.BusinessLayer.Import.FeesAndTermsTools.Validation
{
    public class FeesAndTermsToolsItemValidator
    {
        private readonly BasicInformationValidator _basicInformationValidator;
        private readonly RedemptionPolicyValidator _redemptionPolicyValidator;
        private readonly RedemptionPaymentScheduleValidator _redemptionPaymentScheduleValidator;

        public FeesAndTermsToolsItemValidator(FeesAndTermsToolsItem item)
        {
            _basicInformationValidator = new BasicInformationValidator(item.BasicInformation);
            _redemptionPolicyValidator = new RedemptionPolicyValidator(item.RedemptionPolicy);
            _redemptionPaymentScheduleValidator = new RedemptionPaymentScheduleValidator(item.RedemptionPaymentSchedule);
        }

        public void Validate()
        {
            _basicInformationValidator.Validate();
            _redemptionPolicyValidator.Validate();
            _redemptionPaymentScheduleValidator.Validate();
        }
    }
}
