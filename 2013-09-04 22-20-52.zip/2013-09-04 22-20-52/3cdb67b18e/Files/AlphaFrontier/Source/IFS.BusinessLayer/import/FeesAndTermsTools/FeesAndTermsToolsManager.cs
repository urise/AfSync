﻿namespace IFS.BusinessLayer.Import.FeesAndTermsTools
{
    public class FeesAndTermsToolsManager
    {
        private readonly FeesAndTermsToolsImport _import = new FeesAndTermsToolsImport();
        private readonly FeesAndTermsToolsValidator _validator = new FeesAndTermsToolsValidator();

        public FeesAndTermsToolsUploadResult Upload(string csvFileContent)
        {
            var uploadResult = _validator.ParseAndValidateItems(csvFileContent);

            if (!uploadResult.HasErrors)
            {
                uploadResult = _import.Import(uploadResult.ValidItems);
            }

            return uploadResult;
        }
    }
}
