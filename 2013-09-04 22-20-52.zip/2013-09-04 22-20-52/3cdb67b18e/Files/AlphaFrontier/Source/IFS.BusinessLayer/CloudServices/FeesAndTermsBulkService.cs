﻿using IFS.BusinessLayer.Import.FeesAndTermsTools;
using IFS.Interfaces.CloudContracts;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.FeesAndTermsBulk;
using IFS.BusinessLayer.Export;
using IFS.Interfaces.Common.Enums;
using System.IO;
using System.Linq;

namespace IFS.BusinessLayer.CloudServices
{
    public class FeesAndTermsBulkService : CloudServiceBase, IFeesAndTermsBulkService
    {
        public ExportResult Download(FeesAndTermsBulkDownloadParameters parameters)
        {
            return Execute(null, () =>
            {
                var exportResult = new ExportResult { FileName = "FeesAndTermsTemplate.xlsx" };
                using (var memStream = new MemoryStream())
                {
                    var organization = Organization.Loader.GetById(parameters.OrganizationId);
                    var ufc = new UnderlyingFundCollection(UnderlyingFund.SelectForOrgId(organization.OrganizationID, SystemTypeBase.FUND_CLASS));
                    ufc.AddRange(new UnderlyingFundCollection(UnderlyingFund.SelectForOrgId(organization.OrganizationID, SystemTypeBase.SIDELETTER)));

                    var filteredData = ufc.Where(f => f.IssueDate <= parameters.AsOfDate).ToList();
                    ufc = new UnderlyingFundCollection();
                    ufc.AddRange(filteredData);

                    ufc.SortByFullName();

                    var excelGenerator = new FeesAndTermsExportGenerator(memStream)
                    {
                        ClientName = organization.OrganizationName,
                        OrganizationId = organization.OrganizationID,
                        FundCollection = ufc,
                        FeesAndTermsType = parameters.FeesAndTermsType
                    };

                    excelGenerator.GenerateExcelExport();
                    exportResult.Exported = memStream.ToArray();
                }
                return exportResult;
            });
        }

        public FeesAndTermsUploadResult Upload(string csvFileContent)
        {
            return Execute(null, () =>
            {
                var feesAndTerms = new FeesAndTermsToolsManager();
                var uploadResult = feesAndTerms.Upload(csvFileContent);
                return new FeesAndTermsUploadResult { ErrorItems = uploadResult.ErrorItems };
            });
        }
    }
}
