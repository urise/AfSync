﻿//Round number to x decimal places
function GetRoundedTo(val, decimalPlaces) {
    var result = Math.round(val * Math.pow(10, decimalPlaces)) / Math.pow(10, decimalPlaces);
    return result;
}



function IsNumeric(sText) {
    var numericRegExp = /^(-)?(\d*)(\.?)(\d*)$/;
    var regex = new RegExp(numericRegExp);
    if (!regex.test(sText))
        return false;
    else
        return true;
}

function GetNumericValue(val) {
    var trimmedVal = val.replace(/%|,|\s/g, '');
    return trimmedVal;
}

function isWeekendDay(date) {
    if (date == null)
        return false;

    var dow = date.getDay();
    if (dow == 0 || dow == 6)
        return true;
    return false;
}

// ===================================================================
// Author: Matt Kruse <matt@mattkruse.com>
// WWW: http://www.mattkruse.com/
// ===================================================================
// These functions use the same 'format' strings as the 
// java.text.SimpleDateFormat class, with minor exceptions.
// The format string consists of the following abbreviations:
// 
// Field        | Full Form          | Short Form
// -------------+--------------------+-----------------------
// Year         | yyyy (4 digits)    | yy (2 digits), y (2 or 4 digits)
// Month        | MMM (name or abbr.)| MM (2 digits), M (1 or 2 digits)
//              | NNN (abbr.)        |
// Day of Month | dd (2 digits)      | d (1 or 2 digits)
// Day of Week  | EE (name)          | E (abbr)
// Hour (1-12)  | hh (2 digits)      | h (1 or 2 digits)
// Hour (0-23)  | HH (2 digits)      | H (1 or 2 digits)
// Hour (0-11)  | KK (2 digits)      | K (1 or 2 digits)
// Hour (1-24)  | kk (2 digits)      | k (1 or 2 digits)
// Minute       | mm (2 digits)      | m (1 or 2 digits)
// Second       | ss (2 digits)      | s (1 or 2 digits)
// AM/PM        | a                  |
//
// NOTE THE DIFFERENCE BETWEEN MM and mm! Month=MM, not mm!
// Examples:
//  "MMM d, y" matches: January 01, 2000
//                      Dec 1, 1900
//                      Nov 20, 00
//  "M/d/yy"   matches: 01/20/00
//                      9/2/00
//  "MMM dd, yyyy hh:mm:ssa" matches: "January 01, 2000 12:30:45AM"
// ------------------------------------------------------------------

var MONTH_NAMES = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
var DAY_NAMES = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat');
function LZ(x) { return (x < 0 || x > 9 ? "" : "0") + x;
}

// ------------------------------------------------------------------
// isDate ( date_string, format_string )
// Returns true if date string matches format of format string and
// is a valid date. Else returns false.
// It is recommended that you trim whitespace around the value before
// passing it to this function, as whitespace is NOT ignored!
// ------------------------------------------------------------------
function isDate(val, format) {
    var date = getDateFromFormat(val, format);
    if (date == 0) { return false; }
    return true;
}

// -------------------------------------------------------------------
// compareDates(date1,date1format,date2,date2format)
//   Compare two date strings to see which is greater.
//   Returns:
//   1 if date1 is greater than date2
//   0 if date2 is greater than date1 of if they are the same
//  -1 if either of the dates is in an invalid format
// -------------------------------------------------------------------
function compareDates(date1, dateformat1, date2, dateformat2) {
    var d1 = getDateFromFormat(date1, dateformat1);
    var d2 = getDateFromFormat(date2, dateformat2);
    if (d1 == 0 || d2 == 0 || d1 < d2) {
        return -1;
    }
    else if (d1 > d2) {
        return 1;
    }
    return 0;
}

function CompareDates(date1, date2) {
    var d1 = new Date(date1.getFullYear(), date1.getMonth(), date1.getDate());
    var d2 = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate());
    if (d1 > d2)
        return 1;
    else if (d1 < d2)
        return -1;
    else if (d1 == d2)
        return 0;

    return null;
}

function IsDateGreaterThanFirst(date) {
    if (date == null)
        return false;

    var dow = date.getDate();

    if (dow > 1)
        return true;

    return false;
}

// ------------------------------------------------------------------
// formatDate (date_object, format)
// Returns a date in the output format specified.
// The format string uses the same abbreviations as in getDateFromFormat()
// ------------------------------------------------------------------
function formatDate(date, format) {
    format = format + "";
    var result = "";
    var iFormat = 0;
    var c;
    var token;
    var y = date.getYear() + "";
    var M = date.getMonth() + 1;
    var d = date.getDate();
    var E = date.getDay();
    var H = date.getHours();
    var m = date.getMinutes();
    var s = date.getSeconds();
    // Convert real date parts into formatted versions
    var value = new Object();
    if (y.length < 4) { y = "" + (y - 0 + 1900); }
    value["y"] = "" + y;
    value["yyyy"] = y;
    value["yy"] = y.substring(2, 4);
    value["M"] = M;
    value["MM"] = LZ(M);
    value["MMM"] = MONTH_NAMES[M - 1];
    value["NNN"] = MONTH_NAMES[M + 11];
    value["d"] = d;
    value["dd"] = LZ(d);
    value["E"] = DAY_NAMES[E + 7];
    value["EE"] = DAY_NAMES[E];
    value["H"] = H;
    value["HH"] = LZ(H);
    if (H == 0) { value["h"] = 12; }
    else if (H > 12) { value["h"] = H - 12; }
    else { value["h"] = H; }
    value["hh"] = LZ(value["h"]);
    if (H > 11) { value["K"] = H - 12; } else { value["K"] = H; }
    value["k"] = H + 1;
    value["KK"] = LZ(value["K"]);
    value["kk"] = LZ(value["k"]);
    if (H > 11) { value["a"] = "PM"; }
    else { value["a"] = "AM"; }
    value["m"] = m;
    value["mm"] = LZ(m);
    value["s"] = s;
    value["ss"] = LZ(s);
    while (iFormat < format.length) {
        c = format.charAt(iFormat);
        token = "";
        while ((format.charAt(iFormat) == c) && (iFormat < format.length)) {
            token += format.charAt(iFormat++);
        }
        if (value[token] != null) { result = result + value[token]; }
        else { result = result + token; }
    }
    return result;
}

// ------------------------------------------------------------------
// Utility functions for parsing in getDateFromFormat()
// ------------------------------------------------------------------
function _isInteger(val) {
    var digits = "1234567890";
    for (var i = 0; i < val.length; i++) {
        if (digits.indexOf(val.charAt(i)) == -1) { return false; }
    }
    return true;
}
function _getInt(str, i, minlength, maxlength) {
    for (var x = maxlength; x >= minlength; x--) {
        var token = str.substring(i, i + x);
        if (token.length < minlength) { return null; }
        if (_isInteger(token)) { return token; }
    }
    return null;
}

// ------------------------------------------------------------------
// getDateFromFormat( date_string , format_string )
//
// This function takes a date string and a format string. It matches
// If the date string matches the format string, it returns the 
// getTime() of the date. If it does not match, it returns 0.
// ------------------------------------------------------------------
function getDateFromFormat(val, format) {
    val = val + "";
    format = format + "";
    var iVal = 0;
    var iFormat = 0;
    var c;
    var token;
    var x, y;
    var now = new Date();
    var year = now.getYear();
    var month = now.getMonth() + 1;
    var date = 1;
    var hh = now.getHours();
    var mm = now.getMinutes();
    var ss = now.getSeconds();
    var ampm = "";

    while (iFormat < format.length) {
        // Get next token from format string
        c = format.charAt(iFormat);
        token = "";
        while ((format.charAt(iFormat) == c) && (iFormat < format.length)) {
            token += format.charAt(iFormat++);
        }
        // Extract contents of value based on format token
        if (token == "yyyy" || token == "yy" || token == "y") {
            if (token == "yyyy") { x = 4; y = 4; }
            if (token == "yy") { x = 2; y = 2; }
            if (token == "y") { x = 2; y = 4; }
            year = _getInt(val, iVal, x, y);
            if (year == null) { return 0; }
            iVal += year.length;
            if (year.length == 2) {
                if (year > 70) { year = 1900 + (year - 0); }
                else { year = 2000 + (year - 0); }
            }
        }
        else {
            var i;
            if (token == "MMM" || token == "NNN") {
                month = 0;
                for (i = 0; i < MONTH_NAMES.length; i++) {
                    var monthName = MONTH_NAMES[i];
                    if (val.substring(iVal, iVal + monthName.length).toLowerCase() == monthName.toLowerCase()) {
                        if (token == "MMM" || (token == "NNN" && i > 11)) {
                            month = i + 1;
                            if (month > 12) { month -= 12; }
                            iVal += monthName.length;
                            break;
                        }
                    }
                }
                if ((month < 1) || (month > 12)) { return 0; }
            }
            else if (token == "EE" || token == "E") {
                for (i = 0; i < DAY_NAMES.length; i++) {
                    var dayName = DAY_NAMES[i];
                    if (val.substring(iVal, iVal + dayName.length).toLowerCase() == dayName.toLowerCase()) {
                        iVal += dayName.length;
                        break;
                    }
                }
            }
            else if (token == "MM" || token == "M") {
                month = _getInt(val, iVal, token.length, 2);
                if (month == null || (month < 1) || (month > 12)) { return 0; }
                iVal += month.length;
            }
            else if (token == "dd" || token == "d") {
                date = _getInt(val, iVal, token.length, 2);
                if (date == null || (date < 1) || (date > 31)) { return 0; }
                iVal += date.length;
            }
            else if (token == "hh" || token == "h") {
                hh = _getInt(val, iVal, token.length, 2);
                if (hh == null || (hh < 1) || (hh > 12)) { return 0; }
                iVal += hh.length;
            }
            else if (token == "HH" || token == "H") {
                hh = _getInt(val, iVal, token.length, 2);
                if (hh == null || (hh < 0) || (hh > 23)) { return 0; }
                iVal += hh.length;
            }
            else if (token == "KK" || token == "K") {
                hh = _getInt(val, iVal, token.length, 2);
                if (hh == null || (hh < 0) || (hh > 11)) { return 0; }
                iVal += hh.length;
            }
            else if (token == "kk" || token == "k") {
                hh = _getInt(val, iVal, token.length, 2);
                if (hh == null || (hh < 1) || (hh > 24)) { return 0; }
                iVal += hh.length; hh--;
            }
            else if (token == "mm" || token == "m") {
                mm = _getInt(val, iVal, token.length, 2);
                if (mm == null || (mm < 0) || (mm > 59)) { return 0; }
                iVal += mm.length;
            }
            else if (token == "ss" || token == "s") {
                ss = _getInt(val, iVal, token.length, 2);
                if (ss == null || (ss < 0) || (ss > 59)) { return 0; }
                iVal += ss.length;
            }
            else if (token == "a") {
                if (val.substring(iVal, iVal + 2).toLowerCase() == "am") { ampm = "AM"; }
                else if (val.substring(iVal, iVal + 2).toLowerCase() == "pm") { ampm = "PM"; }
                else { return 0; }
                iVal += 2;
            }
            else {
                if (val.substring(iVal, iVal + token.length) != token) { return 0; }
                else { iVal += token.length; }
            }
        }
    }
    // If there are any trailing characters left in the value, it doesn't match
    if (iVal != val.length) { return 0; }
    // Is date valid for month?
    if (month == 2) {
        // Check for leap year
        if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0)) { // leap year
            if (date > 29) { return 0; }
        }
        else { if (date > 28) { return 0; } }
    }
    if ((month == 4) || (month == 6) || (month == 9) || (month == 11)) {
        if (date > 30) { return 0; }
    }
    // Correct hours value
    if (hh < 12 && ampm == "PM") { hh = hh - 0 + 12; }
    else if (hh > 11 && ampm == "AM") { hh -= 12; }
    var newdate = new Date(year, month - 1, date, hh, mm, ss);
    return newdate;
}

function grayOut(vis, options, divName) {
    // Pass true to gray out screen, false to ungray
    // options are optional.  This is a JSON object with the following (optional) properties
    // opacity:0-100         // Lower number = less grayout higher = more of a blackout 
    // zindex: #             // HTML elements with a higher zindex appear on top of the gray out
    // bgcolor: (#xxxxxx)    // Standard RGB Hex color code
    // grayOut(true, {'zindex':'50', 'bgcolor':'#0000FF', 'opacity':'70'});
    // Because options is JSON opacity/zindex/bgcolor are all optional and can appear
    // in any order.  Pass only the properties you need to set.
    options = options || {};
    var zindex = options.zindex || 50;
    var opacity = options.opacity || 70;
    var opaque = (opacity / 100);
    var bgcolor = options.bgcolor || '#000000';
    var dark;
    if (divName != null) {
        dark = document.getElementById(divName);
    } else {
        dark = document.getElementById('darkenScreenObject');
    }
    if (!dark) {
        // The dark layer doesn't exist, it's never been created.  So we'll
        // create it here and apply some basic styles.
        // If you are getting errors in IE see: http://support.microsoft.com/default.aspx/kb/927917
        var tbody = document.getElementsByTagName('body')[0];
        var tnode = document.createElement('div');           // Create the layer.
        tnode.style.position = 'absolute';                 // Position absolutely
        tnode.style.top = '0px';                           // In the top
        tnode.style.left = '0px';                          // Left corner of the page
        tnode.style.overflow = 'hidden';                   // Try to avoid making scroll bars            
        tnode.style.display = 'none';                      // Start out Hidden
        tnode.id = 'darkenScreenObject';                   // Name it so we can find it later
        tbody.appendChild(tnode);                            // Add it to the web page
        dark = document.getElementById('darkenScreenObject');  // Get the object.
    }
    if (vis) {
        // Calculate the page width and height 
        var pageWidth;
        var pageHeight;
        if (document.body && (document.body.scrollWidth || document.body.scrollHeight)) {
            pageWidth = document.body.scrollWidth + 'px';
            pageHeight = document.body.scrollHeight + 'px';
        } else if (document.body.offsetWidth) {
            pageWidth = document.body.offsetWidth + 'px';
            pageHeight = document.body.offsetHeight + 'px';
        } else {
            pageWidth = '100%';
            pageHeight = '100%';
        }
        //set the shader to cover the entire page and make it visible.
        dark.style.opacity = opaque;
        dark.style.MozOpacity = opaque;
        dark.style.filter = 'alpha(opacity=' + opacity + ')';
        dark.style.zIndex = zindex;
        dark.style.width = pageWidth;
        dark.style.height = pageHeight;
        dark.style.backgroundColor = bgcolor;
        dark.style.display = 'block';
        hideSelects();
    }
    else {
        dark.style.display = 'none';
        showSelects();
    }
}

function ToggleDiv(divId, needCenterWithJs) {
    var divObj = document.getElementById(divId);
    if (divObj.style.display == 'none') {
        divObj.style.display = 'block';
        grayOut(true, { 'opacity': '25' });
        ShowObjSelects(divObj);
        if(needCenterWithJs)
            PlaceDivToCenter(divObj);
    }
    else {
        divObj.style.display = 'none';
        grayOut(false);
    }

    return true;
}

function updatescroll2() {
    var el = document.getElementById(event.srcElement.id.replace("_scroller", ""));
    if (el != null)
        el.value = event.srcElement.scrollTop;
}

function setscroll(el, val) {
    var div = document.getElementById(el);
    if (div != null) {
        div.scrollTop = val;
        div.onscroll = updatescroll2;
    }
}


//Used in PopUp.vb
function setPosition(el, pos) {
    if (pos == "center") {
        //el.style.setExpression("left","document.body.clientWidth/2 - this.offsetWidth/2");
        //el.style.setExpression("top","document.body.clientHeight/2 -  this.offsetHeight/2");
        //********* Use this for your LeftGuess and TopGuess properties on the Popup
        //alert(('left = ' + (document.body.clientWidth/2 - el.offsetWidth/2)));
        //alert(('top = ' + (document.body.clientHeight/2 -  el.offsetHeight/2)));

        // add the control to the default form so that positioning is not relative to a control in the page (DS 11/17/04)
        // assumes one standard page form
        document.forms[0].appendChild(el);
        el.style.position = "absolute";
        el.style.top = document.body.clientHeight / 2 - el.offsetHeight / 2;
        el.style.left = document.body.clientWidth / 2 - el.offsetWidth / 2;

    } else if (pos == "centerRight") {
        document.forms[0].appendChild(el);
        el.style.position = "absolute";
        el.style.top = document.body.clientHeight / 2 - el.offsetHeight / 2;
        el.style.left = (1.5 * document.body.clientWidth - el.offsetWidth) / 2;
    } else if (pos == "centerLeft") {
        document.forms[0].appendChild(el);
        el.style.position = "absolute";
        el.style.top = document.body.clientHeight / 2 - el.offsetHeight / 2;
        el.style.left = (0.5 * document.body.clientWidth - el.offsetWidth) / 2;
    } else if (pos == "topleft") {
        el.style.left = 10;
        el.style.top = 100;
    } else if (pos == "topright") {
        el.style.setExpression("left", "document.body.clientWidth - this.offsetWidth");
        el.style.top = 100;
    } else if (pos == "bottomleft") {
        el.style.left = 10;
        el.style.setExpression("top", "document.body.clientHeight -  this.offsetHeight");
    } else if (pos == "bottomright") {
        el.style.setExpression("left", "document.body.clientWidth - this.offsetWidth");
        el.style.setExpression("top", "document.body.clientHeight -  this.offsetHeight");
    }
    el.style.visibility = "visible";

}
//Used in PopUp.vb
function setRelative(rel, el) {
    var relpos = getElementPosition(rel.id);
    el.style.position = "absolute";
    el.style.left = relpos.left; //+ rel.clientWidth + 5;
    el.style.top = relpos.top;
    //alert('left = ' + relpos.left);
    el.style.visibility = "visible";
    //alert('top = ' + relpos.top);
}
function getElementPosition(elemId) {
    var offsetTrail = document.getElementById(elemId);
    var offsetLeft = 0;
    var offsetTop = 0;
    while (offsetTrail) {
        offsetLeft += offsetTrail.offsetLeft - offsetTrail.scrollLeft;
        offsetTop += offsetTrail.offsetTop - offsetTrail.scrollTop;
        offsetTrail = offsetTrail.offsetParent;
    }

    offsetLeft += document.body.scrollLeft;
    offsetTop += document.body.scrollTop;

    return { left: offsetLeft, top: offsetTop };


}


//**********************Input Mask Function*********************************//

function Mask_KeyDown(el) {
    var k = event.keyCode;

    if (k == 46) //Delete 
        el.value = "";

    if (k == 8) { //backspace
        DeleteOne(el);
    } else if ((k == 9) || (k >= 48 && k <= 57) || (k >= 96 && k <= 105)) {
        //event.returnValue = false;
    } else if (k == 191 || k == 111) { //slash

    } else {
        event.returnValue = false;
    }
}
function Mask_MouseUp(el) {
    var r = document.selection.createRange();
    r.collapse();
    r.moveEnd('character', 1);
    r.select();
    if (r.text == "/") {
        r.moveStart('character', 1);
        r.moveEnd('character', 1);
        r.select();
    }
}

function Mask_KeyPress(el) {//char
    var k = event.keyCode;
    var r = document.selection.createRange();
    if (r.text == '') {
        ProcessMask(el);
    }
    else {
        var selectedValue = r.text;
        var pos = getCaretPosition(el);

        //replace selection with new char
        var old = el.value;
        el.value = old.substr(0, pos) + String.fromCharCode(k) + old.substr(pos + selectedValue.length);

        //move cursor to the end
        el.focus();
        r.moveStart('character', el.value.length);
        r.moveEnd('character', el.value.length);
        r.select();
    }
    event.returnValue = false;
}

function getCaretPosition(ctrl) {
    var caretPos = 0;
    if (document.selection) {

        ctrl.focus();
        var sel = document.selection.createRange();
        var selLength = document.selection.createRange().text.length;
        sel.moveStart('character', -ctrl.value.length);
        caretPos = sel.text.length - selLength;
    }
    return caretPos;
}

function DeleteOne(el) {
    var val = el.value;
    var len = val.length;
    var r = document.selection.createRange();
    if (r.text == '') {

        if (len == 4 || len == 7) {
            el.value = val.substring(0, len - 2);
        } else {
            el.value = val.substring(0, len - 1);
        }
    }

    event.returnValue = false;
    return false;

}


function ProcessMask(el) {
    if (el.mask == "") {

    }
    ProcessDateMask(el);
    return false;
}

function getAdditionalLen(value) {
    var tarr = value.split("/");
    var addLen = 0;
    var monthPos = 0;
    var dayPos = 1;
    if (tarr.length > monthPos + 1 && tarr[monthPos].length < 2) {
        addLen++;
    }
    if (tarr.length > dayPos + 1 && tarr[dayPos].length < 2) {
        addLen++;
    }
    return addLen;
}

function ProcessDateMask(el) {
    var isSlash;
    var isNumber;
    var val = el.value;
    var k = window.event.keyCode;
    var chr = String.fromCharCode(k);
    isSlash = k == 47;
    isNumber = (k >= 48 && k <= 57) || (k >= 96 && k <= 105);
    var len = val.length + getAdditionalLen(val);
    switch (len) {
        case 0:
            if (isNumber)
                el.value = chr;
            break;
        case 1:
            if (isSlash) {
                el.value = '0' + el.value + '/';
            } else if (isNumber) {
                if (parseInt(el.value + chr) > 12) {
                    el.value = '0' + el.value + '/' + chr;
                } else {
                    el.value += chr;
                }
            }
            break;
        case 2:
            if (isSlash) {
                el.value += '/';
            } else if (isNumber) {
                el.value += '/' + chr;
            }
            break;
        case 3:
            if (isNumber) {
                el.value += chr;
            }
            break;
        case 4:
            if (isSlash) {
                el.value = el.value.substring(0, 3) + '0' + el.value.substring(3, 4) + '/';
            } else if (isNumber) {
                if (parseInt(el.value.substring(3, 4) + chr) > GetNumDaysInMonth(el.value.substring(0, 2).replace('/', ''))) {
                    //entered invalid month
                    el.value = el.value.substring(0, 2) + '/' + '0' + el.value.substring(3, 4) + '/' + chr;
                } else {
                    el.value += chr + '/';
                }
            }
            break;
        case 5:
            if (isSlash) {
                el.value += '/';
            } else if (isNumber) {
                if (chr == '0') {
                    el.value += '/200';
                } else if (chr == '1') {
                    el.value += '/1';
                } else if (chr == '2') {
                    el.value += '/2';
                }
            }
            break;
        case 6:
            if (isNumber) {
                if (chr == '0') {
                    el.value += '200';
                } else if (chr == '1') {
                    el.value += '1';
                } else if (chr == '2') {
                    el.value += '2';
                }
            }
            break;
        case 7:
            if (isNumber) {
                el.value += chr;
            }
            break;
        case 8:
            if (isNumber) {
                el.value += chr;
            }
            break;
        case 9:
            if (isNumber) {
                el.value += chr;
            }
            break;
    }
    return false;

}
function GetNumDaysInMonth(val) {
    var daysPerMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    return daysPerMonth[parseInt(eval(val)) - 1];
}

function Replace(refString, oldString, newString) {

    var temp = refString;
    var i = temp.indexOf(oldString);
    while (i > -1) {
        temp = temp.replace(oldString, newString);
        i = temp.indexOf(oldString, i + newString.length + 1);
    }
    return temp;
}


var requiredArr = new Array();
function isRequired(elname, type, mess, len) {
    requiredArr[requiredArr.length] = { name: elname, t: type, message: mess, length: len };
}

function FocusOnMessageBox() {
    setfocus("messagebox_deletebutton");
    //document.getElementById("messagebox_deletebutton").focus();
}

function Disable(id) {
    document.getElementById(id).disabled = false;
}

function Enable(id) {
    document.getElementById(id).disabled = true;
}


function Trim(s) {  // Remove leading spaces and carriage returns
    while ((s.substring(0, 1) == ' ') || (s.substring(0, 1) == '\n') || (s.substring(0, 1) == '\r'))
    { s = s.substring(1, s.length); }
    // Remove trailing spaces and carriage returns
    while ((s.substring(s.length - 1, s.length) == ' ') || (s.substring(s.length - 1, s.length) == '\n') || (s.substring(s.length - 1, s.length) == '\r'))
    { s = s.substring(0, s.length - 1); }
    return s;
}

function setfocus(id, fromtimeout) {
    var el = document.getElementById(id);
    if (fromtimeout == null) fromtimeout = false;
    if (el != null) {
        try {
            el.focus();
        } catch (er) {
            //It will not let you set the focus to an input
            //element that is not visible, lets wait .5 seconds to see if it come up
            if (!fromtimeout) {
                setTimeout("setfocus('" + id + "',true);", 500);
            }
        }
    }
}

//TODO: T.Zavorotnii (ALPHA-482) Investigate if 3 functions below can be removed
/* returns true if [v] is not defined, false otherwise

IE 5.0 does not support the undefined keyword, so we cannot do a direct 
comparison such as v===undefined. 
*/
function isUndefined(v) {
    var undef;
    return v === undef;
}


// LAZINESS

function undef(v) { /* alias for isUndefined  */return isUndefined(v);
}
function isdef(v) { /* alias for !isUndefined */return !isUndefined(v);
}

/*
takes a string containing [sep]-separated values and splits it into an array
sep is optional. the default separator is a comma surrounded by optional 
whitespace.
if sep is true, the separator becomes a simple comma
if sep is any string or regex, then sep is the separator
*/
function list(s, sep) {
    if (typeof sep != 'string' && !(sep instanceof RegExp))
        sep = sep ? ',' : /\s*,\s*/;
    return s.split(sep);
}


// PYTHONIC

/*
identical to python's range.
range(stop)
range(start,stop)
range(start,stop,step)
    
Return a list containing an arithmetic progression of integers.
range(i, j) returns [i, i+1, i+2, ..., j-1]; start (!) defaults to 0.
When step is given, it specifies the increment (or decrement).
For example, range(4) returns [0, 1, 2, 3].  The end point is omitted!
[from python's range's docstring]
*/
function range(start, stop, step) {
    if (isUndefined(stop)) return range(0, start, step);
    if (isUndefined(step)) step = 1;
    var ss = (step / Math.abs(step)); // step sign
    var r = [];
    for (var i = start; i * ss < stop * ss; i = i + step) r.push(i);
    return r;
}

/*
maprange(stop, fn)
maprange(start, stop, fn)
	
return map(range(start,stop), fn)

this is pure laziness.
*/
function maprange(start, stop, fn) {
    if (arguments.length == 2) return maprange(0, start, stop);
    if (arguments.length != 3) throw "maprange takes 2 or 3 arguments";
    return map(range(start, stop), fn);
}


/*
this is used internally by map, filter and reduce to accept strings as 
functions.
	
[args] is a string of comma separated names of the function arguments
[fn] is the function body
	
if [fn] does not contain a return statement, a return keyword will be added 
before the last statement. the last statement is determined by removing the
trailing semicolon (';') (if it exists) and then searching for the last 
semicolon, hence, caveats may apply (i.e. if the last statement has a 
string or regex containing the ';' character things will go wrong)
*/
function __strfn(args, fn) {
    function quote(s) { return '"' + s.replace(/"/g, '\\"') + '"';
    }
    if (!/\breturn\b/.test(fn)) {
        fn = fn.replace(/;\s+$/, '');
        fn = fn.insert(fn.lastIndexOf(';') + 1, ' return ');
    }
    return eval('new Function({0},{1})'.subArgs(
		map(args.split(/\s*,\s*/), quote).join(),
		quote(fn)));
}

/*
traverses [list], applying [fn] to [list], returning an array of values 
returned by [fn]

[fn] should be a function, but may also be a string containing a function
body, in which case the name of the paremeters passed to it	will be 'item', 
'idx' and 'list'.
	
se doc for __strfn for peculiarities about passing strings for [fn]
	
if [fn] is not provided, the list item is returned itself. this is an easy 
way to transform fake arrays (e.g. the arguments object of a function or 
nodeList objects) into real javascript arrays.
	
map also provides a safe way for traversing only an array's indexed items, 
ignoring its other properties. (as opposed to how for-in works)

this is a simplified version of python's map. parameter order is different, 
only a single list (array) is accepted, and the parameters passed to [fn]
are different:
[fn] takes the current item, then, optionally, the current index and a 
reference to the list (so that [fn] can modify list)
*/
function map(list, fn) {
    if (typeof (fn) == 'string') return map(list, __strfn('item,idx,list', fn));

    var result = [];
    fn = fn || function (v) { return v; };
    for (var i = 0; i < list.length; i++) result.push(fn(list[i], i, list));
    return result;
}

/*
returns an array of items in [list] for which fn(value) is true
	
[fn] should be a function, but may also be a string containing a function
body, in which case the name of the paremeters passed to it	will be 'item', 
'idx' and 'list'.
	
se doc for __strfn for peculiarities about passing strings for [fn]
	
if [fn] is not specified the values are evaluated themselves, that is, 
filter will return an array of the values in [list] which evaluate to true
	
this is a similar to python's filter, but parameter order is inverted
*/
function filter(list, fn) {
    if (typeof (fn) == 'string') return filter(list, __strfn('item,idx,list', fn));

    var result = [];
    fn = fn || function (v) { return v; };
    map(list, function (item, idx, list) { if (fn(item, idx, list)) result.push(item); });
    return result;
}

/*
similar to python's reduce. paremeter onder inverted... 
TODO: document this properly

[fn] should be a function, but may also be a string containing a function
body, in which case the name of the paremeters passed to it	will be 'a'	and 
'b';
	
se doc for __strfn for peculiarities about passing strings for [fn]
*/
function reduce(list, fn, initial) {
    if (typeof (fn) == 'string') return reduce(list, __strfn('a,b', fn), initial);
    if (isdef(initial)) list.splice(0, 0, initial);
    if (list.length === 0) return false;
    if (list.length === 1) return list[0];
    var result = list[0];
    var i = 1;
    while (i < list.length) result = fn(result, list[i++]);
    return result;
}


// Exports
window.isUndefined = isUndefined;
window.undef = undef;
window.isdef = isdef;
window.list = list;
window.range = range;
window.maprange = maprange;
window.__strfn = __strfn;
window.map = map;
window.filter = filter;
window.reduce = reduce;
'IFS.system.lang : version 1.0'; function NumberFormat(num, inputDecimal) {
    this.COMMA = ',';
    this.PERIOD = '.';
    this.DASH = '-';
    this.LEFT_PAREN = '(';
    this.RIGHT_PAREN = ')';
    this.LEFT_OUTSIDE = 0;
    this.LEFT_INSIDE = 1;
    this.RIGHT_INSIDE = 2;
    this.RIGHT_OUTSIDE = 3;
    this.LEFT_DASH = 0;
    this.RIGHT_DASH = 1;
    this.PARENTHESIS = 2;
    this.NO_ROUNDING = -1;
    this.num;
    this.numOriginal;
    this.hasSeparators = false;
    this.separatorValue;
    this.inputDecimalValue;
    this.decimalValue;
    this.negativeFormat;
    this.negativeRed;
    this.hasCurrency;
    this.currencyPosition;
    this.currencyValue;
    this.places;
    this.roundToPlaces;
    this.setNumber = setNumberNF;
    this.toUnformatted = toUnformattedNF;
    this.setInputDecimal = setInputDecimalNF;
    this.setSeparators = setSeparatorsNF;
    this.setCommas = setCommasNF;
    this.setNegativeFormat = setNegativeFormatNF;
    this.setNegativeRed = setNegativeRedNF;
    this.setCurrency = setCurrencyNF;
    this.setCurrencyPrefix = setCurrencyPrefixNF;
    this.setCurrencyValue = setCurrencyValueNF;
    this.setCurrencyPosition = setCurrencyPositionNF;
    this.setPlaces = setPlacesNF;
    this.toFormatted = toFormattedNF;
    this.toPercentage = toPercentageNF;
    this.getOriginal = getOriginalNF;
    this.moveDecimalRight = moveDecimalRightNF;
    this.moveDecimalLeft = moveDecimalLeftNF;
    this.getRounded = getRoundedNF;
    this.preserveZeros = preserveZerosNF;
    this.justNumber = justNumberNF;
    this.expandExponential = expandExponentialNF;
    this.getZeros = getZerosNF;
    this.moveDecimalAsString = moveDecimalAsStringNF;
    this.moveDecimal = moveDecimalNF;
    this.addSeparators = addSeparatorsNF;
    if (inputDecimal == null) {
        this.setNumber(num, this.PERIOD);
    } else {
        this.setNumber(num, inputDecimal);
    }
    this.setCommas(true);
    this.setNegativeFormat(this.LEFT_DASH);
    this.setNegativeRed(false);
    this.setCurrency(false);
    this.setCurrencyPrefix('$');
    this.setPlaces(2);
}
function setInputDecimalNF(val) {
    this.inputDecimalValue = val;
}
function setNumberNF(num, inputDecimal) {
    if (inputDecimal != null) {
        this.setInputDecimal(inputDecimal);
    }
    this.numOriginal = num;
    this.num = this.justNumber(num);
}
function toUnformattedNF() {
    return (this.num);
}
function getOriginalNF() {
    return (this.numOriginal);
}
function setNegativeFormatNF(format) {
    this.negativeFormat = format;
}
function setNegativeRedNF(isRed) {
    this.negativeRed = isRed;
}
function setSeparatorsNF(isC, separator, decimal) {
    this.hasSeparators = isC;
    if (separator == null) separator = this.COMMA;
    if (decimal == null) decimal = this.PERIOD;
    if (separator == decimal) {
        this.decimalValue = (decimal == this.PERIOD) ? this.COMMA : this.PERIOD;
    } else {
        this.decimalValue = decimal;
    }
    this.separatorValue = separator;
}
function setCommasNF(isC) {
    this.setSeparators(isC, this.COMMA, this.PERIOD);
}
function setCurrencyNF(isC) {
    this.hasCurrency = isC;
}
function setCurrencyValueNF(val) {
    this.currencyValue = val;
}
function setCurrencyPrefixNF(cp) {
    this.setCurrencyValue(cp);
    this.setCurrencyPosition(this.LEFT_OUTSIDE);
}
function setCurrencyPositionNF(cp) {
    this.currencyPosition = cp;
}
function setPlacesNF(p) {
    this.roundToPlaces = !(p == this.NO_ROUNDING);
    this.places = (p < 0) ? 0 : p;
}
function addSeparatorsNF(nStr, inD, outD, sep) {
    nStr += '';
    var dpos = nStr.indexOf(inD);
    var nStrEnd = '';
    if (dpos != -1) {
        nStrEnd = outD + nStr.substring(dpos + 1, nStr.length);
        nStr = nStr.substring(0, dpos);
    }
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(nStr)) {
        nStr = nStr.replace(rgx, '$1' + sep + '$2');
    }
    return nStr + nStrEnd;
}
function toFormattedNF() {
    var nNum = this.num;
    var nStr;
    if (this.roundToPlaces) {
        nNum = this.getRounded(nNum);
        nStr = this.preserveZeros(Math.abs(nNum));
    } else {
        nStr = this.expandExponential(Math.abs(nNum));
    }
    if (this.hasSeparators) {
        nStr = this.addSeparators(nStr, this.PERIOD, this.decimalValue, this.separatorValue);
    }
    var c0 = '';
    var n0 = '';
    var c1 = '';
    var n1 = '';
    var n2 = '';
    var c2 = '';
    var n3 = '';
    var c3 = '';
    var negSignL = (this.negativeFormat == this.PARENTHESIS) ? this.LEFT_PAREN : this.DASH;
    var negSignR = (this.negativeFormat == this.PARENTHESIS) ? this.RIGHT_PAREN : this.DASH;
    if (this.currencyPosition == this.LEFT_OUTSIDE) {
        if (nNum < 0) {
            if (this.negativeFormat == this.LEFT_DASH || this.negativeFormat == this.PARENTHESIS) n1 = negSignL;
            if (this.negativeFormat == this.RIGHT_DASH || this.negativeFormat == this.PARENTHESIS) n2 = negSignR;
        }
        if (this.hasCurrency) c0 = this.currencyValue;
    } else if (this.currencyPosition == this.LEFT_INSIDE) {
        if (nNum < 0) {
            if (this.negativeFormat == this.LEFT_DASH || this.negativeFormat == this.PARENTHESIS) n0 = negSignL;
            if (this.negativeFormat == this.RIGHT_DASH || this.negativeFormat == this.PARENTHESIS) n3 = negSignR;
        }
        if (this.hasCurrency) c1 = this.currencyValue;
    }
    else if (this.currencyPosition == this.RIGHT_INSIDE) {
        if (nNum < 0) {
            if (this.negativeFormat == this.LEFT_DASH || this.negativeFormat == this.PARENTHESIS) n0 = negSignL;
            if (this.negativeFormat == this.RIGHT_DASH || this.negativeFormat == this.PARENTHESIS) n3 = negSignR;
        }
        if (this.hasCurrency) c2 = this.currencyValue;
    }
    else if (this.currencyPosition == this.RIGHT_OUTSIDE) {
        if (nNum < 0) {
            if (this.negativeFormat == this.LEFT_DASH || this.negativeFormat == this.PARENTHESIS) n1 = negSignL;
            if (this.negativeFormat == this.RIGHT_DASH || this.negativeFormat == this.PARENTHESIS) n2 = negSignR;
        }
        if (this.hasCurrency) c3 = this.currencyValue;
    }
    nStr = c0 + n0 + c1 + n1 + nStr + n2 + c2 + n3 + c3;
    if (this.negativeRed && nNum < 0) {
        nStr = '<font color="red">' + nStr + '</font>';
    }
    return (nStr);
}
function toPercentageNF() {
    var nNum = this.num * 100;
    nNum = this.getRounded(nNum);
    return nNum + '%';
}
function getZerosNF(places) {
    var extraZ = '';
    var i;
    for (i = 0; i < places; i++) {
        extraZ += '0';
    }
    return extraZ;
}
function expandExponentialNF(origVal) {
    if (isNaN(origVal)) return origVal;
    var newVal = parseFloat(origVal) + '';
    var eLoc = newVal.toLowerCase().indexOf('e');
    if (eLoc != -1) {
        var plusLoc = newVal.toLowerCase().indexOf('+');
        var negLoc = newVal.toLowerCase().indexOf('-', eLoc);
        var justNumber = newVal.substring(0, eLoc);
        var places;
        if (negLoc != -1) {
            places = newVal.substring(negLoc + 1, newVal.length);
            justNumber = this.moveDecimalAsString(justNumber, true, parseInt(places));
        } else {
            if (plusLoc == -1) plusLoc = eLoc;
            places = newVal.substring(plusLoc + 1, newVal.length);
            justNumber = this.moveDecimalAsString(justNumber, false, parseInt(places));
        }
        newVal = justNumber;
    }
    return newVal;
}
function moveDecimalRightNF(val, places) {
    var newVal;
    if (places == null) {
        newVal = this.moveDecimal(val, false);
    } else {
        newVal = this.moveDecimal(val, false, places);
    }
    return newVal;
}
function moveDecimalLeftNF(val, places) {
    var newVal;
    if (places == null) {
        newVal = this.moveDecimal(val, true);
    } else {
        newVal = this.moveDecimal(val, true, places);
    }
    return newVal;
}
function moveDecimalAsStringNF(val, left, places) {
    var spaces = (arguments.length < 3) ? this.places : places;
    if (spaces <= 0) return val;
    var newVal = val + '';
    var extraZ = this.getZeros(spaces);
    var re1 = new RegExp('([0-9.]+)');
    var re2;
    if (left) {
        newVal = newVal.replace(re1, extraZ + '$1');
        re2 = new RegExp('(-?)([0-9]*)([0-9]{' + spaces + '})(\\.?)');
        newVal = newVal.replace(re2, '$1$2.$3');
    } else {
        var reArray = re1.exec(newVal);
        if (reArray != null) {
            newVal = newVal.substring(0, reArray.index) + reArray[1] + extraZ + newVal.substring(reArray.index + reArray[0].length);
        }
        re2 = new RegExp('(-?)([0-9]*)(\\.?)([0-9]{' + spaces + '})');
        newVal = newVal.replace(re2, '$1$2$4.');
    }
    newVal = newVal.replace(/\.$/, '');
    return newVal;
}
function moveDecimalNF(val, left, places) {
    var newVal;
    if (places == null) {
        newVal = this.moveDecimalAsString(val, left);
    } else {
        newVal = this.moveDecimalAsString(val, left, places);
    }
    return parseFloat(newVal);
}
function getRoundedNF(val) {
    val = this.moveDecimalRight(val);
    val = Math.round(val);
    val = this.moveDecimalLeft(val);
    return val;
}
function preserveZerosNF(val) {
    var i;
    val = this.expandExponential(val);
    if (this.places <= 0) return val;
    var decimalPos = val.indexOf('.');
    if (decimalPos == -1) {
        val += '.';
        for (i = 0; i < this.places; i++) {
            val += '0';
        }
    } else {
        var actualDecimals = (val.length - 1) - decimalPos;
        var difference = this.places - actualDecimals;
        for (i = 0; i < difference; i++) {
            val += '0';
        }
    }
    return val;
}
function justNumberNF(val) {
    var newVal = val + '';
    var isPercentage = false;
    if (newVal.indexOf('%') != -1) {
        newVal = newVal.replace(/\%/g, '');
        isPercentage = true;
    }
    var re = new RegExp('[^\\' + this.inputDecimalValue + '\\d\\-\\+\\(\\)eE]', 'g');
    newVal = newVal.replace(re, '');
    var tempRe = new RegExp('[' + this.inputDecimalValue + ']', 'g');
    var treArray = tempRe.exec(newVal);
    if (treArray != null) {
        var tempRight = newVal.substring(treArray.index + treArray[0].length);
        newVal = newVal.substring(0, treArray.index) + this.PERIOD + tempRight.replace(tempRe, '');
    }
    if (newVal.charAt(newVal.length - 1) == this.DASH) {
        newVal = newVal.substring(0, newVal.length - 1);
        newVal = '-' + newVal;
    }
    else if (newVal.charAt(0) == this.LEFT_PAREN
&& newVal.charAt(newVal.length - 1) == this.RIGHT_PAREN) {
        newVal = newVal.substring(1, newVal.length - 1);
        newVal = '-' + newVal;
    }
    newVal = parseFloat(newVal);
    if (!isFinite(newVal)) {
        newVal = 0;
    }
    if (isPercentage) {
        newVal = this.moveDecimalLeft(newVal, 2);
    }
    return newVal;
}
//Core Code - Open new window in center of page
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
var OW_HANDLE = null;

function OW_OpenInCenter(page, width, height, config, target, resizable)   //only the first 3 are required
{
    //Provide default dimensions
    if (width == null) { width = 440; }
    if (height == null) { height = 90; }
    if (target == null) { target = 'newWindow_' + new Date().getTime(); }
    if (resizable == null) {resizable = 'yes';}
    //Center the window
    var left = Math.floor((window.screen.availWidth - width) / 2);
    var top = Math.floor((window.screen.availHeight - height) / 2);

    height += 20;
    //Build config string
    var conf = "width=" + width + ",height=" + height + ",top=" + top + ",left=" + left + ",resizable=" + resizable + ",scrollbars=1,";

    //For reports show the Status bar
    if (-1 != page.indexOf('eport'))
        conf += "status=1,";

    if (config != null)
    { conf += config; }

    //Sneak in an extra querystring parameter, so the server can differentiate (eg. session lost)
    var extraParam = 'newWindow=true';
    if (-1 != page.indexOf('?'))
    { page += '&' + extraParam; }
    else
    { page += '?' + extraParam; }

    //Add new parameter to prevent caching
    page += '&time=' + new Date().getTime();

    //Close the last window, as its probably a different size
    if (null != OW_HANDLE)
        OW_HANDLE.close();

    OW_HANDLE = window.open(page, target, conf, 'status=yes');

    if (!OW_HANDLE)
        alert("Failed to launch popup window. This can occur if your browser has disabled popups. Enable popups and try again.\n\n" + "'" + target + "': " + page);

    return OW_HANDLE;
}

function OW_OpenInCenterForChild(page, width, height, config, target)   //only the first 3 are required
{
    //Provide default dimensions
    if (width == null) { width = 440; }
    if (height == null) { height = 90; }
    if (target == null) { target = 'newWindow_' + new Date().getTime(); }

    //Center the window
    var left = Math.floor((window.screen.availWidth - width) / 2);
    var top = Math.floor((window.screen.availHeight - height) / 2);

    //Build config string
    var conf = "width=" + width + ",height=" + height + ",top=" + top + ",left=" + left + ",resizable=yes,";
    if (config != null)
    { conf += config; }

    //Sneak in an extra querystring parameter, so the server can differentiate (eg. session lost)
    var extraParam = 'newWindow=true';
    if (-1 != page.indexOf('?'))
    { page += '&' + extraParam; }
    else
    { page += '?' + extraParam; }

    //Add new parameter to prevent caching
    page += '&time=' + new Date().getTime();

    //Close the last window, as its probably a different size
    if (null != OW_HANDLE)
        OW_HANDLE.close();
    OW_HANDLE = window.open(page, target, conf, 'status=no');

    if (null == OW_HANDLE)
        alert("Failed to launch popup window. This can occur if your browser has disabled popups. Enable popups and try again.\n\n" + "'" + target + "': " + page);
    else
        OW_HANDLE.opener = window.opener;

    return OW_HANDLE;
}
// Check if window open and if open move it to foreground
function OW_IsOpen(handle) {
    if (handle == null) return false;
    var isOpened = !handle.closed;
    if (isOpened) {
        handle.focus(); // move to foreground
    }
    return isOpened;
}
//Modal Dialogs - (Perhaps should just this automatically for all windows?)
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
var OW_MODAL_WINDOW;
var OW_MODAL_INTERVAL;
function OW_ShowModalDialog(url, width, height, config, target)   //only the first 3 are required
{
    OW_MODAL_WINDOW = OW_OpenInCenter(url, width, height, config, target);
    OW_MODAL_WINDOW.focus();
    OW_MODAL_INTERVAL = window.setInterval('OW_ModalDialogMaintainFocus()', 5);
    return OW_MODAL_WINDOW;
}
function OW_ModalDialogMaintainFocus() {
    try {
        if (OW_MODAL_WINDOW.closed) {
            window.clearInterval(OW_MODAL_INTERVAL);
            return;
        }
        OW_MODAL_WINDOW.focus();
    }
    catch (e) { }
}


/*  Config options: (comma delimited)
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
resizable=yes or no
scrollbars=yes or no
toolbar=yes or no
location=yes or no
directories=yes or no
status=yes or no
menubar=yes or no
copyhistory=yes or no
*/



//Application-Specific code - NOTE: Most functions should just define {url, width, height}, or provide an overload/alias
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



//Application Dialog Boxes
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//TODO: T.Zavorotnii (ALPHA-482) Investigate usages of the 4 below functions
// They are used in WebUtililies.CPopup public static methods (Ln 51-65),   which have no usage
function OW_ShowErrorPopup(msg) { OW_ShowMsgPopup(msg, 'Error'); }
function OW_ShowWarningPopup(msg) { OW_ShowMsgPopup(msg, 'Warning'); }
function OW_ShowInfoPopup(msg) { OW_ShowMsgPopup(msg, 'Info'); }
function OW_ShowMsgPopup(msg, type) {
    var url = window.AppPath + '/pages/MessageDialog.aspx?msg=<center>' + msg + '</center>&type=' + type;
    return OW_ShowModalDialog(url, 325, 245);
}


//General-Purpose New/Rename
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function OW_EnterNamePopup(callbackFunctionName, oldName, title, mode, hideTradeExecChkbox, layoutType)    //Only 1st param is compulsory
{

    if (null == oldName)
        oldName = "";
    var url = window.AppPath + '/pages/popups/EnterNamePopup.aspx?oldName=' + oldName + '&callbackFunction=' +
    callbackFunctionName + "&title=" + title + "&mode=" + mode + "&hideTradeChkBox=" + hideTradeExecChkbox + "&layoutType=" + layoutType;
    OW_OpenInCenter(url, 300, 140);
}



//Reports
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function OW_DisplayHtmlReport(reportPage) {
    var url = window.AppPath + '/pages/reports/' + reportPage;
    if (reportPage.indexOf('ReportPriceVariance.aspx') != -1) {
        return OW_OpenInCenter(url, 990, 605);
    }
    if (reportPage.indexOf('ReportExposure.aspx') != -1) {
        return OW_OpenInCenter(url, 1000, 800);
    }
    else if (reportPage.indexOf('ReportFundOfFunds.aspx') != -1 ||
            reportPage.indexOf('ReportInvestmentAnalysis.aspx') != -1 ||
            reportPage.indexOf('ReportCashProjection.aspx') != -1 ||
            reportPage.indexOf('ReportMVComparison.aspx') != -1 ||
            reportPage.indexOf('ReportIaAndFof.aspx') != -1 ||
            reportPage.indexOf('ReportAllPortfoliosInvestments.aspx') != -1 ||
            reportPage.indexOf('ReportContacts.aspx') != -1 ||
            reportPage.indexOf('ReportGlobalContacts.aspx') != -1) {
        return OW_OpenInCenter(url, 800, 605, "scrollbars=yes");
    }
    else {
        return OW_OpenInCenter(url, 800, 605);
    }
}

function OW_DisplayHtmlReportNoBorder(reportPage) {
    var url = window.AppPath + '/pages/reports/' + reportPage;
    OW_OpenInCenterForChild(url, 800, 600);
}

//Investments
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function OW_AttributeComparison(rowId) {
    var url = window.AppPath + '/pages/Popups/AttributeComparisonBarChart.aspx?AttributeRowID=' + rowId;
    return OW_OpenInCenter(url, 415, 515);
}

function OW_AllocationEqualization(fundId, clearer, executionDate, allocationId) {
    var url = window.AppPath + '/pages/popups/EqualizationSubscription.aspx?fundId=' + fundId +
                        '&clearer=' + clearer + '&executionDate=' + executionDate +
                        '&allocationId=' + allocationId;
    return OW_OpenInCenterForChild(url, 350, 300, "scrollbars=yes");
}
function OW_AllocationSubscription(fundId, fromConstruct, administeredBy) {
    var url = window.AppPath + '/pages/popups/AllocationSubscription.aspx?fundId=' + fundId;
    if (fromConstruct)
        url += '&fromContruct=true';
    if (administeredBy)
        url += '&administeredBy=' + administeredBy;
    return OW_OpenInCenter(url, 500, 350, "scrollbars=yes");
}

function OW_AllocationShortSaleBuyToCover(fundId, fromConstruct) {
    var url = window.AppPath + '/pages/popups/ShortSaleBuyToCover.aspx?fundId=' + fundId;
    if (fromConstruct)
        url += '&fromContruct=true';
    return OW_OpenInCenter(url, 500, 350, "scrollbars=yes");
}

function OW_AllocationRedemption(fundId) {
    var url = window.AppPath + '/pages/popups/AllocationRedemption.aspx?fundId=' + fundId;
    return OW_OpenInCenter(url, 820, 500, "scrollbars=yes");
}

function OW_CorporateAction(fundId, caId) {
    var url = window.AppPath + '/pages/popups/CorporateActionEntry.aspx?fundId=' + fundId + '&caId=' + caId;
    return OW_OpenInCenter(url, 820, 500, "scrollbars=yes");
}


function OW_ViewCorporateActions(fundId) {
    var url = window.AppPath + '/pages/popups/ViewCorporateActions.aspx?fundId=' + fundId;
    return OW_OpenInCenter(url, 730, 367, "scrollbars=yes");
}

function OW_ViewCorporateActionAmendments(caId) {
    var url = window.AppPath + '/pages/popups/CorporateActionAmendments.aspx?caId=' + caId;
    return OW_OpenInCenter(url, 730, 367, "scrollbars=yes");
}

function DisablePageContent(contentId, idsToOmit) {
    var content = document.getElementById(contentId);
    var idsToOmitArray = idsToOmit.split(',');
    lockPage(content, idsToOmitArray);
}


function lockPage(oContent, idsToOmitArray) {
    for (var i = 0; i < idsToOmitArray.length; i++) {
        if (oContent.id == idsToOmitArray[i])
            return;
    }

    try {
        if ((oContent.nodeName == "INPUT" &&
           oContent.type != "hidden") ||
           oContent.nodeName == "SELECT" ||
           oContent.nodeName == "IMG" ||
           oContent.type == "textarea") {
            oContent.disabled = true;
        }
    }
    catch (e) { }

    if (oContent.childNodes && oContent.childNodes.length > 0) {
        for (var x = 0; x < oContent.childNodes.length; x++) {
            lockPage(oContent.childNodes[x], idsToOmitArray);
        }
    }
}


function OW_AllocationContingentRedemption(fundId, allocationId) {
    var url = window.AppPath + '/pages/popups/AllocationContingentRedemption.aspx?fundId=' + fundId;
    if (allocationId)
        url += '&allocationId=' + allocationId;
    return OW_OpenInCenter(url, 350, 330, "scrollbars=yes");
}
function OW_AllocationShortSale(fundId, allocationId) {
    var url = window.AppPath + '/pages/popups/AllocationContingentRedemption.aspx?fundId=' + fundId + '&isShortSale=1';
    if (allocationId)
        url += '&allocationId=' + allocationId;
    return OW_OpenInCenter(url, 350, 330, "scrollbars=yes");
}
function OW_AllocationEdit(allocationId, administeredBy) {
    var url = window.AppPath + '/pages/popups/AllocationSubscription.aspx?allocationId=' + allocationId;
    if (administeredBy)
        url += '&administeredBy=' + administeredBy;
    return OW_OpenInCenter(url, 450, 410, "scrollbars=yes");
}
function OW_AllocationShortSaleBuyToCoverEdit(fundId, allocationId) {
    var url = window.AppPath + '/pages/popups/ShortSaleBuyToCover.aspx?allocationId=' + allocationId + '&fundid=' + fundId;
    return OW_OpenInCenter(url, 450, 410, "scrollbars=yes");
}
function OW_PvtEqtySubscriptionEdit(allocationId, fundId) {
    var url = window.AppPath + '/pages/popups/AllocationSubscriptionPvtEqty.aspx?AllocationId=' + allocationId + '&fundid=' + fundId;
    return OW_OpenInCenter(url, 600, 605, "scrollbars=yes");
}
function OW_CapitalCommitmentThirdPartyTransferIn(allocationId, fundId) {
    var url = window.AppPath + '/pages/popups/AllocationSubscriptionPvtEqty.aspx?AllocationId=' + allocationId + '&fundid=' + fundId + '&isThirdPartyTransferIn=1';
    return OW_OpenInCenter(url, 600, 605, "scrollbars=yes");
}
function OW_CapitalCommitmentThirdPartyTransferOut(allocationId, fundId) {
    var url = window.AppPath + '/pages/popups/AllocationRedemptionPvtEqty.aspx?AllocationId=' + allocationId + '&fundid=' + fundId + '&isThirdPartyTransferOut=1';
    return OW_OpenInCenter(url, 645, 605, "scrollbars=yes");
}
function OW_PvtEqtyCommitmentsEdit(allocationId, fundId) {
    var url = window.AppPath + '/pages/popups/AllocationCommitmentPvtEqty.aspx?AllocationId=' + allocationId + '&fundid=' + fundId;
    return OW_OpenInCenter(url, 600, 605, "scrollbars=yes");
}


function OW_PvtEqtyInvestmentSummary(fundId) {
    var url = window.AppPath + '/pages/popups/PrivateEquityInvestmentSummary.aspx?fundid=' + fundId;
    return OW_OpenInCenter(url, 900, 940);
}

function OW_PvtEqtyRedemptionEdit(allocationId, fundId) {
    var url = window.AppPath + '/pages/popups/AllocationRedemptionPvtEqty.aspx?AllocationId=' + allocationId + '&fundid=' + fundId;
    return OW_OpenInCenter(url, 645, 605, "scrollbars=yes");
}

function OW_PvtEqtyCashDistributionEdit(allocationId, fundId) {
    var url = window.AppPath + '/pages/popups/AllocationCashDistributionPvtEqty.aspx?AllocationId=' + allocationId + '&fundid=' + fundId;
    return OW_OpenInCenter(url, 645, 605, "scrollbars=yes");
}

function OW_RedemptionEdit(allocationId, fundid) {
    var url = window.AppPath + '/pages/popups/AllocationRedemption.aspx?allocationId=' + allocationId + '&fundid=' + fundid;
    return OW_OpenInCenter(url, 820, 500, "scrollbars=yes");
}
function OW_AllocationExchange(fundId) {
    var url = window.AppPath + '/pages/popups/AllocationExchange.aspx?fundId=' + fundId;
    return OW_OpenInCenter(url, 800, 450, "scrollbars=yes");
}
function OW_AllocationExchange_CapitalCommitment(fundId) {
    var url = window.AppPath + '/pages/popups/AllocationExchange.aspx?fundId=' + fundId + '&isCapitalCommitment = 1';
    return OW_OpenInCenter(url, 800, 450, "scrollbars=yes");
}
function OW_AllocationTransferIfsTo3rdParty(fundId, transferOutId) {
    var url = window.AppPath + '/pages/popups/AllocationTransfer.aspx?fundId=' + fundId + '&administeredBy=0';
    if (transferOutId)
        url += '&transferOutId=' + transferOutId;
    return OW_OpenInCenter(url, 750, 450, "scrollbars=yes");
}
function OW_AllocationTransferIfsToIfs(portfolioId, fundId, transferOutId, transferType) {
    var url = window.AppPath + '/pages/popups/AllocationTransfer.aspx?fromPortfolioId=' + portfolioId + '&fundId=' + fundId + '&administeredBy=1';
    if (transferOutId)
        url += '&transferOutId=' + transferOutId;
    if (transferType)
        url += '&transferType=' + transferType;
    return OW_OpenInCenter(url, 750, 450, "scrollbars=yes");
}

function OW_AllocationTransfer3rdPartyToIfs(fundId, transferInId) {
    if (transferInId)
        return OW_AllocationEdit(transferInId, 2);
    else
        return OW_AllocationSubscription(fundId, true, 2);
}

function OW_AllocationEqualizationEdit(fundId, allocationId) {
    var url = window.AppPath + '/pages/popups/EqualizationSubscription.aspx?fundId=' + fundId + '&equalizationAllocationId=' + allocationId;
    return OW_OpenInCenter(url, 450, 410, "scrollbars=yes");
}

function OW_AllocationExchangeEdit(fundId, exchangeOutId, exchangeInId) {
    var url = window.AppPath + '/pages/popups/AllocationExchange.aspx?fundId=' + fundId + '&exchangeOutId=' + exchangeOutId + '&exchangeInId=' + exchangeInId;
    return OW_OpenInCenter(url, 850, 450, "scrollbars=yes");
}
function OW_ActivityReport(fundId) {
    var url = window.AppPath + '/pages/popups/ActivityReport.aspx?fundId=' + fundId;
    return OW_OpenInCenter(url, 730, 367);
}

function OW_CashActivityReport(portfolioId) {
    var url = window.AppPath + '/pages/reports/ReportCashActivity.aspx?portfolioId=' + portfolioId;
    return OW_OpenInCenter(url, 800, 600);
}
function OW_EditReturns(fundId, endDate) {
    if (!isDate(endDate, 'MM/dd/yyyy')) {
        var errorString = 'Invalid date is entered.\nDate format should be "mm/dd/yyyy"\nPlease correct and submit again.';
        alert(errorString);
        return false;
    }

    var url = window.AppPath + '/pages/popups/ReturnsEdit.aspx?fundId=' + fundId + '&endDate=' + endDate;
    return OW_OpenInCenter(url, 700, 275);
}
function FT_GoToDetail(fundId) {
    var dd = getElementByClass('ddlClassSeriesSide');
    for (var i = 0; i < dd.options.length; i++) {
        if (dd.options[i].value == fundId) {
            dd.selectedIndex = i;
            dd.onchange();
            return;
        }
    }
    alert('Error: bad fundId ' + fundId);
}

function getElementByClass(theClass) {
    var allHTMLTags = document.getElementsByTagName("*");
    for (var i = 0; i < allHTMLTags.length; i++) {        
        if (allHTMLTags[i].className == theClass) {
            return allHTMLTags[i];
        }
    }
    return null;
}

function OW_ViewPortfolioLockdown(portfolioId) {
    var url = window.AppPath + '/pages/popups/ViewPortfolioLockdown.aspx?PortfolioId=' + portfolioId;
    return OW_OpenInCenter(url, 300, 290);
}

function OW_PortfolioLockdown(portfolioId) {
    var url = window.AppPath + '/pages/popups/PortfolioLockdown.aspx?PortfolioId=' + portfolioId;
    return OW_OpenInCenter(url, 300, 300);
}

//Home
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function OW_ClickComparisonQuickSearch(comparisionId, isModify) {
    var url = window.AppPath + "/pages/popups/ComparisonQuickSearch.aspx?callbackFunction=OnSearchReturn&compID=%0&isModify=%1".merge(comparisionId, isModify);
    OW_OpenInCenter(url, 825, 600);
}

function OW_ClickOpenTrades() {
    var url = window.AppPath + "/pages/portfolio/TradeActivity.aspx";
    window.location.href = url;
}

function OW_ClickTradeHistory(tradeOrderId) {
    var url = window.AppPath + "/pages/popups/TradeOrderHistoryPopup.aspx?tradeOrderID=%0".merge(tradeOrderId);
    OW_OpenInCenter(url, 1100, 350);
    return false;
}

function OW_EditTrade(tradeOrderId, fundId) {
    var url = window.AppPath + "/pages/popups/TradeOrderPopup.aspx?tradeOrderID=%0&fundID=%1".merge(tradeOrderId, fundId);
    OW_OpenInCenter(url, 500, 400);
    return false;
}

function OW_EditRedemptionTrade(tradeOrderId, fundId) {
    var url = window.AppPath + "/pages/popups/TradeOrderRedemption.aspx?tradeOrderID=%0&fundID=%1".merge(tradeOrderId, fundId);
    OW_OpenInCenter(url, 500, 400);
    return false;
}

function OW_EditContributionTrade(tradeOrderId, fundId) {
    var url = window.AppPath + "/pages/popups/TradeOrderContribution.aspx?tradeOrderID=%0&fundID=%1".merge(tradeOrderId, fundId);
    OW_OpenInCenter(url, 500, 400);
    return false;
}

function OW_EditExchangeTrade(tradeOrderId, fundId) {
    var url = window.AppPath + "/pages/popups/TradeOrderExchange.aspx?tradeOrderID=%0&fundID=%1".merge(tradeOrderId, fundId);
    OW_OpenInCenter(url, 500, 400);
    return false;
}

function OW_EditTransferTrade(tradeOrderId, fundId) {
    var url = window.AppPath + "/pages/popups/TradeOrderTransfer.aspx?tradeOrderID=%0&fundID=%1".merge(tradeOrderId, fundId);
    OW_OpenInCenter(url, 500, 400);
    return false;
}

function OW_NewTrade(fundId, tradeType) {
    var url = window.AppPath;
    switch (tradeType) {
        case 'REDEMPTION':
            url += "/pages/popups/TradeOrderRedemption.aspx?fundID=%0".merge(fundId);
            break;
        case 'EXCHANGE':
            url += "/pages/popups/TradeOrderExchange.aspx?fundID=%0".merge(fundId);
            break;

        default:
            url += "/pages/popups/TradeOrderPopup.aspx?fundID=%0&tradeOrderType=%1".merge(fundId, tradeType);
            break;

    }
    OW_OpenInCenter(url, 500, 400);
}

//UCAddress
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function ShowCompanyDetailsForFund(companyId, activeEffectiveDate) {
    var url = window.AppPath;
    if (activeEffectiveDate!=null)
        url += "/pages/popups/CompanyDetailPopup.aspx?companyId=%0&attributeGroupId=%1&effectiveDate=%2".merge(companyId, 21, activeEffectiveDate);
    else
        url += "/pages/popups/CompanyDetailPopup.aspx?companyId=%0&attributeGroupId=%1".merge(companyId, 21);
    OW_OpenInCenter(url, 340, 510);
}

//UCContact
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function OW_ShowCompanyDetails(companyId, attributeGroupId) {
    OW_ShowCompanyDetailsEx(companyId, attributeGroupId, true);
}
function OW_ShowCompanyDetailsEx(companyId, attributeGroupId, canEdit) {
    var url = window.AppPath + "/pages/popups/CompanyDetailPopup.aspx?companyId=%0&attributeGroupId=%1&canEdit=%2".merge(companyId, attributeGroupId, canEdit);
    OW_OpenInCenter(url, 340, 510);
    return false;
}

function OW_ShowContactDetails(contactId, companyId) {
    return OW_ShowContactDetailsEx(contactId, companyId, true);
}
function OW_ShowContactDetailsEx(contactId, companyId, canEdit) {
    var url = window.AppPath + "/pages/popups/ContactDetailPopup.aspx?contactId=%0&companyId=%1&canEdit=%2".merge(contactId, companyId, canEdit);
    OW_OpenInCenter(url, 325, 180);
    return false;
}

//UCDueDiligence
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function OW_ClickEditNote(noteId, fundId, hdnButtonId) {
    var url = window.AppPath + "/pages/popups/NotePopup.aspx?NOTE_ID=%0&FUND_ID=%1&HIDDEN_BUTTON_ID=%2".merge(noteId, fundId, hdnButtonId);
    OW_OpenInCenter(url, 370, 310);
    return false;
}

// UCFeesTerms
function OW_ClickNewFeeTerm(fundId, isDuplicate) {
    var url = window.AppPath + "/pages/popups/AddFundOrPortfolioClass.aspx";
    if (null != fundId)
    { url += '?fundId=' + fundId; }
    if (isDuplicate != null) { url += '&isDuplicate=' + isDuplicate; }
    OW_OpenInCenter(url, 330, 240);
}
function OW_ClickSideFeeTerm(fundId, hdnButtonId) {
    var url = window.AppPath + "/pages/popups/ClassSeriesSidePopup.aspx?FUND_ID=%0&HIDDEN_BUTTON_ID=%1&CALLBACK_FUNCTION=UCFeesTerms_Reload".merge(fundId, hdnButtonId);
    return OW_OpenInCenter(url, 425, 125);
}
function OW_ClickNewFeeTermDisableControls(fundId) {
    var url = window.AppPath + "/pages/popups/AddFundOrPortfolioClass.aspx";
    if (null != fundId)
    { url += '?fundId=' + fundId; }
    url += '&disableControl=true';
    OW_OpenInCenter(url, 330, 240);
}

//Fund-Maintain
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function OW_ShowFundPopup(fundId, isEditFund) {
    var url;
    if (isEditFund == true) {
        url = window.AppPath + "/pages/popups/FundPopup.aspx?FundId=%0&CallbackFunction=OnNewFund&IsEditFund=%1".merge(fundId, isEditFund);
    } else {
        url = window.AppPath + "/pages/popups/FundPopup.aspx?IsEditFund=%0&CallbackFunction=OnNewFund".merge(isEditFund);
    }
    OW_OpenInCenter(url, 390, 305);
}

function OW_ShowNewHedgeFundPopup(fundId, isEditFund) {
    var url;
    if (isEditFund == true) {
        url = window.AppPath + "/pages/popups/FundPopup.aspx?FundId=%0&CallbackFunction=OnNewFund&IsEditFund=%1&IsHedgeFund=1".merge(fundId, isEditFund);
    } else {
        url = window.AppPath + "/pages/popups/FundPopup.aspx?IsEditFund=%0&CallbackFunction=OnNewFund&IsHedgeFund=1".merge(isEditFund);
    }
    OW_OpenInCenter(url, 390, 305);
}

function OW_ShowSecurityPopup(fundId) {
    var url;
    if (fundId > 0) {
        url = window.AppPath + "/pages/popups/GSM/SecurityPopup.aspx?FundId=%0&CallbackFunction=OnNewFund".merge(fundId);
    } else {
        url = window.AppPath + "/pages/popups/GSM/SecurityPopup.aspx?CallbackFunction=OnNewFund";
    }
    OW_OpenInCenter(url, 390, 305);
}

function OW_ShowFundSeriesPopup(seriesId, fromSubscriptionScreen, basefundId, fundClassAbstractId, tradeOrderId) {
    var url = window.AppPath + "/pages/popups/SeriesAddEdit.aspx?seriesId=%0".merge(seriesId);
    if (fromSubscriptionScreen) {
        url += "&fromSubscriptionScreen=true";
        url += "&basefundId=" + basefundId;
        url += "&fundClassAbstractId=" + fundClassAbstractId;
        url += "&tradeOrderId=" + tradeOrderId;
    }
    OW_OpenInCenter(url, 550, 500);
}
function OW_EditAggregateBenchmarks(fundId, aggregateId, portfolioId) {
    var url = window.AppPath + "/pages/popups/BenchmarksAssign.aspx?fundId=%0&aggregateId=%1&portfolioId=%2".merge(fundId, aggregateId, portfolioId);
    OW_OpenInCenter(url, 700, 300);
}

//Key Persons
function OW_ShowKeyPersonsSearch() {
    var url = window.AppPath + "/pages/popups/KeyPersonPopup.aspx";
    OW_OpenInCenter(url, 550, 265, 'status=no');
}

function OW_ShowGlobalKeyPersonsSearch() {
    var url = window.AppPath + "/pages/popups/GlobalKeyPersonPopup.aspx";
    OW_OpenInCenter(url, 550, 265, 'status=no');
}

function OW_ShowGlobalContactDetails(contactPersonId) {
    var url = window.AppPath + "/pages/popups/GlobalContactDetailPopup.aspx?contactId=%0".merge(contactPersonId);
    OW_OpenInCenter(url, 325, 180);
    return false;
}

//Portfolio
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function OW_ShowNewPortfolioPopup(isEdit) {
    var url = window.AppPath + "/pages/popups/PortfolioPopup.aspx?CallbackFunction=OnPortfolioNew&Edit=%0".merge(isEdit);
    OW_OpenInCenter(url, 420, 360);
}

//Merge Clients
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function OW_ShowMergeClientsPopup(organizationId) {
    var url = window.AppPath + "/pages/admin/popups/MergeClients.aspx?organizationId=%0".merge(organizationId);
    OW_OpenInCenter(url, 760, 350, null, null, 'no');
}

//Benchmark
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function OW_ShowBenchmark(fundId) {
    var url = window.AppPath + "/pages/popups/BenchmarkPopup.aspx?CallbackFunction=OnSaveCustomBenchmark";
    if (fundId != null)
        url += "&fundid=%0".merge(fundId);
    OW_OpenInCenter(url, 600, 360, "scrollbars=no");
}

function OW_OpenBenchmarkReport() {
    var url = window.AppPath + "/pages/reports/BenchmarkReport.aspx";
    OW_OpenInCenter(url, 520, 550, "scrollbars=no");
}

function OW_CommentsPopup(allocationId, showComments) {
    var url = window.AppPath + "/pages/popups/CommentsHistoryPopup.aspx?AllocationId=" + allocationId + "&showComments=" + showComments;
    OW_OpenInCenter(url, 700, 300);
    return false;
}
function OW_UnlockCommentsPopup(lockdownId) {
    var url = window.AppPath + "/pages/popups/LockdownComments.aspx?lockdownId=" + lockdownId;
    OW_OpenInCenter(url, 700, 300);
    return false;
}

function OW_CreditProviderHistoryPopup(fundId) {
    var url = window.AppPath + "/pages/popups/CreditProviderHistoryPopup.aspx?fundId=" + fundId;
    OW_OpenInCenter(url, 750, 300);
    return false;
}

//Notes Fields Popups
function OW_NotesPopup(hash) {
    var url = window.AppPath + "/pages/popups/ViewNotes.aspx?hash=" + hash;
    OW_OpenInCenter(url, 350, 225);
    return false;
}

//Admin
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

function OW_UserPopup(userName, isActiveFlag, mode) {
    var url = window.AppPath + "/pages/admin/popups/UserPopup.aspx?UserName=%0".merge(userName);
    url = url + "&isActive=" + isActiveFlag + "&Mode=" + mode;
    OW_OpenInCenter(url, 910, 425);
    return false;
}

function OW_OrganizationPopup(organizationId) {
    var url = window.AppPath + "/pages/admin/popups/OrganizationPopup.aspx?OrganizationID=%0".merge(organizationId);
    OW_OpenInCenter(url, 565, 400);
    return false;
}

function OW_CorporateActionChecklistPopup(corporateActionId, checklistId) {
    var url = window.AppPath + "/pages/popups/CorporateActionsChecklist.aspx?corporateActionId=" + corporateActionId + "&checklistId=" + checklistId;
    OW_OpenInCenter(url, 830, 860, "scrollbars=yes");
    return false;
}

function OW_ChecklistPopup(path, allocationId, checklistId, fundId) {
    var url = window.AppPath + path + "?allocationID=" + allocationId + "&checklistId=" + checklistId + "&fundId=" + fundId;
    OW_OpenInCenter(url, 840, 860, "scrollbars=yes");
    return false;
}

String.prototype.startsWith = function (chr) {
    var seg = this.substring(0, chr.length);
    return (seg == chr);
};
String.prototype.startswith = String.prototype.startsWith;

String.prototype.endsWith = function (chr) {
    var seg = this.substring(this.length - chr.length);
    return (seg == chr);
};
String.prototype.endswith = String.prototype.endsWith;

/**
* Usage:
*   "My %0 is good. Good %0!".merge("Dog");
*/
String.prototype.merge = function () {
    var argv = arguments;
    var argc = arguments.length;
    var output = this.toString();

    if (argc == 1) {
        if (typeof argv[0] == 'object' && argv[0] instanceof Array) {
            argv = argv[0];
            argc = argv.length;
        }
    }
    for (var i = 0; i < argc; i++) {
        // Get the value from the arg list. If the entry is a function execute it
        // and use it's results as the value to use.
        var value = (typeof argv[i] == 'function') ? argv[i]() : argv[i];
        // Replace all instances of the %N in the template with the derived Value (see above).
        output = output.replace(new RegExp("%" + i, "g"), value);
    }
    return output;
};
/* returns the string with leading whitespace removed */
String.prototype.trimLeft = function () {
    return this.replace(/^\s+/, '');
};
/* returns the string with trailing whitespace removed */
String.prototype.trimRight = function () {
    return this.replace(/\s+$/, '');
};
/* returns the string with leading and trailing whitespace removed */
String.prototype.trim = function () {
    return this.replace(/^\s+|\s+$/g, '');
};
/* returns the string with [value] inserted at position [idx] */
String.prototype.insert = function (idx, value) {
    return this.slice(0, idx) + value + this.slice(idx);
};
/* returns the string with characters from [idx1] up to but not 
including [idx2] removed */
String.prototype.strip = function (idx1, idx2) {
    if (arguments.length == 1) idx2 = this.length;
    return this.slice(0, idx1) + this.slice(idx2);
};
/* returns the string with characters from [idx] up to but not including 
[idx]+[count] removed, and [value] inserted at [idx]

the original string is not modified (as opposed to Array.splice)*/
String.prototype.splice = function (idx, count, value) {
    return this.strip(idx, idx + count).insert(idx, value);
};
/* subArgs(value_0 [,...,value_n])
returns string with occurrences of {n} replaced with [value_n] */
String.prototype.subArgs = function () {
    var args = arguments;
    return this.replace(/\{(\d+)\}/g, function (s, i) { return args[i]; });
    //	return this.replace(/(?:^|[^\\])\{(\d+)\}/g, function(s,i){return args[i]} ).replace(/\\\{/g, '{' );
    //  does not replace when { is preceded by a \ [str notation: '\\{...'] . Doesn't sound necessary
};
String.prototype.format = String.prototype.subArgs;
/* returns string with occurences of {key} replaced by dict['key']
undefined keys are not changed */
String.prototype.subDict = function (dict) {
    return this.replace(/\{(\w+)\}/g, function (s, k) { return !isUndefined(dict[k]) ? dict[k] : s; });
};
/* wrap(left [, right]);
returns string wrapped in [left] and [right]; right=left if not provided;*/
String.prototype.wrap = function (left, right) {
    if (undef(left)) throw 'S.wrap takes 1 argument (none given)';
    if (undef(right)) right = left;
    return left + this + right;
};
/* returns string quoted in double quotes */
String.prototype.quote = function () {
    return this.wrap('"');
};
/* returns string quoted in single quotes */
String.prototype.squote = function () {
    return this.wrap("'");
};
/* TODO: doc */
String.prototype.pad = function (side, len, chr) {
    if (undef(chr)) chr = ' ';
    var s = this;
    var left = side.toLowerCase() == 'left';
    while (s.length < len) s = left ? chr + s : s + chr;
    return s;
};
/* TODO: doc */
String.prototype.padLeft = function (len, chr) {
    return this.pad('left', len, chr);
};
/* TODO: doc */
String.prototype.padRight = function (len, chr) {
    return this.pad('right', len, chr);
};
/* return string left filled with 0s to match length [len] */
String.prototype.zerofill = function (len) {
    var s = this;
    var ix = /^[+-]/.test(s) ? 1 : 0;
    while (s.length < len) s = s.insert(ix, '0');
    return s;
};
/* isEmpty([donttrim])
true if string contains no characters.
unless [donttrim] is specified and set to True, the string is trimmed before
testing*/
String.prototype.isEmpty = function (donttrim) {
    return !(donttrim ? this : this.trim()).length;
};
/***********************************************
* Cool DHTML tooltip script- © Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
* http://www.dynamicdrive.com/dynamicindex5/dhtmltooltip.htm
***********************************************/

document.write('<div id="dhtmltooltip"></div>');
//write out tooltip DIV

var offsetxpoint = -10;
//Customize x offset of tooltip
var offsetypoint = 10;
//Customize y offset of tooltip
var ie = document.all;
var ns6 = document.getElementById && !document.all;
var enabletip = false;
if (ie || ns6)
    var tipobj = document.all ? document.all["dhtmltooltip"] : document.getElementById ? document.getElementById("dhtmltooltip") : "";

function ietruebody() {
    return (document.compatMode && document.compatMode != "BackCompat") ? document.documentElement : document.body;
}

function ddrivetip(thetext, thecolor, thewidth) {
    if (ns6 || ie) {
        if (typeof thewidth != "undefined") tipobj.style.width = thewidth + "px";
        if (typeof thecolor != "undefined" && thecolor != "") tipobj.style.backgroundColor = thecolor;
        tipobj.innerHTML = thetext;
        enabletip = true;
        return false;
    }
}

function positiontip(e) {
    if (enabletip) {
        var curX = (ns6) ? e.pageX : event.clientX + ietruebody().scrollLeft;
        var curY = (ns6) ? e.pageY : event.clientY + ietruebody().scrollTop;
        //Find out how close the mouse is to the corner of the window
        var rightedge = ie && !window.opera ? ietruebody().clientWidth - event.clientX - offsetxpoint : window.innerWidth - e.clientX - offsetxpoint - 20;
        var bottomedge = ie && !window.opera ? ietruebody().clientHeight - event.clientY - offsetypoint : window.innerHeight - e.clientY - offsetypoint - 20;
        var leftedge = (offsetxpoint < 0) ? offsetxpoint * (-1) : -1000; //if the horizontal distance isn't enough to accomodate the width of the context menu
        if (rightedge < tipobj.offsetWidth)
        //move the horizontal position of the menu to the left by it's width
            tipobj.style.left = ie ? ietruebody().scrollLeft + event.clientX - tipobj.offsetWidth + "px" : window.pageXOffset + e.clientX - tipobj.offsetWidth + "px";
        else if (curX < leftedge)
            tipobj.style.left = "5px";
        else
        //position the horizontal position of the menu where the mouse is positioned
            tipobj.style.left = curX + offsetxpoint + "px"; //same concept with the vertical position
        if (bottomedge < tipobj.offsetHeight)
            tipobj.style.top = ie ? ietruebody().scrollTop + event.clientY - tipobj.offsetHeight - offsetypoint + "px" : window.pageYOffset + e.clientY - tipobj.offsetHeight - offsetypoint + "px";
        else
            tipobj.style.top = curY + offsetypoint + "px";
        tipobj.style.visibility = "visible";
    }
}

function hideddrivetip() {
    if (ns6 || ie) {
        enabletip = false;
        tipobj.style.visibility = "hidden";
        tipobj.style.left = "-1000px";
        tipobj.style.backgroundColor = '';
        tipobj.style.width = '';
    }
}

document.onmousemove = positiontip;
/* --- BoxOver ---
/* --- v 2.1 17th June 2006
By Oliver Bryant with help of Matthew Tagg
http://boxover.swazz.org */

if (typeof document.attachEvent != 'undefined') {
    window.attachEvent('onload', init);
    document.attachEvent('onmousemove', moveMouse);
    document.attachEvent('onclick', checkMove);
}
else {
    window.addEventListener('load', init, false);
    document.addEventListener('mousemove', moveMouse, false);
    document.addEventListener('click', checkMove, false);
}

var oDv = document.createElement("div");
var dvHdr = document.createElement("div");
var dvBdy = document.createElement("div");
var windowlock, boxMove, fixposx, fixposy, lockX, lockY, fixx, fixy, ox, oy, boxLeft, boxRight, boxTop, boxBottom, evt, mouseX, mouseY, boxOpen, totalScrollTop, totalScrollLeft;
boxOpen = false;
ox = 10;
oy = 10;
lockX = 0;
lockY = 0;

function init() {
    oDv.appendChild(dvHdr);
    oDv.appendChild(dvBdy);
    oDv.style.position = "absolute";
    oDv.style.visibility = 'hidden';
    document.body.appendChild(oDv);
}

function defHdrStyle() {
    dvHdr.innerHTML = '<img  style="vertical-align:middle"  src="info.gif">&nbsp;&nbsp;' + dvHdr.innerHTML;
    dvHdr.style.fontWeight = 'bold';
    dvHdr.style.width = '150px';
    dvHdr.style.fontFamily = 'arial';
    dvHdr.style.border = '1px solid #A5CFE9';
    dvHdr.style.padding = '3';
    dvHdr.style.fontSize = '11';
    dvHdr.style.color = '#4B7A98';
    dvHdr.style.background = '#D5EBF9';
    dvHdr.style.filter = 'alpha(opacity=85)'; // IE
    dvHdr.style.opacity = '0.85'; // FF
}

function defBdyStyle() {
    dvBdy.style.borderBottom = '1px solid #A5CFE9';
    dvBdy.style.borderLeft = '1px solid #A5CFE9';
    dvBdy.style.borderRight = '1px solid #A5CFE9';
    dvBdy.style.width = '150px';
    dvBdy.style.fontFamily = 'arial';
    dvBdy.style.fontSize = '11';
    dvBdy.style.padding = '3';
    dvBdy.style.color = '#1B4966';
    dvBdy.style.background = '#FFFFFF';
    dvBdy.style.filter = 'alpha(opacity=85)'; // IE
    dvBdy.style.opacity = '0.85'; // FF
}

function checkElemBO(txt) {
    if (!txt || typeof (txt) != 'string') return false;
    if ((txt.indexOf('header') > -1) && (txt.indexOf('body') > -1) && (txt.indexOf('[') > -1) && (txt.indexOf('[') > -1))
        return true;
    else
        return false;
}

function scanBO(curNode) {
    if (checkElemBO(curNode.title)) {
        curNode.boHDR = getParam('header', curNode.title);
        curNode.boBDY = getParam('body', curNode.title);
        curNode.boCSSBDY = getParam('cssbody', curNode.title);
        curNode.boCSSHDR = getParam('cssheader', curNode.title);
        curNode.IEbugfix = (getParam('hideselects', curNode.title) == 'on') ? true : false;
        curNode.fixX = parseInt(getParam('fixedrelx', curNode.title));
        curNode.fixY = parseInt(getParam('fixedrely', curNode.title));
        curNode.absX = parseInt(getParam('fixedabsx', curNode.title));
        curNode.absY = parseInt(getParam('fixedabsy', curNode.title));
        curNode.offY = (getParam('offsety', curNode.title) != '') ? parseInt(getParam('offsety', curNode.title)) : 10;
        curNode.offX = (getParam('offsetx', curNode.title) != '') ? parseInt(getParam('offsetx', curNode.title)) : 10;
        curNode.fade = (getParam('fade', curNode.title) == 'on') ? true : false;
        curNode.fadespeed = (getParam('fadespeed', curNode.title) != '') ? getParam('fadespeed', curNode.title) : 0.04;
        curNode.delay = (getParam('delay', curNode.title) != '') ? parseInt(getParam('delay', curNode.title)) : 0;
        if (getParam('requireclick', curNode.title) == 'on') {
            curNode.requireclick = true;
            document.all ? curNode.attachEvent('onclick', showHideBox) : curNode.addEventListener('click', showHideBox, false);
            document.all ? curNode.attachEvent('onmouseover', hideBox) : curNode.addEventListener('mouseover', hideBox, false);
        }
        else {// Note : if requireclick is on the stop clicks are ignored   			
            if (getParam('doubleclickstop', curNode.title) != 'off') {
                document.all ? curNode.attachEvent('ondblclick', pauseBox) : curNode.addEventListener('dblclick', pauseBox, false);
            }
            if (getParam('singleclickstop', curNode.title) == 'on') {
                document.all ? curNode.attachEvent('onclick', pauseBox) : curNode.addEventListener('click', pauseBox, false);
            }
        }
        curNode.windowLock = getParam('windowlock', curNode.title).toLowerCase() == 'off' ? false : true;
        curNode.title = '';
        curNode.hasbox = 1;
    }
    else
        curNode.hasbox = 2;
}

function getParam(param, list) {
    var reg = new RegExp('([^a-zA-Z]' + param + '|^' + param + ')\\s*=\\s*\\[\\s*(((\\[\\[)|(\\]\\])|([^\\]\\[]))*)\\s*\\]');
    var res = reg.exec(list);
    if (res)
        return res[2].replace('[[', '[').replace(']]', ']');
    else
        return '';
}

function Left(elem) {
    var x = 0;
    if (elem.calcLeft)
        return elem.calcLeft;
    var oElem = elem;
    while (elem) {
        if ((elem.currentStyle) && (!isNaN(parseInt(elem.currentStyle.borderLeftWidth))) && (x != 0))
            x += parseInt(elem.currentStyle.borderLeftWidth);
        x += elem.offsetLeft;
        elem = elem.offsetParent;
    }
    oElem.calcLeft = x;
    return x;
}

function Top(elem) {
    var x = 0;
    if (elem.calcTop)
        return elem.calcTop;
    var oElem = elem;
    while (elem) {
        if ((elem.currentStyle) && (!isNaN(parseInt(elem.currentStyle.borderTopWidth))) && (x != 0))
            x += parseInt(elem.currentStyle.borderTopWidth);
        x += elem.offsetTop;
        elem = elem.offsetParent;
    }
    oElem.calcTop = x;
    return x;
}

var ah, ab;
function applyStyles() {
    if (ab)
        oDv.removeChild(dvBdy);
    if (ah)
        oDv.removeChild(dvHdr);
    dvHdr = document.createElement("div");
    dvBdy = document.createElement("div");
    CBE.boCSSBDY ? dvBdy.className = CBE.boCSSBDY : defBdyStyle();
    CBE.boCSSHDR ? dvHdr.className = CBE.boCSSHDR : defHdrStyle();
    dvHdr.innerHTML = CBE.boHDR;
    dvBdy.innerHTML = CBE.boBDY;
    ah = false;
    ab = false;
    if (CBE.boHDR != '') {
        oDv.appendChild(dvHdr);
        ah = true;
    }
    if (CBE.boBDY != '') {
        oDv.appendChild(dvBdy);
        ab = true;
    }
}

var CSE, iterElem, LSE, CBE, LBE, totalScrollLeft, totalScrollTop, width, height;
var ini = false;

// Customised function for inner window dimension
function SHW() {
    if (document.body && (document.body.clientWidth != 0)) {
        width = document.body.clientWidth;
        height = document.body.clientHeight;
    }
    if (document.documentElement && (document.documentElement.clientWidth != 0) && (document.body.clientWidth + 20 >= document.documentElement.clientWidth)) {
        width = document.documentElement.clientWidth;
        height = document.documentElement.clientHeight;
    }
    return [width, height];
}


var ID = null;
function moveMouse(e) {
    //boxMove=true;
    e ? evt = e : evt = event;

    CSE = evt.target ? evt.target : evt.srcElement;

    if (!CSE.hasbox) {
        // Note we need to scan up DOM here, some elements like TR don't get triggered as srcElement
        iElem = CSE;
        while ((iElem.parentNode) && (!iElem.hasbox)) {
            scanBO(iElem);
            iElem = iElem.parentNode;
        }
    }

    if ((CSE != LSE) && (!isChild(CSE, dvHdr)) && (!isChild(CSE, dvBdy))) {
        if (!CSE.boxItem) {
            iterElem = CSE;
            while ((iterElem.hasbox == 2) && (iterElem.parentNode))
                iterElem = iterElem.parentNode;
            CSE.boxItem = iterElem;
        }
        iterElem = CSE.boxItem;
        if (CSE.boxItem && (CSE.boxItem.hasbox == 1)) {
            LBE = CBE;
            CBE = iterElem;
            if (CBE != LBE) {
                applyStyles();
                if (!CBE.requireclick)
                    if (CBE.fade) {
                        if (ID != null)
                            clearTimeout(ID);
                        ID = setTimeout("fadeIn(" + CBE.fadespeed + ")", CBE.delay);
                    }
                    else {
                        if (ID != null)
                            clearTimeout(ID);
                        COL = 1;
                        ID = setTimeout("oDv.style.visibility='visible';ID=null;", CBE.delay);
                    }
                if (CBE.IEbugfix) { hideSelects(); }
                fixposx = !isNaN(CBE.fixX) ? Left(CBE) + CBE.fixX : CBE.absX;
                fixposy = !isNaN(CBE.fixY) ? Top(CBE) + CBE.fixY : CBE.absY;
                lockX = 0;
                lockY = 0;
                boxMove = true;
                ox = CBE.offX ? CBE.offX : 10;
                oy = CBE.offY ? CBE.offY : 10;
            }
        }
        else if (!isChild(CSE, dvHdr) && !isChild(CSE, dvBdy) && (boxMove)) {
            // The conditional here fixes flickering between tables cells.
            if ((!isChild(CBE, CSE)) || (CSE.tagName != 'TABLE')) {
                CBE = null;
                if (ID != null)
                    clearTimeout(ID);
                fadeOut();
                //showSelects();
            }
        }
        LSE = CSE;
    }
    else if (((isChild(CSE, dvHdr) || isChild(CSE, dvBdy)) && (boxMove))) {
        totalScrollLeft = 0;
        totalScrollTop = 0;

        iterElem = CSE;
        while (iterElem) {
            if (!isNaN(parseInt(iterElem.scrollTop)))
                totalScrollTop += parseInt(iterElem.scrollTop);
            if (!isNaN(parseInt(iterElem.scrollLeft)))
                totalScrollLeft += parseInt(iterElem.scrollLeft);
            iterElem = iterElem.parentNode;
        }
        if (CBE != null) {
            boxLeft = Left(CBE) - totalScrollLeft;
            boxRight = parseInt(Left(CBE) + CBE.offsetWidth) - totalScrollLeft;
            boxTop = Top(CBE) - totalScrollTop;
            boxBottom = parseInt(Top(CBE) + CBE.offsetHeight) - totalScrollTop;
            doCheck();
        }
    }

    if (boxMove && CBE) {
        // This added to alleviate bug in IE6 w.r.t DOCTYPE
        bodyScrollTop = document.documentElement && document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop;
        bodyScrollLet = document.documentElement && document.documentElement.scrollLeft ? document.documentElement.scrollLeft : document.body.scrollLeft;
        mouseX = evt.pageX ? evt.pageX - bodyScrollLet : evt.clientX - document.body.clientLeft;
        mouseY = evt.pageY ? evt.pageY - bodyScrollTop : evt.clientY - document.body.clientTop;
        if ((CBE) && (CBE.windowLock)) {
            mouseY < -oy ? lockY = -mouseY - oy : lockY = 0;
            mouseX < -ox ? lockX = -mouseX - ox : lockX = 0;
            mouseY > (SHW()[1] - oDv.offsetHeight - oy) ? lockY = -mouseY + SHW()[1] - oDv.offsetHeight - oy : lockY = lockY;
            mouseX > (SHW()[0] - dvBdy.offsetWidth - ox) ? lockX = -mouseX - ox + SHW()[0] - dvBdy.offsetWidth : lockX = lockX;
        }
        oDv.style.left = ((fixposx) || (fixposx == 0)) ? fixposx : bodyScrollLet + mouseX + ox + lockX + "px";
        oDv.style.top = ((fixposy) || (fixposy == 0)) ? fixposy : bodyScrollTop + mouseY + oy + lockY + "px";

    }
}

function doCheck() {
    if ((mouseX < boxLeft) || (mouseX > boxRight) || (mouseY < boxTop) || (mouseY > boxBottom)) {
        if (!CBE.requireclick)
            fadeOut();
        if (CBE.IEbugfix) { showSelects(); }
        CBE = null;
    }
}

function pauseBox(e) {
    e ? evt = e : evt = event;
    boxMove = false;
    evt.cancelBubble = true;
}

function showHideBox(e) {
    oDv.style.visibility = (oDv.style.visibility != 'visible') ? 'visible' : 'hidden';
}

function hideBox(e) {
    oDv.style.visibility = 'hidden';
}

var COL = 0;
var stopfade = false;
function fadeIn(fs) {
    ID = null;
    COL = 0;
    oDv.style.visibility = 'visible';
    fadeIn2(fs);
}

function fadeIn2(fs) {
    COL = COL + fs;
    COL = (COL > 1) ? 1 : COL;
    oDv.style.filter = 'alpha(opacity=' + parseInt(100 * COL) + ')';
    oDv.style.opacity = COL;
    if (COL < 1)
        setTimeout("fadeIn2(" + fs + ")", 20);
}

function fadeOut() {
    oDv.style.visibility = 'hidden';
}

function isChild(s, d) {
    while (s) {
        if (s == d)
            return true;
        s = s.parentNode;
    }
    return false;
}

var cSrc;
function checkMove(e) {
    e ? evt = e : evt = event;
    cSrc = evt.target ? evt.target : evt.srcElement;
    if ((!boxMove) && (!isChild(cSrc, oDv))) {
        fadeOut();
        if (CBE && CBE.IEbugfix) { showSelects(); }
        boxMove = true;
        CBE = null;
    }
}

function showSelects() {
    var elements = document.getElementsByTagName("select");
    for (var i = 0; i < elements.length; i++) {
        elements[i].style.visibility = 'visible';
    }
}

function hideSelects() {
    var elements = document.getElementsByTagName("select");
    for (var i = 0; i < elements.length; i++) {
        elements[i].style.visibility = 'hidden';
    }
}

function ShowObjSelects(obj) {
    var elements = obj.getElementsByTagName("select");
    for (var i = 0; i < elements.length; i++) {
        elements[i].style.visibility = 'visible';
    }
} ////////////////////////////////////////////////////////////////////////
//								     //
//////////////////////////////////////////////////////////////////////


function RegisterToolTip(aElement, aMsg, aStyle) {

    var el = document.getElementById(aElement);

    if (el != null) {
        if (aStyle != "") {
            el.className = aStyle;
        }
        if (aMsg != "") {
            el.tooltip = aMsg;
        }
    }

}

///////////////////////////////////////////////////////////////////////
//     This Tooltip was designed by Erik Arvidsson for WebFX         //
//                                                                   //
//     For more info and examples see: http://www.eae.net/webfx/     //
//     or contact Erik at http://webfx.eae.net/contact.html#erik     //
//                                                                   //
//     Feel free to use this code as lomg as this disclaimer is      //
//     intact.                                                       //
///////////////////////////////////////////////////////////////////////

var delayTime = 700;
var showTime = 5000;

//var tooltipDefaultStyle = "background: infobackground; color: infotext; font: statusbar; padding: 1; border: 1 solid black; position: absolute; z-index: 99; visibility: hidden;";
var tooltipDefaultStyle = "position: absolute; z-index: 99; visibility: hidden; cursor: help;";
var tooltipStart = "<table id=\"internalTooltipSpan\" cellspacing=0 cellpadding=0 style=\"" + tooltipDefaultStyle + "\"><tr><td>";
var tooltipEnd = "</td></tr></table>";
var showTimeout;
var hideTimeout;
var shown = false;
var x;
var y;

function getReal(el) {
    var temp = el;

    while ((temp != null) && (temp.tagName != "BODY")) {
        if (temp.getAttribute("tooltip")) {
            el = temp;
            return el;
        }
        temp = temp.parentElement;
    }
    return el;
}


//function document.onmouseover() {
//	x = window.event.clientX;
//	y = window.event.clientY;
//	fromEl = getReal(event.fromElement);
//	toEl = getReal(event.toElement);
//	if ((toEl.getAttribute("tooltip")) && (toEl != fromEl)) {
//		showTimeout = window.setTimeout("displayTooltip(toEl)", delayTime);
//	}
//}

document.onmouseout = function() {
    var fromEl = getReal(event.fromElement);
    var toEl = getReal(event.toElement);
    if ((fromEl.getAttribute("tooltip")) && (toEl != fromEl)) {
        window.clearTimeout(showTimeout);
        hideTooltip();
    }
};

function displayTooltip(el) {
    if (!document.all.internalTooltipSpan) {
        document.body.insertAdjacentHTML("BeforeEnd", tooltipStart + el.getAttribute("tooltip") + tooltipEnd);
    }
    else {
        window.internalTooltipSpan.outerHTML = tooltipStart + el.getAttribute("tooltip") + tooltipEnd;
    }
    var toolStyle = el.getAttribute("tooltipstyle");
    if (toolStyle != null) {
        window.internalTooltipSpan.style.cssText = tooltipDefaultStyle + toolStyle;
    }
    window.internalTooltipSpan.style.left = x - 3;  //This is placed for the hand cursor :-(
    window.internalTooltipSpan.style.top = y + 20;

    dir = getDirection(); //This also fixes the position if the tooltip is outside the window.

    if (typeof (window.swipe) == "function")
        window.setTimeout("swipe(internalTooltipSpan, dir);", 1); // The span must be rendered before
    else if (typeof (fade) == "function")
        window.setTimeout("fade(internalTooltipSpan, true, 5)", 1);
    else
        window.internalTooltipSpan.style.visibility = "visible";

    shown = true;
    //hideTimeout = window.setTimeout("hideTooltip()", showTime);
    //removed autohide as per DC 
    //- EE 08/11/2005
}

function hideTooltip() {
    if (shown) {
        window.clearTimeout(hideTimeout);
        window.internalTooltipSpan.style.visibility = "hidden";
        shown = false;
    }
}

function getDirection() {
    var pageWidth, pageHeight, scrollTop;
    pageHeight = document.body.clientHeight;
    pageWidth = document.body.clientWidth;
    toolTipTop = window.internalTooltipSpan.style.pixelTop;
    toolTipLeft = window.internalTooltipSpan.style.pixelLeft;
    toolTipHeight = window.internalTooltipSpan.offsetHeight;
    toolTipWidth = window.internalTooltipSpan.offsetWidth;
    scrollTop = document.body.scrollTop;
    scrollLeft = document.body.scrollLeft;

    if (toolTipWidth > pageWidth)
        window.internalTooltipSpan.style.left = scrollLeft;
    else if (toolTipLeft + toolTipWidth - scrollLeft > pageWidth)
        window.internalTooltipSpan.style.left = pageWidth - toolTipWidth + scrollLeft;

    if (toolTipTop + toolTipHeight - scrollTop > pageHeight) {
        window.internalTooltipSpan.style.top = toolTipTop - toolTipHeight - 22;
        return 8;
    }
    return 2;
}

// JScript File
//***********************UCReturnsGrid.ascx***************************************************

var _navTextBox, _returnTextBox, _asReturnHiddenFld, _localMV, _investmentId, _portfolioId;
var _endDate, _fundId, _previousValue;
var _setMV = true;
_portfolioId = -1;
_investmentId = -1;
function JsEstimate(estimateNav, estimateReturn, estimateMv) {
    this.EstimateNav = nav;
    this.EstimateReturn = estimateReturn;
    this.EstimateMv = estimateMv;
}

function SetReturn(e) {
    _previousValue = _navTextBox.RealValue();
    _setMV = true;
    SetAsReturn(false);
 
    WSSharedFunctions.CalculateNavOrReturn(_navTextBox.value, 'GetReturn', _fundId, _endDate, _portfolioId, _investmentId, SetReturnSucceeded, OnSetReturnFailed);   
}

function SetReturnSucceeded(estimate) {
    if (!estimate) {
        _returnTextBox.SetValue('');
        if (_localMV && _setMV) _localMV.SetValue('');
    }
    else {
        _returnTextBox.SetValue(DoubleToString(estimate.EstimateReturn));
        if (_localMV && _setMV) _localMV.SetValue(estimate.EstimateMv);
        AlertForReturn();
    }
}

var PRECISION = 10;
// convert double to string without exponential representation and remove insignificant trailing zeros
function DoubleToString(number) {
    var result = number.toFixed(PRECISION);
    if(result.indexOf('.'))
        result.replace(/0*$/, '');
    return result;
}

function OnSetReturnFailed(result) {
    alert(result.get_message());
    _navTextBox.SetValue(_previousValue);
}

function SetNav(e) {
    _previousValue = _returnTextBox.RealValue();
    _setMV = true;
    SetAsReturn(true);

    WSSharedFunctions.CalculateNavOrReturn(_returnTextBox.value, 'GetNav', _fundId, _endDate, _portfolioId, _investmentId, SetNavSucceeded, OnSetNavFailed);
}

function SetNavSucceeded(estimate) {
    if (!estimate) {
        if (_navTextBox != null)
            _navTextBox.SetValue('');
        if (_localMV && _setMV) _localMV.SetValue('');
    }
    else {
        if (_navTextBox != null)
            _navTextBox.SetValue(estimate.EstimateNav);
        if (_localMV && _setMV) _localMV.SetValue(estimate.EstimateMv);
        AlertForReturn();
    }

}

function OnSetNavFailed(result) {
    alert(result.get_message());
    _returnTextBox.SetValue(_previousValue);
}

function FromMV(e) {
    _setMV = false;
    _previousValue = _localMV.RealValue();
    WSSharedFunctions.CalculateNav(_investmentId, _localMV.value, _endDate, FromMVSucceeded, FromMVFailed);
}

function FromMVSucceeded(result) {
    _navTextBox.SetValue(result);
    SetReturn();
}

function FromMVFailed(result) {
    alert(result.get_message());
    _localMV.SetValue(_previousValue);
}

function AlertForReturn() {
    var returnValue;
    returnValue = _returnTextBox.RealValue();
    if (returnValue >= 5 && returnValue != '')
        alert('Greater than 5% return, please verify.');
    if (returnValue <= -5 && returnValue != '')
        alert('Less than -5% return,please verify.');
}

var flatStaleddl;
function GetLastEstimate(returnDate, flatStaleElementId) {
    if (!_navTextBox || !_returnTextBox || !_localMV || !returnDate)
        return;

    flatStaleddl = $get(flatStaleElementId);
    var selectedText = flatStaleddl.options[flatStaleddl.selectedIndex].text;
    if (selectedText.toUpperCase() == 'YES') {

        if ((_fundId != '') && (returnDate != '') && (_navTextBox.RealValue() != '')) {
            WSSharedFunctions.ValidateNav(_fundId, returnDate, _navTextBox.RealValue(), ValidateNavSucceeded, ValidateNavFailed);
        }

        if ((returnDate != '') && (_returnTextBox.RealValue() == '') && _navTextBox.RealValue() == '') {
            WSSharedFunctions.GetLastNav(_fundId, returnDate, GetPreviousPeriodEstimateSucceeded, GetPreviousPeriodEstimateFailed);
        }
    }
    else {
        _navTextBox.SetValue('');
        SetReturn();
    }
}

function ValidateNavSucceeded(result) {
    if (result != '') {
        alert(result);
        flatStaleddl.selectedIndex = 1; //set the value back to "No"
    }
}

function ValidateNavFailed(result) {
    alert(result.get_message());
}

function GetPreviousPeriodEstimateSucceeded(result) {

    if (_navTextBox != null) {
        _navTextBox.SetValue(result);
        SetReturn();
        SetIsDirty();
    }
}
function GetPreviousPeriodEstimateFailed(result) {
    alert(result.get_message());
}

function SetAsReturn(asReturn) {
    _returnTextBox.style.fontWeight = asReturn ? 'bold' : '';
    if (_navTextBox != null)
        _navTextBox.style.fontWeight = asReturn ? '' : 'bold';
    _asReturnHiddenFld.value = asReturn;
}

function ChkMarkParentCheckBox(chkLastEstimateboxId, rowIndex, fundName) {
    var chkLastEstimatebox = document.getElementById(chkLastEstimateboxId);
    if (chkLastEstimatebox.checked)
        chkLastEstimatebox.checked = confirm("Are you sure you want to delete the estimate for " + fundName + "?");
}

//************************************************************************************************

var navTicker = "txtEstimateNav";
var returnTicker = "txtEstimateReturn";
var mvTicker = "txtLocalMV";
var dateTicker = "txtDateReceived";
var priceSourceTicker = "ctrlPriceSource$ddlEnum";

function convertToEditBox(lblField, bShowRealValue, focusOnPriceSource) {
    if (lblField == null)
        return;

    if (lblField.innerHTML.indexOf("INPUT") > 0)
        return;

    width = widthEl(lblField.id);
    height = heightEl(lblField.id) + 5;

    var txtValue;
    var onchangestring = "";
    var fontweight = "normal";
    var realValue = GetRealValue(lblField);
    var displayValue = lblField.innerHTML;
    var readOnly = false;
    if (bShowRealValue) { txtValue = realValue; }
    else { txtValue = displayValue; }

    if (eval(lblField.bold.toLowerCase())) { fontweight = "bold"; }
    
    var behaviorFile = "behavior:url(" + AppPath + "/scripts/js/VirtualTextBox.htc);";

    if (lblField.id.indexOf(navTicker) > 0) {
        onchangestring = GenerateOnChangeFunction(lblField, navTicker) + "SetReturn();SetIsDirty();";
    }
    else if (lblField.id.indexOf(returnTicker) > 0) {
        if (returnsType == "P") //For 'Portfolio Returns' page, Unmarry MV and Return
            onchangestring = "SetIsDirty();";
        else
            onchangestring = GenerateOnChangeFunction(lblField, returnTicker) + "SetNav();SetIsDirty();";
    }
    else if (lblField.id.indexOf(mvTicker) > 0) {
        if (returnsType == "P") //For 'Portfolio Returns' page, Unmarry MV and Return
            onchangestring = "SetIsDirty();";
        else
            onchangestring = GenerateOnChangeFunction(lblField, mvTicker) + "FromMV();SetIsDirty();";
    }
    else if (lblField.id.indexOf(dateTicker) > 0) {
        onchangestring = "SetIsDirty();";
        lblField.innerHTML = "<input id=\"" + lblField.id.replace("lbl", "") + "_field\" style=\"width: " + width + "px; height: " + height + "px; font-size:" + lblField.fontsize + "; font-family:"+ lblField.fontfamily + "; font-weight: " +
	    fontweight + "; " + behaviorFile + "text-align:left;\" maxlength=\"254\" type=\"text\" value=\"" + txtValue + "\"  preset=\"" + lblField.preset +
	    "\" onChange='" + onchangestring + "' OnKeyDown='Mask_KeyDown(this)' OnKeyPress='Mask_KeyPress(this);'/>";
        lblField.setAttribute('onclick', '');
        if (bShowRealValue) { lblField.firstChild.select(); }
        return;
    }

    var textboxHtml = "<input id=\"" + lblField.id.replace("lbl", "") + "_field\" style=\"width: " + width + "px; height: " + height + "px; font-size:" + lblField.fontsize + "; font-family:" + lblField.fontfamily + "; font-weight: " +
    fontweight + "; " + behaviorFile + "text-align:right;\" maxlength=\"254\" type=\"text\" value=\"" + txtValue + "\"  preset=\"" + lblField.preset +
    "\" allowMinus=\"" + lblField.allowMinus + "\" decimals=\"" + lblField.decimals + "\" onChange='" + onchangestring + "' ";

    if (readOnly)
        textboxHtml += "readOnly=true";

    textboxHtml += "/>";
    lblField.innerHTML = textboxHtml;
    lblField.setAttribute('onclick', '');
    if (bShowRealValue && !focusOnPriceSource) {
        lblField.firstChild.select();
    }
}

function GenerateOnChangeFunction(lblField, fieldTag) {
    return "SetData_" + lblField.id.replace("lbl", "").replace("$" + fieldTag, "") + "();";
}

function GetRealValue(lblField) {
    return $get(lblField.id.replace("lbl", "")).value;
}

function ConvertLabelsToTextBox(lblField, focusOnPriceSource) {
    // Forbid editing for prices from CP
    if (lblField.id.indexOf("ReturnsSecurityPricingGV") != -1)
        return;

    // Forbid editing for unchanged estimates from CP
    var inputs = lblField.parentNode.parentNode.getElementsByTagName("input");
    for (var i = 0; i < inputs.length; i++) {
        if(inputs[i].id.indexOf("EditSpEstimate") != -1) {
            var chkEditSpEstimate = inputs[i];
            if (chkEditSpEstimate && !chkEditSpEstimate.checked)
                return;
        }
    }
    
    var navTextBox;
    var returnTextBox;
    var mvTextBox;
    var dateTextBox;
    var userSelectedFieldId = lblField.id;
    if (null == lblField)
        return;

    var tickerToReplace;

    if (userSelectedFieldId.indexOf(navTicker) > 0) {
        tickerToReplace = navTicker;
    }
    else if (userSelectedFieldId.indexOf(returnTicker) > 0) {
        tickerToReplace = returnTicker;
    }
    else if (userSelectedFieldId.indexOf(mvTicker) > 0) {
        tickerToReplace = mvTicker;
    }
    else if (userSelectedFieldId.indexOf(dateTicker) > 0) {
        tickerToReplace = dateTicker;
    }

    navTextBox = $get(userSelectedFieldId.replace(tickerToReplace, navTicker));
    returnTextBox = $get(userSelectedFieldId.replace(tickerToReplace, returnTicker));
    mvTextBox = $get(userSelectedFieldId.replace(tickerToReplace, mvTicker));
    dateTextBox = $get(userSelectedFieldId.replace(tickerToReplace, dateTicker));
   
    convertToEditBox(navTextBox, userSelectedFieldId.indexOf(navTicker) > 0, focusOnPriceSource);
    convertToEditBox(returnTextBox, userSelectedFieldId.indexOf(returnTicker) > 0, focusOnPriceSource);
    
    convertToEditBox(mvTextBox, userSelectedFieldId.indexOf(mvTicker) > 0, focusOnPriceSource);
    convertToEditBox(dateTextBox, userSelectedFieldId.indexOf(dateTicker) > 0, focusOnPriceSource);   
}


//get width of text element
function widthEl(span) {
    return document.getElementById(span).offsetWidth;
}

//get height of text element
function heightEl(span) {
    return document.getElementById(span).offsetHeight;
}

//----------Effective date-------------
function openDialog(dialogId, ctlId, pnlId) {
    var posLeft = $('#' + pnlId).position().left - $(document).scrollLeft() + $('#' + pnlId).width() / 2 - 125;
    var posTop = $('#' + pnlId).position().top - $(document).scrollTop();
    var dlg = $('#' + dialogId).dialog({
        autoOpen: false,
        minheight: 120,
        minwidth: 50,
        width: 250,
        height: 200,
        position: [posLeft, posTop],
        modal: false
    });
    dlg.parent().appendTo($("form:first"));

    $('#' + dialogId).dialog("open");
    $('#' + ctlId).val("");
    $('#' + ctlId).focus();
    return false;
}

function closeDialog(dialogId) {
    $('#' + dialogId).dialog("destroy");
    return false;
}
function createEffectiveDate(dialogId, btnId) {
    $('#' + btnId).click();
    var dlg = $('#' + dialogId);
    if (Page_IsValid && dlg.hasClass('ui-dialog-content')) {
        dlg.dialog("destroy");
    }
    
    return false;
}
//-----------------------

var ENTERED_AS_PCT = 'PCT';
var ENTERED_AS_AMT = 'AMT';
var ENTERED_AS_QTY = 'QTY';

//--------Set center position to div----//
//used instead of expressions
function PlaceDivToCenter(divObj) {
    divObj.style.marginLeft = divObj.offsetWidth < document.body.offsetWidth ? parseInt((document.body.offsetWidth - divObj.offsetWidth) / 2) + "px" : "0";
    divObj.style.top = divObj.offsetHeight < document.body.offsetHeight ? parseInt((document.body.offsetHeight - divObj.offsetHeight) / 2) + "px" : "0";
}

//Compare two arrays
function CompareArrays(arr1, arr2) {
    return $(arr1).not(arr2).length == 0 && $(arr2).not(arr1).length == 0;
}