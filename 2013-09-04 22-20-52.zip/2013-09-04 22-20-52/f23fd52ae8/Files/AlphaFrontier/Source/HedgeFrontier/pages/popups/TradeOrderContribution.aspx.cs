﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using HedgeFrontier.Common;
using IFS.BusinessLayer;
using IFS.BusinessLayer.CloudServices;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.Import;
using IFS.BusinessLayer.Loader;
using IFS.BusinessLayer.OrderManagementSystem;
using IFS.BusinessLayer.Trade;
using IFS.BusinessLayer.Utilities;
using IFS.Interfaces.CloudContracts.DataContracts;
using IFS.Interfaces.CloudContracts.DataContracts.Trades;
using IFS.Interfaces.CloudContracts.Trades;
using IFS.Interfaces.Common;
using IFS.Interfaces.Common.Enums;
using IFS.Interfaces.Rounding;
using IFS.UI.IFSControls;
using WebUtilities;
using TradeOrderContributionClass = IFS.BusinessLayer.OrderManagementSystem.TradeOrderContribution;

namespace HedgeFrontier.pages.popups
{
    public partial class TradeOrderContribution : CBasePage
    {
        #region Members
        private int _fundId = -1;
        private TradeOrderContributionClass _contributionTradeOrder;
        #endregion

        #region Querystring
        public int FundID
        {
            get
            {
                if (_fundId <= 0)
                {
                    var sFundId = Request.Params["fundID"];
                    _fundId = string.IsNullOrEmpty(sFundId) ? -1 : int.Parse(sFundId);
                }
                return _fundId;
            }
            set { _fundId = value; }
        }

        public int TradeOrderID
        {
            get
            {
                var sTradeOrderId = Request.Params["tradeOrderID"];
                return string.IsNullOrEmpty(sTradeOrderId) ? -1 : int.Parse(sTradeOrderId);
            }
        }
        #endregion

        #region Properties

        private bool IsEditMode
        {
            get { return ContributionTradeOrder.TradeOrderId > 0; }
        }

        private PortfolioView PortfolioView { get; set; }

        private InvestableFundView InvestableFundView { get; set; }

        private BaseFundView BaseFundView { get; set; }

        private List<KeyValuePair<int, string>> InvestableFunds { get; set; }
        
        private double Price { get; set; }

        private double Rate { get; set; }

        private bool AreSubscriptionsAllowed { get; set; }

        private CAmount UnfundedCommitment { get; set; }

        private bool DoNotUseSharedFunds { get; set; }

        private bool IsInvestedInDifferentPortfolio { get; set; }

        private bool IsFundFullyRedeemed { get; set; }

        private bool UserHasAccess { get; set; }

        private DateTime MoneyMoveDate
        {
            get { return dpMoneyMoveDate.DateTime.Date; }
            set { dpMoneyMoveDate.DateTime = value; }
        }

        private DateTime ExecutionDate
        {
            get { return dpEffectiveDate.DateTime.Date; }
            set { dpEffectiveDate.DateTime = value; }
        }

        private DateTime TradeDate
        {
            get { return dpTradeDate.DateTime.Date; }
            set { dpTradeDate.DateTime = value; }
        }

        private DateTime LockdownDate
        {
            get
            {
                if (ViewState["LockdownDate"] == null)
                {
                    ViewState["LockdownDate"] = PortfolioView.LatestLockdownDate;
                }
                return (DateTime) ViewState["LockdownDate"];
            }
        }

        private int GetSelectedInvestableFundId()
        {
            return CDropDown.GetInt(ddInvestable);
        }

        private bool IsCapitalCommitmentThirdPartyTransferIn
        {
            get
            {
                bool isThirdPartyTransfer = false;
                var isThirdParty = Request.QueryString["isThirdPartyTransferIn"];

                if (!string.IsNullOrEmpty(isThirdParty))
                    isThirdPartyTransfer = isThirdParty == "1";

                return isThirdPartyTransfer;
            }
        }

        private static ITradeService TradeService
        {
            get { return SpringUtil.GetObject<ITradeService>(ServiceNames.TRADE_PVT_EQTY_FUND_SPRING_NAME); }
        }

        private IPvtEquitySubscriptionService PageDataService
        {
            get
            {
                return
                    SpringUtil.GetObject<IPvtEquitySubscriptionService>(
                        ServiceNames.PVT_EQUITY_SUBSCRIPTION_SERVICE_SPRING_NAME);
            }
        }

        private DateTime LastModifiedDate
        {
            get
            {
                long lastModifiedDateTicks = long.MinValue;
                if (ViewState["LastModifiedDateTicks"] != null)
                    long.TryParse(ViewState["LastModifiedDateTicks"].ToString(), out lastModifiedDateTicks);
                if (lastModifiedDateTicks == long.MinValue)
                    return DateTime.Now;
                return new DateTime(lastModifiedDateTicks);
            }
            set { ViewState["LastModifiedDateTicks"] = value.Ticks; }
        }

        protected string CapitalCallValue
        {
            get { return EnumValue.CAPITAL_CALL; }
        }

        public TradeOrderContributionClass ContributionTradeOrder
        {
            get
            {
                if (_contributionTradeOrder == null && TradeOrderID > 0)
                    _contributionTradeOrder = TradeOrderHelper.GetTradeOrderCloneFromPorfolio(IFSSession.Portfolio, TradeOrderID) as TradeOrderContributionClass;

                return _contributionTradeOrder ?? (_contributionTradeOrder = new TradeOrderContributionClass());
            }
            set { _contributionTradeOrder = value; }
        }

        #endregion

        #region Page Events

        protected void Page_PreRender(object sender, EventArgs e)
        {
            RegisterClientScript();
            BindJavascriptToControls();
            BuildTable();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            var user = CSession.User;
            if (!Page.IsPostBack)
            {
                RequestPageData(false);
                CheckAccessRight(UserHasAccess, user, true);
                CheckAccessRight(BaseFund.IsFundAccessibleForUser(FundID), CSession.User, true);
                OnPageLoad();
            }
            else
            {
                RequestPageData(true);
            }
        }

        protected void ddInvestable_SelectedIndexChanged(object sender, EventArgs e)
        {
            FundID = GetSelectedInvestableFundId();
            RequestPageData(false);

            if (InvestableFundView != null)
            {
                ValidateSubscriptionRequest();
                SetUnfundedCommitment();
                SetPrice();
                SetRate();
            }
            else
            {
                SetControlsForEmptyFund();
            }
            SetEditModeControls();
            SetApproveButton();
            SetRejectButton();
            ClearHiddenFieldsForBreakouts();
        }

        protected void dpEffectiveDate_ValueChanged(object sender, EventArgs e)
        {
            SetTradeDate();
            if (InvestableFundView != null)
            {
                ValidateSubscriptionRequest();
                SetUnfundedCommitment();
                SetPrice();
                SetRate();
            }
            else
            {
                SetControlsForEmptyFund();
            }
            SetEditModeControls();
            SetApproveButton();
            SetRejectButton();
            ClearHiddenFieldsForBreakouts();
        }

        protected void btnAccept_Click(object sender, EventArgs e)
        {
            if (ValidateData())
            {
                try
                {
                    SaveTradeOrder();
                    CacheUpdateNotificationHelper.ForceReceiveNotifications();
                    WSCache.ResetReturns(FundID);
                    CPopup.RefreshParentWindowAndClose();
                }
                catch (ValidationException valEx)
                {
                    DisplayErrorMessageAndReloadPageData(valEx.Message);
                    ClearHiddenFieldsForBreakouts();
                }
                catch (ChangeConflictException)
                {
                    DisplayErrorMessageAndReloadPageData(
                        "This investment has been modified by another user. Please rebook the Subscription.");
                    ClearHiddenFieldsForBreakouts();
                    CPopup.RefreshParentWindow();
                }
            }
            else
            {
                SetPrice();
                ClearHiddenFieldsForBreakouts();
            }
        }

        protected void btnApproval_Click(object sender, EventArgs e)
        {
            try
            {
                var currentUser = CSession.User;
                var processor = TradeOrderHelper.GetTradeProcessor();
                ContributionTradeOrder.TradeLastModifiedDate = LastModifiedDate;
                processor.TradeOrder = ContributionTradeOrder;
                var metadata = new TradeOrderWorkflowMetaData
                {
                    TradeOrderIn = ContributionTradeOrder,
                    TradeUserRoleId = currentUser.UserRoleID,
                    CurrentUserId = currentUser.UserID,
                    ApprovalAction = hdnApprovalType.Value == @"Approve" ? ETradeApprovalAction.APPROVED : ETradeApprovalAction.REJECTED,
                    ApprovalComment = txtApprovalComment.Text,
                    ApproverUserId = currentUser.UserID
                };
                var errMsg = processor.RunWorkflow(metadata);
                if (!string.IsNullOrEmpty(errMsg))
                    throw new ValidationException(errMsg);
                CPopup.RefreshParentWindowAndClose();
            }
            catch (ChangeConflictException)
            {
                CPopup.Alert(Page, "This trade order has been modified by another user. Please verify updated information and try again");
                ContributionTradeOrder = null;
                OnPageLoad();
                CPopup.RefreshParentWindow();
            }
            catch (ValidationException valEx)
            {
                //Display the Validation message
                CPopup.Alert(Page, valEx.Message);
            }
        }

        #endregion

        #region Initializing Methods

        private void OnPageLoad()
        {
            SetDateControls();
            ValidateSubscriptionRequest();
            SetFundNames();
            SetEditModeControls();
            SetUnfundedCommitment();
            ValidateInvestableFund();
            SetStaticControls();
            SetPrice();
            SetRate();
            SetApproveButton();
            SetRejectButton();
        }

        private void RequestPageData(bool useCachedData)
        {
            PvtEquitySubscriptionRequestResult pageData;
            if (useCachedData)
            {
                pageData = IFSSession.CurrentTrade as PvtEquitySubscriptionRequestResult;
            }
            else
            {
                pageData = PageDataService.GetPageData(new TradeParameters
                {
                    PortfolioId = IFSSession.PortfolioId,
                    InvestableFundId = FundID,
                    ExecutionDate = Page.IsPostBack
                                        ? ExecutionDate
                                        : DateTime.MinValue
                }, CSession.GetSessionData());
                if (pageData.Failed)
                {
                    throw pageData.InnerException;
                }
                IFSSession.CurrentTrade = pageData;
            }

            if (pageData != null)
            {
                SetTradeDataProperties(pageData.Allocation);
                InvestableFunds = pageData.InvestableFunds;
                PortfolioView = pageData.Portfolio;
                InvestableFundView = pageData.InvestableFund;
                BaseFundView = pageData.BaseFund;
                Price = pageData.CurrentPrice != null ? pageData.CurrentPrice.Value : 0;
                Rate = pageData.Rate;
                UserHasAccess = pageData.UserHasAccess;
                AreSubscriptionsAllowed = pageData.AreSubscriptionsAllowed;
                UnfundedCommitment = pageData.UnfundedCommitment;
                DoNotUseSharedFunds = pageData.DoNotUseSharedFunds;
                IsInvestedInDifferentPortfolio = pageData.IsInvestedInDifferentPortfolio;
                IsFundFullyRedeemed = pageData.IsFundFullyRedeemed;
            }
        }
        
        private void SetTradeDataProperties(TradeData data)
        {
            if (data != null)
            {
                SetLastModifiedDate(data.InvestmentLastModifiedDate);
            }
        }

        private void SetLastModifiedDate(DateTime? lastModifiedDate)
        {
            if (lastModifiedDate.HasValue && lastModifiedDate.Value != DateTime.MinValue)
                LastModifiedDate = lastModifiedDate.Value;
        }

        private void SetControlsForEmptyFund()
        {
            btnAccept.Enabled = false;
            btnAccept.ToolTip = @"Cannot create a new Subscription. Please select an appropriate fund.";
            lblUnfundedCommit.Text = string.Empty;
            txtOverridePrice.Text = string.Empty;
            lblPriceCurrency.Text = string.Empty;
            lblDate.Text = string.Empty;
            pnlRateOverride.Visible = false;
        }
        
        private void SetUnfundedCommitment()
        {
            lblUnfundedCommit.Text = string.Format("{0}(@{1})", UnfundedCommitment.ToString(CAmount.FORMAT_STRING),
                                                   ExecutionDate.ToShortDateString());
        }

        private void SetEditModeControls()
        {
            SetClearer();
            txtQuantity.Text = string.Empty;
            txtAmount.Text = string.Empty;

            if (!IsEditMode)
                return;

            btnAccept.Text = @"Update";
            //if date has changed in the screen recalculate the prices
            if (ContributionTradeOrder.ExecutionDate != ExecutionDate)
            {
                SetAmountAndQuantity(string.Empty, txtOverridePrice.Text);
            }
            else
            {
                txtQuantity.Text = Property.FormatDouble(ContributionTradeOrder.TradeQuantity.Value);
                txtAmount.Text = Property.FormatDouble(ContributionTradeOrder.TradeAmount.Value);
                hdnQuantity.Value = Property.FormatDouble(ContributionTradeOrder.TradeQuantity.Value);
                hdnAmount.Value = Property.FormatDouble(ContributionTradeOrder.TradeAmount.Value);
            }
            hdnEditMode.Value = Property.FormatBool(true);
            _ctrlTransactionId.Text = ContributionTradeOrder.TradeOrderTransactionId;
            txtComments.Text = ContributionTradeOrder.Comment;
            //lblEnteredBy.Text = ContributionTradeOrder.PerformedBy;
        }

        private void SetAmountAndQuantity(string value, string price)
        {
            var amountQuantityCalc = new WSSharedFunctions();

            if (!rdAmountFixed.Checked)
            {
                if (string.IsNullOrEmpty(value))
                    value = txtQuantity.RealValue;
                string amount = amountQuantityCalc.CalculateQuantityOrAmount(value, price, "GetAmt");
                txtQuantity.Text = value;
                hdnQuantity.Value = value;
                txtAmount.Text = amount;
                hdnAmount.Value = amount;
            }
            else
            {
                if (string.IsNullOrEmpty(value))
                    value = txtAmount.RealValue;
                string quantity = amountQuantityCalc.CalculateQuantityOrAmount(value, price, "GetQty");
                txtAmount.Text = value;
                hdnAmount.Value = value;
                txtQuantity.Text = quantity;
                hdnQuantity.Value = quantity;
            }
        }

        private void SetClearer()
        {
            if (UCClearer.EnumList.Items.Count == 2)
                UCClearer.EnumList.SelectedIndex = 1;

            UCClearer.ValueInt = ContributionTradeOrder.TradeClearerId;
        }


        private void SetDateControls()
        {
            if (IsEditMode)
            {
                ExecutionDate = ContributionTradeOrder.ExecutionDate;
                MoneyMoveDate = ContributionTradeOrder.MoneyMoveDate;
                TradeDate = ContributionTradeOrder.TradeDate;
                MoneyMoveDate = ContributionTradeOrder.MoneyMoveDate == DateTime.MinValue
                                    ? ContributionTradeOrder.TradeDate
                                    : ContributionTradeOrder.MoneyMoveDate;
                if (InvestableFundView.IsOfType(SystemTypeBase.CONTINGENT_REDEMPTION) || 
                    InvestableFundView.IsOfType(SystemTypeBase.EQUALIZATION))
                    dpEffectiveDate.Enabled = false;
            }
            else
            {
                ExecutionDate = LockdownDate != DateTime.MinValue ? LockdownDate.AddDays(1) : DateTime.Now.Date;
                SetTradeDate();
            }
        }

        private void SetTradeDate()
        {
            TradeDate = DateUtil.GetTradeDateForSubscription(ExecutionDate);
            MoneyMoveDate = TradeDate;
        }

        private void SetStaticControls()
        {
            txtOverridePrice.Decimals = CNav.DECIMALS;
        }

        private void SetFundNames()
        {
            ddInvestable.Items.Clear();
            
            if (IsEditMode)
            {
                lblInvestableFundName.Text = InvestableFundView.Name;
                ddInvestable.Visible = false;
            }
            else
            {
                foreach (var investableFund in InvestableFunds)
                {
                    CDropDown.Add(ddInvestable, investableFund.Value, investableFund.Key);
                }
                CDropDown.BlankItem(ddInvestable, "Select a Fund", "-1");
                CDropDown.SetValue(ddInvestable, FundID);

                lblInvestableFundName.Visible = false;
            }

            lblBaseFundName.Text = BaseFundView.Name;
            lblBaseFundName.ToolTip = BaseFundView.FormOfEntity;
        }

        private void SetPrice()
        {
            hdnPrice.Value = Property.FormatDouble(Price);
            //if (!RoundingBase.IsNaN(ContributionTradeOrder.TradePrice))
            //{
            //    chkOverride.Checked = true;
            //    txtOverridePrice.Text = Property.FormatDouble(ContributionTradeOrder.TradePrice);
            //}

            txtOverridePrice.Enabled = chkOverride.Checked;

            if (!chkOverride.Checked)
                txtOverridePrice.Text = Property.FormatDouble(Price);

            lblPriceCurrency.Text = InvestableFundView.CurrencyId;
            lblDate.Text = DateTime.MinValue == ExecutionDate
                               ? string.Empty
                               : String.Format("(@{0})", Property.FormatDate(ExecutionDate));
        }

        private void SetRate()
        {
            if (InvestableFundView.CurrencyId == PortfolioView.CurrencyId)
            {
                pnlRateOverride.Visible = false;
                return;
            }

            pnlRateOverride.Visible = true;
            lblFxRateFromTo.Text = string.Format("{0}=>{1}", InvestableFundView.CurrencyId, PortfolioView.CurrencyId);
            //if (!double.IsNaN(ContributionTradeOrder.TradeFxRateOveride))
            //{
            //    txtRateOverride.Text = Property.FormatDouble(ContributionTradeOrder.TradeFxRateOveride);
            //    chkRateOverride.Checked = true;
            //}

            txtRateOverride.Enabled = chkRateOverride.Checked;
            var stringifiedRate = Property.FormatDouble(Rate);
            if (!chkRateOverride.Checked)
                txtRateOverride.Text = stringifiedRate;

            hdnDefaultRate.Value = stringifiedRate;
        }

        private void SetApproveButton()
        {
            btnApprove.Enabled = IsEditMode && ContributionTradeOrder.CurrentState.Contains(TradeOrderHelper.PENDING_APPROVAL);
            if (IsEditMode && !btnApprove.Enabled)
                btnApprove.ToolTip = @"Disabled because the trade order is in " + ContributionTradeOrder.CurrentState + @" state";
        }

        private void SetRejectButton()
        {
            btnReject.Enabled = IsEditMode && ContributionTradeOrder.CurrentState.Contains(TradeOrderHelper.PENDING_APPROVAL);
            if (IsEditMode && !btnReject.Enabled)
                btnReject.ToolTip = @"Disabled because the trade order is in " + ContributionTradeOrder.CurrentState + @" state";
        }

        private void BindJavascriptToControls()
        {
            if (InvestableFundView == null)
            {
                rdQuantityFixed.Enabled = false;
                btnAccept.OnClientClick = "";
                txtAmount.Attributes.Clear();
                txtQuantity.Attributes.Clear();
                chkOverride.Enabled = false;
                dpTradeDate.OnChange = "";
            }
            else
            {
                chkOverride.Enabled = true;

                CPopup.OnClick(chkRateOverride, "ToggleRateOverride(this);");
                CPopup.OnClick(rdAmountFixed, "ToggleQtyAmt(this);");

                var isHedgeFundCommitment = BaseFundView.IsHedgeFundCommitment;
                rdQuantityFixed.Enabled = isHedgeFundCommitment;
                if (isHedgeFundCommitment)
                    CPopup.OnClick(rdQuantityFixed, "ToggleQtyAmt(this);");

                var script = "if(!ValidateData()){this.disabled=false; this.value='" + btnAccept.Text +
                             "'; return false; }else {UpdateBreakouts();}";
                btnAccept.OnClientClick += script;

                //Please attach the DisableOnClickScript for the 'btnAccept' after the above JS plugins
                CButton.DisableOnClick(btnAccept);

                txtAmount.Attributes.Add("onChange",
                                         "CalculateQuantityOrAmount('" + txtQuantity.UniqueID.Replace("$", "_")
                                         + "','" + txtAmount.UniqueID.Replace("$", "_") + "','" +
                                         txtOverridePrice.RealValueCtrlID + "')");

                txtQuantity.Attributes.Add("onChange",
                                           "CalculateQuantityOrAmount('" + txtQuantity.UniqueID.Replace("$", "_")
                                           + "','" + txtAmount.UniqueID.Replace("$", "_") + "','" +
                                           txtOverridePrice.RealValueCtrlID + "')");

                //Different JavaScript is required for Trade Order.
                chkOverride.Attributes["onclick"] = "javascript: ToggleCheckBoxes(this,false);";
                txtOverridePrice.Attributes.Add("onChange", "SetQtyAmt('','');");

                dpTradeDate.OnChange = "TradeDate_ValueChange(this,'" + dpEffectiveDate.ClientID + "','"
                                       + InvestableFundView.IssueDate.ToString("MM/dd/yyyy") + "','"
                                       + PortfolioView.InceptionDate.ToString("MM/dd/yyyy") + "');";
            }

            txtAmount.Attributes.Add("onFocus", "SetFocus('amt')");
            txtQuantity.Attributes.Add("onFocus", "SetFocus('qty')");
        }

        private void RegisterClientScript()
        {
            Page.ClientScript.RegisterStartupScript(Page.GetType(), "FixedQtyOrAmt",
                                                    "<script>InitializeQtyAmt();</script>");

            const string scriptKey = "ValueChangedScript";
            if (Page.ClientScript.IsClientScriptBlockRegistered(scriptKey))
                return;

            var sb = new StringBuilder(256);
            sb.Append("<script>");
            sb.Append("function InitializeQtyAmt() {");

            //The following logic is to reset the readonly and background color attributes of the qty/amt textbox pair.
            //In case of Cpopup.Alert, the page needs to maintain state and for some reason, properties modified
            //by javascript(readonly,background color) do not get set on post back.
            sb.Append("document.getElementById('");
            if (rdAmountFixed.Checked)
                sb.Append(rdAmountFixed.UniqueID.Replace("$", "_"));
            else if (rdQuantityFixed.Checked)
                sb.Append(rdQuantityFixed.UniqueID.Replace("$", "_"));
            else if (!IsEditMode)
                sb.Append(rdAmountFixed.UniqueID.Replace("$", "_"));
            else if (ContributionTradeOrder.ETradeEnteredAs == AllocationEnteredAs.QTY)
                sb.Append(rdQuantityFixed.UniqueID.Replace("$", "_"));
            else
                sb.Append(rdAmountFixed.UniqueID.Replace("$", "_"));
            sb.Append("').click(); }");
            sb.Append("</script>");
            Page.ClientScript.RegisterClientScriptBlock(GetType(), scriptKey, sb.ToString());
        }

        private void BuildTable()
        {
            tblBreakouts.Rows.Clear();

            if (IsEditMode)
            {
                //foreach (var brkup in ContributionTradeOrder.Breakups)
                //{
                //    var breakupType = CImport.GetEnumValueId(EnumGroup.SUBSCRIPTION_BREAKUP_TYPES,
                //                                             brkup.TransactionDetails);
                //    tblBreakouts.Rows.Add(GetNewRow(brkup.MvLocal, breakupType, brkup.IsCapitalCall, brkup.BreakupId));
                //}
            }

            //Display atleast one Row.
            if (tblBreakouts.Rows.Count == 0)
                tblBreakouts.Rows.Add(GetNewRow(CAmount.Zero(), -1, false, -1));
        }

        #endregion

        #region Validating Methods

        private void ValidateSubscriptionRequest()
        {
            btnAccept.Enabled = true;
            btnAccept.ToolTip = "";

            if (string.IsNullOrEmpty(BaseFundView.Country))
            {
                CPopup.AlertAndClose(String.Format("Select a Country for basefund: {0}", BaseFundView.Name));
                return;
            }

            if (string.IsNullOrEmpty(BaseFundView.FormOfEntity))
            {
                CPopup.AlertAndClose("Must select a Form of Entity for this fund before a subscription can be entered");
                return;
            }

            if (!BaseFundView.IsHedgeFundCommitment && IsFundFullyRedeemed || BaseFundView.IsHedgeFundCommitment && btnAccept.Enabled && !AreSubscriptionsAllowed)
            {
                btnAccept.Enabled = false;
                btnAccept.ToolTip = @"Cannot create a new Subscription as this fund has been fully redeemed.";
            }
        }

        private bool ValidateData()
        {
            bool dataIsValid = false;
            try
            {
                TradePageValidator.ValidateQuantityAndAmount(txtQuantity.Text, txtAmount.Text);
                TradeValidator.ValidateClearer(UCClearer.ValueInt);

                if (IsEditMode)
                {
                    try
                    {
                        TradeValidator.ValidateComment(txtComments.Text);
                    }
                    catch (ValidationException)
                    {
                        CTextBox.Focus(Page, txtComments);
                        throw;
                    }
                }
                //ValidateBreakupTypes();
                dataIsValid = true;
            }
            catch (ValidationException vex)
            {
                CPopup.Alert(Page, vex.Message);
            }
            return dataIsValid;
        }

        private void ValidateBreakupTypes()
        {
            var breakoutRows = hdnBreakouts.Value.Split(';');
            if (
                (from breakoutRow in breakoutRows where !string.IsNullOrEmpty(breakoutRow) select breakoutRow.Split('|'))
                    .Any(rowCells => rowCells[1] == "-1"))
            {
                throw new ValidationException("Please select appropriate breakup type for all breakups.");
            }
        }

        private void ValidateInvestableFund()
        {
            //Show this message only for the first time when the page Loads
            if (InvestableFundView != null && IsInvestedInDifferentPortfolio && DoNotUseSharedFunds)
            {
                CPopup.Alert(Page, "Class picked is already invested in a different portfolio. Please create a new Class / Select another one.");
            }
        }

        #endregion

        #region Helper Methods

        private void ClearHiddenFieldsForBreakouts()
        {
            hdnBreakouts.Value = string.Empty;
            hdnDeletedBreakOuts.Value = string.Empty;
        }

        private void DisplayErrorMessageAndReloadPageData(string errorMessage)
        {
            CPopup.Alert(Page, errorMessage);
            OnPageLoad();
        }

        private string GetTransactionType()
        {
            return IsCapitalCommitmentThirdPartyTransferIn
                       ? CBulkUploadTrades.TRANSACTION_TYPE_CAPITAL_COMMITMENT_TRANSFER_IN
                       : CBulkUploadTrades.TRANSACTION_TYPE_CONTRIBUTION;
        }

        private List<int> GetDeletedBreakups()
        {
            return hdnDeletedBreakOuts.Value.Split('|').Where(breakUp =>
                {
                    int res;
                    return int.TryParse(breakUp, out res);
                }).Select(breakUp => Convert.ToInt32(breakUp)).
                                       ToList();
        }

        private List<TradeBreakup> GetBreakups()
        {
            string[] breakupRows = hdnBreakouts.Value.Split(';');

            return (from breakupRow in breakupRows
                    where !string.IsNullOrEmpty(breakupRow)
                    select breakupRow.Split('|')
                    into rowCells
                    let amount = double.Parse(rowCells[0])
                    let type = int.Parse(rowCells[1])
                    let isCapital = !bool.Parse(rowCells[2])
                    let breakupId = !string.IsNullOrEmpty(rowCells[3]) ? int.Parse(rowCells[3]) : -1
                    select new TradeBreakup
                        {
                            MvLocal = new CAmount(amount),
                            TransactionDetails = ((EnumValueLoader) EnumValue.Loader).GetById(type).EnumValueName,
                            IsCapitalCall = isCapital,
                            BreakupId = breakupId
                        }).ToList();
        }

        private HtmlTableRow GetNewRow(CAmount amt, int type, bool isCapital, int breakupId)
        {
            var newRow = new HtmlTableRow();
            var rowIndex = tblBreakouts.Rows.Count;

            var ddlTypeValues = GetTypesDropDown(type.ToString(CultureInfo.InvariantCulture), rowIndex);
            ddlTypeValues.Attributes.Add("onchange", "BreakupTypeChanged(this)");

            newRow.Cells.Add(GetAmountTextCell(rowIndex));
            newRow.Cells.Add(GetAmountCell(amt, rowIndex));
            newRow.Cells.Add(GetTypeTextCell(rowIndex));
            newRow.Cells.Add(GetTypeCell(rowIndex, ddlTypeValues));
            newRow.Cells.Add(GetCapitalTextCell(rowIndex));
            newRow.Cells.Add(GetCaptialCell(isCapital, rowIndex, ddlTypeValues));
            newRow.Cells.Add(GetBreakupIdCell(breakupId, rowIndex));
            newRow.Cells.Add(GetDeleteIconCell(rowIndex));
            return newRow;
        }

        private static HtmlTableCell GetDeleteIconCell(int rowIndex)
        {
            var deleteIconCell = new HtmlTableCell {ID = "tdDeleteIconCell" + rowIndex};
            var image = new HtmlImage
                {
                    ID = "imgDelete" + rowIndex,
                    Src = "../../images/icon_delete.gif"
                };
            image.Attributes["onclick"] = "DeleteRow(this);";
            deleteIconCell.Controls.Add(image);
            return deleteIconCell;
        }

        private static HtmlTableCell GetBreakupIdCell(int breakupId, int rowIndex)
        {
            var breakupIdCell = new HtmlTableCell {ID = "tdbreakupIdCell" + rowIndex};
            var hdnBreakupId = new HiddenField
                {
                    ID = "hdnBreakupId" + rowIndex,
                    Value = breakupId.ToString(CultureInfo.InvariantCulture)
                };
            breakupIdCell.Controls.Add(hdnBreakupId);
            return breakupIdCell;
        }

        private HtmlTableCell GetCaptialCell(bool isCapital, int rowIndex, DropDownList ddlTypeValues)
        {
            var chkCaptialCell = new HtmlTableCell {ID = "tdChkCapitalCell" + rowIndex};
            var chkCapital = new CheckBox
                {
                    ID = "chkCapitalCall" + rowIndex,
                    Checked = !isCapital,
                    Enabled = ddlTypeValues.SelectedItem.Text != CapitalCallValue
                };
            chkCaptialCell.Controls.Add(chkCapital);
            return chkCaptialCell;
        }

        private static HtmlTableCell GetTypeCell(int rowIndex, DropDownList ddlTypeValues)
        {
            var ddlTypeCell = new HtmlTableCell { ID = "tdDdlTypeCell" + rowIndex };
            ddlTypeCell.Controls.Add(ddlTypeValues);
            return ddlTypeCell;
        }

        private static HtmlTableCell GetAmountCell(CAmount amt, int rowIndex)
        {
            var txtBoxCell = new HtmlTableCell { ID = "tdTxtBox" + rowIndex };
            var txtAmt = new RoundingTextbox
            {
                AllowMinus = false,
                Decimals = 2,
                Width = new Unit(120, UnitType.Pixel),
                Mask = MaskType.Currency,
                AutoCompleteType = AutoCompleteType.None,
                EnableViewState = true,
                Text = amt.ToString("R"),
                ID = "txtBreakupAmount" + rowIndex,
                CssClass = "commonTextBox"
            };
            txtBoxCell.Controls.Add(txtAmt);
            return txtBoxCell;
        }

        private static HtmlTableCell GetCapitalTextCell(int rowIndex)
        {
            return new HtmlTableCell
            {
                ID = "tdCapitalText" + rowIndex,
                InnerText = "Capital Call Outside Commitment"
            };
        }

        private static HtmlTableCell GetTypeTextCell(int rowIndex)
        {
            return new HtmlTableCell {ID = "tdTypeTxt" + rowIndex, InnerText = "Type"};
        }

        private static HtmlTableCell GetAmountTextCell(int rowIndex)
        {
            return new HtmlTableCell {ID = "tdAmtTxt" + rowIndex, InnerText = "Amount"};
        }

        private static DropDownList GetTypesDropDown(string selectedValue, int rowIndex)
        {
            var ddlTypeValues = new DropDownList
                {
                    ID = "ddlTypeValues" + rowIndex,
                    Width = new Unit(200, UnitType.Pixel),
                    DataTextField = "EnumValueName",
                    DataValueField = "EnumValueID",
                    DataSource = EnumGroup.Loader.GetById(EnumGroup.SUBSCRIPTION_BREAKUP_TYPES).ValuesForOrg(-1)
                };
            ddlTypeValues.DataBind();
            ddlTypeValues.Items.Insert(0, new ListItem("", "-1"));
            ddlTypeValues.SelectedValue = selectedValue;
            return ddlTypeValues;
        }

        #endregion

        #region Saving Method

        private void SaveTradeOrder()
        {
            SetTradeOrderValues();
            var processor = TradeOrderHelper.GetTradeProcessor();
            processor.TradeOrder = ContributionTradeOrder;
            var currentUser = CSession.User;
            var metadata = new TradeOrderWorkflowMetaData
            {
                TradeOrderIn = ContributionTradeOrder,
                TradeUserRoleId = currentUser.UserRoleID,
                CurrentUserId = currentUser.UserID
            };
            var errMsg = processor.RunWorkflow(metadata);
            if (!string.IsNullOrEmpty(errMsg))
                throw new ValidationException(errMsg);
        }

        private void SetTradeOrderValues()
        {
            Portfolio tradeOrderPort = IFSSession.Portfolio;
            var oc = new ObjectContainer();
            var tradeInvestment = tradeOrderPort.GetInvestmentForOrders(InvestableFund.GetById(FundID), oc);
            using (var bsd = new BulkSaveData())
            {
                bsd.SubmitChanges(oc);
            }

            ContributionTradeOrder.TradeInvestment = tradeInvestment;
            ContributionTradeOrder.TradeInvestmentId = tradeInvestment.InvestmentID;

            //ContributionTradeOrder.TradePortfolioId = IFSSession.PortfolioId;
            ContributionTradeOrder.TradeOrderTransactionId = _ctrlTransactionId.Text;
            ContributionTradeOrder.TradeType = TradeOrderType.TRADE_ORDER_CONTRIBUTION;
            //ContributionTradeOrder.TransactionType = GetTransactionType();
            //ContributionTradeOrder.TradeFundId = InvestableFundView.Id;
            ContributionTradeOrder.TradeDate = TradeDate;
            ContributionTradeOrder.ExecutionDate = ExecutionDate;
            ContributionTradeOrder.MoneyMoveDate = MoneyMoveDate;
            ContributionTradeOrder.TradeClearerId = UCClearer.ValueInt;
            //ContributionTradeOrder.TradeFxRateOveride =
            //                        chkRateOverride.Checked
            //                            ? Property.ParseDouble(txtRateOverride.RealValue)
            //                            : double.NaN;
            ContributionTradeOrder.TradeAmount = new CAmount(Property.ParseDouble(txtAmount.RealValue));
            ContributionTradeOrder.TradeQuantity = new CQuantity(Property.ParseDouble(txtQuantity.RealValue));
            ContributionTradeOrder.ETradeEnteredAs =
                rdQuantityFixed.Checked ? AllocationEnteredAs.QTY : AllocationEnteredAs.AMT;
            //ContributionTradeOrder.TradePrice =
            //                        chkOverride.Checked
            //                            ? new CNav(Property.ParseDouble(txtOverridePrice.RealValue))
            //                            : CNav.NaN;
            ContributionTradeOrder.Comment = txtComments.Text;
            //ContributionTradeOrder.Breakups = GetBreakups();
            ContributionTradeOrder.TradeLastModifiedDate = LastModifiedDate;

            ContributionTradeOrder.UserAction = ContributionTradeOrder.InsertPending ? TradeOrderHelper.USERACTION_NEW : TradeOrderHelper.USERACTION_EDIT;

            var currentUser = CSession.User;
            ContributionTradeOrder.TradeUserId = CSession.User.UserID;
            if (!ContributionTradeOrder.InsertPending)
            {
                ContributionTradeOrder.TradeLastModifiedUserId = currentUser.UserID;
            }
        }
        
        #endregion
    }
}