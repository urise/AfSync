﻿using System;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Text;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Export;
using IFS.BusinessLayer.Utilities.ExtensionMethods;
using IFS.Interfaces.Rounding;
using WebUtilities;
using IFS.BusinessLayer.OrderManagementSystem;
using IFS.BusinessLayer.Utilities;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace HedgeFrontier.pages.portfolio
{
    public partial class TradeActivity : CBasePage
    {
        #region Members
        private Portfolio _selectedPortfolio;
        #endregion

        #region Properties
        public Portfolio SelectedPortfolio
        {
            get { return _selectedPortfolio ?? (_selectedPortfolio = IFSSession.Portfolio); }
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            CheckAccessRight(Portfolio.IsPortfolioAccessibleForUser(SelectedPortfolio.PortfolioID), CSession.User);
            if (!IsPostBack)
            {
                var org = Organization.Loader.GetById(CSession.OrganizationID);
                lblClientName.Text = @"Client - " + org.OrganizationName.Trim();
                PopulateDropDowns();
                PouplateDateControls();
                BindGrid();
            }
        }

        protected void ddlPortfolios_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedPorfolioId = CDropDown.GetInt(ddlPortfolios);
            if (selectedPorfolioId > 0)
                IFSSession.PortfolioId = selectedPorfolioId;
            PouplateDateControls();
            BindGrid();
        }

        protected void ddlTransactionType_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        protected void dpFromDate_TextChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        protected void dpToDate_TextChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        protected void bgvTradeActvity_OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            switch (e.Row.RowType)
            {
                case DataControlRowType.DataRow:
                    ProcessRow(e.Row);
                    break;
                case DataControlRowType.Header:
                    e.Row.Cells[14].Visible = Role.IsAdminRole(CSession.User.UserRoleID);
                    break;
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteTrade(hdnTradeToDelete.Value);
            hdnTradeToDelete.Value = string.Empty;
            txtReasonForDelete.Text = string.Empty;
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            //Binding for the Refresh to show the latest Details
            PouplateDateControls();
            BindGrid();
        }

        protected void btnExport_OnClick(object sender, EventArgs e)
        {
            GenerateExcelExport();
        }

        protected void btnApproveReject_OnClick(object sender, EventArgs e)
        {
            var processor = TradeOrderHelper.GetTradeProcessor();
            var idsToApprove = hdnApprovalOrders.Value.Split(',').ToIntList();
            var idsToReject = hdnRejectionOrders.Value.Split(',').ToIntList();

            var tradesByAction = new Dictionary<ETradeApprovalAction, List<int>>
                {
                    {ETradeApprovalAction.APPROVED, idsToApprove},
                    {ETradeApprovalAction.REJECTED, idsToReject}
                };
        
            var errmsgs = processor.BulkApproveOrRejectTradeOrder(tradesByAction, txtApprovalComment.Text, CSession.User.UserID);
            if(errmsgs.Count > 0)
            {
                var sb = new StringBuilder();
                errmsgs.ForEach(msg => sb.AppendLine(msg));
                CPopup.Alert(Page,sb.ToString());
            }

            CSession.Portfolios = null;
            BindGrid();
        }

        protected void btnForceRunTradeOrder_OnClick(object sender, EventArgs e)
        {
            var moveToState = ddlMoveToState.SelectedIndex == 0 ? TradeOrderHelper.GetApprovalStepString(txtApprovallevel.Text) : TradeOrderHelper.REJECTED;
            var processor = TradeOrderHelper.GetTradeProcessor();
            int tradeId;
            if(int.TryParse(hdnTradeToForceRun.Value, out tradeId) && tradeId > 0)
            {
                processor.TradeOrder = TradeOrderHelper.GetTradeOrderCloneFromPorfolio(null, tradeId);
                processor.ForceRunTradeOrder(moveToState,txtResetComments.Text,CSession.User);
            }
            CSession.Portfolios = null;
            BindGrid();
        }
        #region Methods

        private void GenerateExcelExport()
        {
            try
            {
                var selectedPortId = CDropDown.GetInt(ddlPortfolios);
                var portfolioName = selectedPortId <= 0 ? "All" : Portfolio.Loader.GetById(selectedPortId).FullName;

                Response.ClearHeaders();
                Response.ClearContent();
                Response.Clear();
                Response.Buffer = true;
                Response.ContentType = AfOpenExcelHelper.EXCEL_EXPORT_CONTENT_TYPE;
                Response.AddHeader("content-disposition", "attachment; filename=TradeActivityExport.xlsx");
                Response.Charset = "";

                using (var memStream = new MemoryStream())
                {
                    var excelGenerator = new TradeActivityExportGenerator(GetTradeActivity());
                    var org = CSession.CurrentOrganization;
                    excelGenerator.ClientName = IFSStringUtil.RemoveSpecialCharacters(org.OrganizationName);
                    excelGenerator.PortfolioName = portfolioName;
                    excelGenerator.FromDate = dpFromDate.DateTime;
                    excelGenerator.ToDate = dpToDate.DateTime;
                    excelGenerator.TransactionType = ddlTransactionType.SelectedItem.Text;
                    excelGenerator.Status = ddlStatus.SelectedItem.Text;
                    excelGenerator.GenerateExcelExport(memStream);
                    memStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                }
            }
            catch(Exception)
            {
                Response.ClearHeaders();
                Response.Clear();
                CPopup.Alert(Page, "Error generating Export. Please try again.");
            }
            Response.End();
        }

        private void PopulatePortfolios()
        {
            var tradeExecutionPortfolios = CSession.Portfolios.Where(p => p.IsTradeExecution);
            ddlPortfolios.DataSource = tradeExecutionPortfolios;
            ddlPortfolios.DataBind();
            CDropDown.BlankItem(ddlPortfolios, "All");
        }

        private void PopulateDropDowns()
        {
            PopulatePortfolios();
            PopulateTransactionTypes();
            PopulateTradeStatus();
        }

        private void PopulateTransactionTypes()
        {
            CDropDown.Add(ddlTransactionType,"ALL","");
            TradeOrderType.LST_ALL_TYPES.ForEach(type => CDropDown.Add(ddlTransactionType, type, type));
        }

        private void PopulateTradeStatus()
        {
            CDropDown.Add(ddlStatus, "ALL", "");
            TradeOrderHelper.GetStatusForTradeActivity().ForEach(status => CDropDown.Add(ddlStatus,status,status));
        }

        private void PouplateDateControls()
        {
            dpFromDate.DateTime = DateUtil.GetBeginningOfMonthDate(DateTime.Today);
            dpToDate.DateTime = DateTime.MaxValue;
        }

        private void BindGrid()
        {
            var tradeActivity = GetTradeActivity();
            if (dpToDate.DateTime.Date == DateTime.MaxValue.Date)
                dpToDate.DateTime = GetLastOrderMonthEnd(tradeActivity);

            bgvTradeActvity.DataSource = tradeActivity;
            bgvTradeActvity.DataBind();

            if (bgvTradeActvity.HeaderRow != null)
            {
                bgvTradeActvity.HeaderRow.Style.Add("top", "expression(this.offsetParent.scrollTop)");
                bgvTradeActvity.HeaderRow.Style.Add("position", "relative");
            }
        }

        private List<BaseTradeOrder> GetTradeActivity()
        {
            var toDate = dpToDate.DateTime == DateTime.MinValue ? DateTime.MaxValue : dpToDate.DateTime;
            var tradeActivity = TradeOrderHelper.GetTradeActivity(CDropDown.GetInt(ddlPortfolios),
                ddlTransactionType.SelectedValue, ddlStatus.SelectedValue, dpFromDate.DateTime, toDate);

            tradeActivity = tradeActivity.OrderBy(o => o.TradeDate).ToList();
            return tradeActivity;
        }

        private static DateTime GetLastOrderMonthEnd(IList<BaseTradeOrder> tActivity)
        {
            return tActivity.Count == 0 ? DateUtil.GetEndOfMonthDate(DateTime.Today) : tActivity.Last().TradeDate;
        }

        private void DeleteTrade(string strTradeId)
        {
            int tradeId;
            if (!int.TryParse(strTradeId, out tradeId))
            {
                CPopup.Alert(Page, "Invalid TradeID supplied");
                BindGrid();
            }
            else
            {
                try
                {
                    var processor = TradeOrderHelper.GetTradeProcessor();
                    var tradeOrderToDelete = TradeOrderHelper.GetTradeOrderFromPorfolio(null, tradeId);
                    processor.TradeOrder = tradeOrderToDelete;
                    var currentUser = CSession.User;
                    var metadata = new TradeOrderWorkflowMetaData
                        {
                            TradeOrderIn = tradeOrderToDelete,
                            TradeUserRoleId = currentUser.UserRoleID,
                            CurrentUserId = currentUser.UserID
                        };

                    processor.CancelTradeOrder(txtReasonForDelete.Text, metadata, currentUser);
                    CSession.Portfolios = null;
                    BindGrid();
                }
                catch (ValidationException valEx)
                {
                    CPopup.Alert(Page, valEx.Message);
                }
            }
        }

        private static void ProcessRow(GridViewRow row)
        {
            var lnkDelete = (HtmlAnchor)row.FindControl("lnkDelete");
            var lnkTradeDate = (HtmlAnchor)row.FindControl("hlnkTradeDate");
            var lnkHistory = (HtmlAnchor)row.FindControl("lnkHistory");
            var rowChkAccept = (CheckBox)row.FindControl("chkApprove");
            var rowChkReject = (CheckBox)row.FindControl("chkReject");
            var hdnTradeOrderId = (HiddenField) row.FindControl("hdnTradeOrderId");

            string tradeId = DataBinder.Eval(row.DataItem, "TradeOrderID").ToString();
            hdnTradeOrderId.Value = tradeId;

            rowChkAccept.Attributes["onclick"] = "ToggleCheckboxes(this,'" + rowChkReject.ClientID + "');";
            rowChkReject.Attributes["onclick"] = "ToggleCheckboxes(this,'" + rowChkAccept.ClientID + "');"; 

            string currentState = DataBinder.Eval(row.DataItem, "CurrentState").ToString();

            var isCurrentTradeInPendingApp = currentState.Contains(TradeOrderHelper.PENDING_APPROVAL);
            rowChkAccept.Enabled = isCurrentTradeInPendingApp;
            rowChkReject.Enabled = isCurrentTradeInPendingApp;

            var tradeAmount = CAmount.Parse(DataBinder.Eval(row.DataItem, "TradeAmount").ToString());
            var lblTradeAmount = (Label)row.FindControl("lblTradeAmount");
            lblTradeAmount.Text = tradeAmount.ToString(CAmount.FORMAT_STRING);

            var tradeQuantity = CQuantity.Parse(DataBinder.Eval(row.DataItem, "TradeQuantity").ToString());
            var lblTradeQuantity = (Label)row.FindControl("lblTradeQuantity");
            lblTradeQuantity.Text = tradeQuantity.ToString(CQuantity.FORMAT_STRING);

            double tradePct;
            double.TryParse(DataBinder.Eval(row.DataItem, "TradePercentage").ToString(), out tradePct);
            if (!double.IsNaN(tradePct))
            {
                var lblTradePercentage = (Label)row.FindControl("lblTradePercentage");
                lblTradePercentage.Text = string.Format("{0:0.00} %", tradePct);
            }
            DateTime dtTradeDate;
            DateTime.TryParse(DataBinder.Eval(row.DataItem, "TradeDate").ToString(), out dtTradeDate);

            ProcessDeleteLink(lnkDelete, currentState, tradeId);

            lnkHistory.Attributes.Add("onClick", "return OW_ClickTradeHistory(" + tradeId + ");");
            var tradeLnk = GetTradeOrderEditLink(tradeId, DataBinder.Eval(row.DataItem, "TradeFundId").ToString(), DataBinder.Eval(row.DataItem, "TradeType").ToString());

            if (currentState == TradeOrderHelper.TRADE_CANCELLED)
                lnkTradeDate.HRef = "";
            else
                lnkTradeDate.Attributes.Add("onClick", tradeLnk);

            lnkTradeDate.InnerText = dtTradeDate.ToString("MM/dd/yyyy");

            if (currentState == TradeOrderHelper.TRADE_CANCELLED)
            {
                foreach (TableCell cell in row.Cells)
                {
                    cell.BackColor = Color.LightGray;
                    cell.Font.Italic = true;
                }
            }
            bool isAdmin = Role.IsAdminRole(CSession.User.UserRoleID);
            row.Cells[14].Visible = isAdmin;
            if(isAdmin)
            {
                var lnkAdminUsage = (HtmlAnchor)row.FindControl("lnkAdminUsage");
                lnkAdminUsage.Attributes.Add("onClick", "ResetTradeOrder(" + tradeId +");");
            }
        }

        private static void ProcessDeleteLink(HtmlAnchor lnkDelete, string currentState, string tradeId)
        {
            //Decide whether to show the Delete Options div or not on click
            lnkDelete.Visible = currentState != TradeOrderHelper.TRADE_CANCELLED;

            if(lnkDelete.Visible)
            {
                var userRoleId = CSession.User.UserRoleID;
                var errmsg = TradeOrderHelper.ValidateUserForDeleteAction(currentState, userRoleId);
                errmsg = errmsg != null ? "alert('" + errmsg + "');" :
                    "return DeleteTrade(" + tradeId + "," + (Component.RoleHasFullAccess(Component.OMS_PREPARER, userRoleId) || Role.IsAccountantRole(userRoleId)).ToString().ToLower() + ");";

                lnkDelete.Attributes.Add("onClick", errmsg);
            }
        }

        private static string GetTradeOrderEditLink(string tradeOrderId, string fundId, string tradeType)
        {
            string tradeLink ;
            switch(tradeType)
            {
                case TradeOrderType.TRADE_ORDER_SUBSCRIPTION:
                    tradeLink = "OW_EditTrade(" + tradeOrderId + "," + fundId + ")";
                    break;
                case TradeOrderType.TRADE_ORDER_CONTRIBUTION:
                    tradeLink = "OW_EditContributionTrade(" + tradeOrderId + "," + fundId + ")";
                    break;
                case TradeOrderType.TRADE_ORDER_REDEMPTION:
                    tradeLink = "OW_EditRedemptionTrade(" + tradeOrderId + "," + fundId + ")";
                    break;
                case TradeOrderType.TRADE_ORDER_EXCHANGE:
                    tradeLink = "OW_EditExchangeTrade(" + tradeOrderId + "," + fundId + ")";
                    break;
                case TradeOrderType.TRADE_ORDER_TRANSFER:
                case TradeOrderType.TRADE_ORDER_TRANSFER_IN_3:
                case TradeOrderType.TRADE_ORDER_TRANSFER_OUT_3:
                    tradeLink = "OW_EditTransferTrade(" + tradeOrderId + "," + fundId + ")";
                    break;
                default:
                    tradeLink = string.Empty;
                    break;
            }
            return tradeLink;
        }
        #endregion
    }
}
