﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IFS.BusinessLayer.OrderManagementSystem
{
    public class TradeOrderContribution : BaseTradeOrder
    {
        #region Constructors

        public TradeOrderContribution()
        {
            TradeType = TradeOrderType.TRADE_ORDER_CONTRIBUTION;
        }

        public TradeOrderContribution(TradeOrderContribution copy, bool primaryKey)
            : base(copy, primaryKey)
        {
            TradeType = TradeOrderType.TRADE_ORDER_CONTRIBUTION;
        }

        public TradeOrderContribution(TradeOrderContribution source, double scalingFactor)
            : base(source, scalingFactor)
        {
            TradeType = TradeOrderType.TRADE_ORDER_CONTRIBUTION;
        }

        #endregion

    }
}
