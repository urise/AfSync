﻿namespace IFS.BusinessLayer.Import.FeesAndTermsTools.ItemWrapper
{
    public class BasicInformation
    {
        public string Client { get; set; }
        public string Fund { get; set; }
        public string ClassOnly { get; set; }
        public TypedItem<int> Id { get; set; }
        public TypedItem<bool> SidePocket { get; set; }

        public BasicInformation()
        {
            Id = new TypedItem<int>();
            SidePocket = new TypedItem<bool>();
        }

        public bool IsSidePocketEmpty()
        {
            return string.IsNullOrEmpty(SidePocket.String);
        }
    }
}
