﻿using System;
using IFS.BusinessLayer.Import.FeesAndTermsTools.ItemWrapper;

namespace IFS.BusinessLayer.Import.FeesAndTermsTools.Validation
{
    public class BasicInformationValidator
    {
        private readonly BasicInformation _basicInformation;
        private readonly ValidationHelper _validationHelper = new ValidationHelper();

        public BasicInformationValidator(BasicInformation basicInformation)
        {
            _basicInformation = basicInformation;
        }

        public void Validate()
        {
            ValidateClient();
            ValidateFundId();
            ValidateSidePocket();
        }

        private void ValidateClient()
        {
            var organization = Organization.Loader.GetByName(_basicInformation.Client, -1);
            if (organization == null)
                throw new ValidationException("'" + _basicInformation.Client + "' is not a valid 'Organization Name'.");
        }

        private void ValidateFundId()
        {
            var errorMessage = "'" + _basicInformation.Id.String + "' is not a valid 'Fund ID'.";
            int id;

            if (!int.TryParse(_basicInformation.Id.String, out id))
            {
                throw new ValidationException(errorMessage);
            }

            InvestableFund fund;
            try
            {
                fund = InvestableFund.Loader.GetById(id);
            }
            catch (Exception)
            {
                throw new ValidationException(errorMessage);
            }
            if (fund == null)
            {
                throw new ValidationException(errorMessage);
            }
            _basicInformation.Id.Value = id;
        }

        private void ValidateSidePocket()
        {
            _validationHelper.ValidateBoolItem(_basicInformation.SidePocket, "Side Pocket");
        }

    }
}
