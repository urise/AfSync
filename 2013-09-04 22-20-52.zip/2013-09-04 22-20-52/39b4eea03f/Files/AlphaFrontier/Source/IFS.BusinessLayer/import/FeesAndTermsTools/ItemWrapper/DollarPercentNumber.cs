﻿namespace IFS.BusinessLayer.Import.FeesAndTermsTools.ItemWrapper
{
    public class DollarPercentNumber
    {
        public string Type { get; set; }
        public TypedItem<double> Value { get; set; }

        public DollarPercentNumber()
        {
            Value = new TypedItem<double>();
        }

        public bool IsEmpty()
        {
            return string.IsNullOrEmpty(Type) && string.IsNullOrEmpty(Value.String);
        }
    }
}
