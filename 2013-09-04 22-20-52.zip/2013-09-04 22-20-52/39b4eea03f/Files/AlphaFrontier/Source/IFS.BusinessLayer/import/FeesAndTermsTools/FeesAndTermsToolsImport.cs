﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.FundProperty.Fund;
using IFS.BusinessLayer.Import.FeesAndTermsTools.ItemWrapper;
using IFS.Interfaces.Common;

namespace IFS.BusinessLayer.Import.FeesAndTermsTools
{
    public class FeesAndTermsToolsImport
    {
        public FeesAndTermsToolsUploadResult TryImport(IEnumerable<FeesAndTermsToolsItem> items)
        {
            var uploadResult = new FeesAndTermsToolsUploadResult();
            try
            {
                ImportAndSave(items);
            }
            catch (Exception ex)
            {
                uploadResult.ErrorItems.Add(new FeesAndTermsErrorItem { ErrorText = ex.Message });
            }
            return uploadResult;
        }

        private static void ImportAndSave(IEnumerable<FeesAndTermsToolsItem> items)
        {
            var oc = new ObjectContainer();
            ImportAllItems(items, oc);
            SubmitChanges(oc);
        }

        private static void ImportAllItems(IEnumerable<FeesAndTermsToolsItem> items, ObjectContainer oc)
        {
            foreach (var item in items)
            {
                Import(item, oc);
            }
        }

        private static void SubmitChanges(ObjectContainer oc)
        {
            using (var bsd = new BulkSaveData())
            {
                bsd.SubmitChanges(oc);
            }
        }

        private static void Import(FeesAndTermsToolsItem item, ObjectContainer oc)
        {
            var fund = GetFund(item);

            if (fund.OrganizationEntity.FlowFromGsm && fund.HasParentGsmFund)
                return;

            var investableFundProperties = fund.InvestableFundPropeties;

            var redemptionPaymentProperties = investableFundProperties.RedemptionPaymentPolicy;
            var redemptionPolicyProperties = investableFundProperties.RedemptionPolicy;
            var subscriptionPolicyProperties = investableFundProperties.SubscriptionPolicy;

            SaveRedemptionPaymentsSchedule(item.RedemptionPaymentSchedule, redemptionPaymentProperties);
            SaveRedemptionPolicy(item.RedemptionPolicy, redemptionPolicyProperties);
            SaveSubscriptionPolicy(item.RedemptionPolicy, subscriptionPolicyProperties);

            redemptionPaymentProperties.BulkSave(oc);
            redemptionPolicyProperties.BulkSave(oc);
            subscriptionPolicyProperties.BulkSave(oc);
        }

        private static InvestableFund GetFund(FeesAndTermsToolsItem item)
        {
            return InvestableFund.Loader.GetById(item.BasicInformation.Id.Value);
        }

        #region Redemption Payment Schedule

        private static void SaveRedemptionPaymentsSchedule(RedemptionPaymentSchedule redemptionPayment, RedemptionPaymentProperties properties)
        {
            properties.FullPaymentScheduleList.Items = GetPaymentScheduleList(redemptionPayment.FullRedemption);
            properties.PartialPaymentScheduleList.Items = GetPaymentScheduleList(redemptionPayment.PartialRedemption);

            SetFullHoldback(redemptionPayment.FullRedemption.Holdback, properties);
            SetPartialHoldback(redemptionPayment.PartialRedemption.Holdback, properties);

            SetExpectedAuditMonthAndDay(redemptionPayment, properties);

            properties.Schedule = redemptionPayment.Schedule;
        }

        private static List<PaymentSchedule> GetPaymentScheduleList(RedemptionPayment redemptionPayment)
        {
            var filledRows = redemptionPayment.Rows.Where(r => !r.IsEmptyRow());
            return filledRows.Select(r => new PaymentSchedule(r.Percent.Value, r.Days.Value)).ToList();
        }

        private static void SetFullHoldback(RedemptionHoldback holdback, RedemptionPaymentProperties properties)
        {
            if (!holdback.IsEmpty())
            {
                properties.FullRedHoldbackSchedule = CreateHoldbackPaymentSchedule(holdback);
            }
        }

        private static void SetPartialHoldback(RedemptionHoldback holdback, RedemptionPaymentProperties properties)
        {
            if (!holdback.IsEmpty())
            {
                properties.PartialRedHoldbackSchedule = CreateHoldbackPaymentSchedule(holdback);
            }
        }

        private static HoldbackPaymentSchedule CreateHoldbackPaymentSchedule(RedemptionHoldback holdback)
        {
            return new HoldbackPaymentSchedule(
                holdback.Percent.Value,
                holdback.ReceivedDays.Value,
                holdback.ReceivedAfter.Value
                );
        }

        private static void SetExpectedAuditMonthAndDay(RedemptionPaymentSchedule redemptionPayment, RedemptionPaymentProperties properties)
        {
            var expectedAuditMonth = redemptionPayment.ExpectedAuditMonth.Value;
            var expectedAuditDay = redemptionPayment.ExpectedAuditDay.Value;

            if (expectedAuditMonth > 0 && expectedAuditDay > 0)
            {
                properties.ExpectedAuditMonth = expectedAuditMonth;
                properties.ExpectedAuditDay = expectedAuditDay;
            }
        }

        #endregion

        #region Redemption Policy

        private static void SaveRedemptionPolicy(RedemptionPolicy redemptionPolicy, RedemptionPolicyProperties properties)
        {
            properties.Schedule = redemptionPolicy.RedemptionPolicyGroup.Schedule;
            properties.Lockups = GetLockups(redemptionPolicy);
            properties.TotalLockup = GetTotalLockups(redemptionPolicy);
            properties.NoticePeriodFullDays = redemptionPolicy.RedemptionPolicyGroup.NoticePeriodFullDays.Value;
            properties.NoticePeriodFullMethod = redemptionPolicy.RedemptionPolicyGroup.NoticePeriodFullMethod.Value;
            properties.NoticePeriodPartialDays = redemptionPolicy.RedemptionPolicyGroup.NoticePeriodPartialDays.Value;
            properties.NoticePeriodPartialMethod = redemptionPolicy.RedemptionPolicyGroup.NoticePeriodPartialMethod.Value;
            properties.MinBalance = GetDollarPercentTabNumber(redemptionPolicy.RedemptionPolicyGroup.MinBalance);
            properties.GeneralRedemptionFee = GetDollarPercentTabNumber(redemptionPolicy.RedemptionPolicyGroup.GeneralRedFee);
            properties.DistributedDeclaration = redemptionPolicy.DistrDeclaration.Value;

            properties.RedemptionLockupTerm = redemptionPolicy.RedemptionPolicyGroup.LockupTerm.Value;
            properties.RedemptionFrequency = redemptionPolicy.RedemptionPolicyGroup.CustomDate.Value != DateTime.MinValue;
            properties.RedemptionFrequencyDate = redemptionPolicy.RedemptionPolicyGroup.CustomDate.Value;
            properties.RedemptionAfterLockupExpire = redemptionPolicy.RedemptionPolicyGroup.FirstRedAfterLockupExp.Value;
            properties.Liquidity = redemptionPolicy.RedemptionPolicyGroup.Liquidity.Value;
            properties.LiquidityAsOf = redemptionPolicy.RedemptionPolicyGroup.AsOf.Value;
            properties.Minredemption.Value = GetDollarPercentTabNumberValue(redemptionPolicy.RedemptionPolicyGroup.MinRedemption);
            properties.Maxredemption.Value = GetDollarPercentTabNumberValue(redemptionPolicy.RedemptionPolicyGroup.MaxRedemption);
            properties.RedemptionGate = redemptionPolicy.Gate.Value;
        }

        private static List<Lockup> GetLockups(RedemptionPolicy redemptionPolicy)
        {
            var filledLockups = GetFilledLockups(redemptionPolicy);
            return filledLockups.Select(r => new Lockup
            {
                LockupType = r.LockupType,
                Fee = new CDollarPercentTabNumber { DollarOrPercent = r.FeeType, Number = r.FeeNumber.Value, },
                Years = r.Years.Value,
                Months = r.Months.Value,
                Days = r.Days.Value,
            }).ToList();
        }

        private static List<RedemptionFee> GetFilledLockups(RedemptionPolicy redemptionPolicy)
        {
            return redemptionPolicy.RedemptionPolicyGroup.Lockups.Where(lockup => !lockup.IsEmpty()).ToList();
        }

        private static Lockup GetTotalLockups(RedemptionPolicy redemptionPolicy)
        {
            var filledLockups = GetFilledLockups(redemptionPolicy);
            return new Lockup
            {
                Years = filledLockups.Sum(lockup => lockup.Years.Value),
                Months = filledLockups.Sum(lockup => lockup.Months.Value),
                Days = filledLockups.Sum(lockup => lockup.Days.Value),
            };
        }

        private static CDollarPercentTabNumber GetDollarPercentTabNumber(DollarPercentNumber dollarPercentNumber)
        {
            CDollarPercentTabNumber dollarPercentTabNumber = null;
            if (!dollarPercentNumber.IsEmpty())
            {
                dollarPercentTabNumber = new CDollarPercentTabNumber
                {
                    DollarOrPercent = dollarPercentNumber.Type,
                    Number = dollarPercentNumber.Value.Value
                };
            }
            return dollarPercentTabNumber;
        }

        private static string GetDollarPercentTabNumberValue(DollarPercentNumber dollarPercentNumber)
        {
            var dollarPercentTabNumber = string.Empty;
            if (!dollarPercentNumber.IsEmpty())
            {
                dollarPercentTabNumber = GetDollarPercentTabNumber(dollarPercentNumber).Value;
            }
            return dollarPercentTabNumber;
        }

        #endregion

        #region Subscription Policy

        private static void SaveSubscriptionPolicy(RedemptionPolicy redemptionPolicy, SubscriptionPolicyProperties properties)
        {
            if (redemptionPolicy.RedemptionPolicyGroup.MinRedemption.IsEmpty())
                return;

            properties.SubscriptionMinSubsequent = redemptionPolicy.RedemptionPolicyGroup.MinRedemption.Value.Value;
        }

        #endregion
    }
}
