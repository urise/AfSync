﻿using IFS.BusinessLayer.Import.FeesAndTermsTools.ItemWrapper;

namespace IFS.BusinessLayer.Import.FeesAndTermsTools.Validation
{
    public class DollarPercentNumberValidator
    {
        private readonly ValidationHelper _validationHelper = new ValidationHelper();

        public void Validate(DollarPercentNumber dollarPercentNumber, string fieldName)
        {
            if (dollarPercentNumber.IsEmpty())
                return;

            var type = dollarPercentNumber.Type;
            var number = dollarPercentNumber.Value;

            if (string.IsNullOrEmpty(type))
                throw new ValidationException("'" + fieldName + " $ / %' must be populated since '" + fieldName + "' is populated.");

            if (string.IsNullOrEmpty(number.String))
                throw new ValidationException("'" + fieldName + "' must be populated since '" + fieldName + " $ / %' is populated.");

            _validationHelper.ValidateDoubleItem(number, fieldName);

            if (type != "%" && type != "$")
                throw new ValidationException("'" + fieldName + " $ / %' must have '$' or '%' value.");

            if (type == "%" && (number.Value > 100))
                throw new ValidationException("'" + fieldName + "' can not be greater than 100%.");
        }
    }
}
