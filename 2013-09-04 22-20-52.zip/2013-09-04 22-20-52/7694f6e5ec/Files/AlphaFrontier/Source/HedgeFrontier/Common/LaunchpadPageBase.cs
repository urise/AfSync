﻿using System;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Launchpad;
using IFS.BusinessLayer.Fund.FundProperties;
using IFS.Interfaces.Rounding;
using System.Drawing;

/// <summary>
/// Base class for all launchpad pages.
/// </summary>
public class LaunchpadPageBase: CBasePage
{
    protected const string PERCENT = "%";
    //  TODO: extract common behavior (init 3D style) to chart base control as soon as design finally approved

    /// <summary>
    /// Calculates start and end report dates for the specified list of portfolios.
    /// </summary>
    /// <param name="portfolioList">List of portfolio identifiers to calculate report dates against.</param>
    /// <param name="isDuplicateDates">If "True" - lists StartDates and EndDates are equals.</param>
    /// <returns>Returns JSON-serialized object which has start/end dates collections under corresponding properties.</returns>
    [WebMethod]
    public static string GetPortfoliosReportDates(int[] portfolioList, bool isDuplicateDates = false)
    {
        var dates = PortfolioReportDatesProvider.GetReportDatesForPortfolioList(portfolioList)
                                                .Where(d => d.Key != PortfolioReportDatesProvider.OptionsEndDatesKeyName)
                                                .ToDictionary(d=> d.Key, d=> d.Value);
        //ToDo: Please move the isDuplicates logic inside GetReportDatesForPortfolioList
        if (isDuplicateDates)
        {
            var toDates = dates[PortfolioReportDatesProvider.EndDatesKeyName];
            if(toDates != null)
            {
                var lstToDates = new List<string>(toDates);
                dates[PortfolioReportDatesProvider.StartDatesKeyName] = lstToDates.Where(dt => !dt.Contains("Today"));
            }
        }
        return new JavaScriptSerializer().Serialize(dates);
    }

    [WebMethod]
    public static string GetPortfoliosStrategies(int [] portfolioList)
    {
        var portfilios = portfolioList.Select(Portfolio.GetById).ToList();
        var strategies = PortfolioStrategiesProvider.GetStrategiesForPortfolios(portfilios).ToDictionary(p => p.Key.ToString(), p => p.Value);
        return new JavaScriptSerializer().Serialize(strategies);
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        if(!Organization.Loader.GetById(CSession.OrganizationID).IsLaunchpadAvailable)
            Response.Redirect("~/pages/Launchpad/LaunchpadIsNotAvailableForTheClient.aspx", false);
    }

    protected void AddPiePointWithTooltip(DataPointCollection chartPoints, double weight, string preLegendText, bool appendPercent = true)
    {
        var currentIndex = chartPoints.Count;
        var weightPercent = weight.ToString(CPercent.FORMAT_STRING);
        chartPoints.AddY(weight);
        chartPoints[currentIndex].LegendText = appendPercent ? preLegendText + " - " + weightPercent : preLegendText;
        chartPoints[currentIndex].ToolTip = weightPercent;
    }

    protected void AddPiePointWithTooltip(ICollection<object> data, double weight, string preLegendText, bool appendPercent = true)
    {

        var weightPercent = weight.ToString(CPercent.FORMAT_STRING);
        data.Add(new object[] { appendPercent ? preLegendText + " - " + weightPercent : preLegendText, weight });
    }

    public static void SetChartCurrencySymbol(IEnumerable<Chart> charts, string currencyId, bool setTooltip = false)
    {
        if (charts != null)
        {
            foreach (var chart in charts)
            {
                var currencySymbol = Currency.GetSymbol(currencyId);
                chart.ChartAreas[0].AxisY.LabelStyle.Format = currencySymbol + "#,##0;" + currencySymbol + "(#,##0)";
                if (setTooltip)
                {
                    foreach (var series in chart.Series)
                    {
                        series.ToolTip = currencySymbol + "#VALY{#,##0;(#,##0)}";
                    }
                }
            }
        }
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        IncludeHighChartJsScript();
    }

    protected void IncludeHighChartJsScript()
    {
        const string key = "HighCharts";
        const string keyThemeGrid = "HighChartsThemeGrid";
        if (!Page.ClientScript.IsClientScriptBlockRegistered(key))
        {
            Page.ClientScript.RegisterClientScriptInclude(key, ResolveUrl("~/scripts/Highcharts/highcharts.js"));
            Page.Header.Controls.Add(new LiteralControl("<link rel=\"stylesheet\" type=\"text/css\" href=\"" + ResolveUrl("~/Styles/highcharts.css") + "\" />"));
        }
        if (!Page.ClientScript.IsClientScriptBlockRegistered(key))
        {
            Page.ClientScript.RegisterClientScriptInclude(keyThemeGrid, ResolveUrl("~/scripts/Highcharts/themes/grid.js"));
        }
    }

    protected static Color FixColorForIE8(Color color)
    {
        return Color.FromArgb(color.ToArgb());
    }
}