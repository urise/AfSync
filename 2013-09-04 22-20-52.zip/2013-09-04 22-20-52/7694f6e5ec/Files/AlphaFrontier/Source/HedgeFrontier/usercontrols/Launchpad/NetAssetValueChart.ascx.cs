﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using DotNet.Highcharts.Options;
using IFS.BusinessLayer.Fund.FundProperties;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Launchpad;
using IFS.BusinessLayer.Launchpad.NAV;
using IFS.Interfaces.Rounding;
using Data = DotNet.Highcharts.Helpers.Data;
using Series = DotNet.Highcharts.Options.Series;

public partial class pages_launchpad_Graphs_NetAssetValueChart : System.Web.UI.UserControl
{
    public string CurrencyId { get; set; }

    /// <summary>
    /// Handles Load event of the page.
    /// </summary>
    /// <param name="sender">Event sender.</param>
    /// <param name="e">Event arguments.</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        var launchpadOptions = GetLaunchpadSettings();
        CurrencyId = launchpadOptions.CurrencyId;
        if (NeedRefreshNavDetails())
        {
            SelectedPortfolioList.LaunchpadOptions = launchpadOptions;
            IDictionary<string, bool> portfolioNames = GetPortfoliosFromIdList(launchpadOptions.Portfolios);
            SetWarning(portfolioNames);
            DateTime toDate = launchpadOptions.ToDate.HasValue ? launchpadOptions.ToDate.Value : DateTime.MinValue;
            var navData = new LaunchpadNavCalculator(launchpadOptions.Portfolios, launchpadOptions.CurrencyId, toDate).Calculate(toDate);
            SetNavDetails(navData);
        }
    }

    /// <summary>
    /// Gets launchpad settings.
    /// </summary>
    /// <returns></returns>
    private LaunchpadOptionsBase GetLaunchpadSettings()
    {
        return IsPostBack ? ChartOptions.GetLaunchpadSettings() : ChartOptions.LoadPreferences();
    }

    /// <summary>
    /// Check if NAV values is already filled or it's first time page loaded
    /// </summary>
    /// <returns></returns>
    private bool NeedRefreshNavDetails()
    {
        return IsPostBack || string.IsNullOrEmpty(lblBeginningNetAssetValue.Text);
    }

    /// <summary>
    /// Gets a list of portfolios based on provided list of portfolio identifiers.
    /// </summary>
    /// <param name="idList">List of portfolio identifiers.</param>
    /// <returns>Returns list of portfolios.</returns>
    private static IDictionary<string, bool> GetPortfoliosFromIdList(IEnumerable<int> idList)
    {
        return (from porfolioId in idList
                let port = Portfolio.GetById(porfolioId)
                select new { port.PortfolioName, port.InitialNav }).ToDictionary(data => data.PortfolioName, data => RoundingBase.IsNaN(data.InitialNav));
    }

    /// <summary>
    /// Fill NAV details for selected portfolio
    /// </summary>
    /// <param name="navData">Calculated navData</param>
    private void SetNavDetails(INavData navData)
    {
        SetNavTable(new NavDataView(navData));
        var navDataViews = GetMonthlyData(navData);

        var currencySymbol = Currency.GetSymbol(CurrencyId);

        BindYtdPortfoliosAum(navDataViews, currencySymbol);
        BindYtdPortfolioPnL(navDataViews, currencySymbol);
        BindPortfolioMtdYtdRor(navDataViews);
    }

    #region YtdPortfoliosAum
    private DotNet.Highcharts.Highcharts InitializeYtdPortfoliosAumChart(string currencySymbol)
    {
        var chart = new DotNet.Highcharts.Highcharts("YtdPortfoliosAum").InitChart(new Chart { Width = 498 }).SetCredits(new Credits { Enabled = false });
        chart.SetTitle(new Title { Text = "YTD Portfolios AUM" });
        chart.SetYAxis(new YAxis { Title = new YAxisTitle { Text = "Millions" }, Labels = new YAxisLabels { Format = currencySymbol + " {value} " } });
        chart.SetTooltip(new Tooltip { ValuePrefix = currencySymbol, ValueDecimals = 2 });
        return chart;
    }

    private void BindYtdPortfoliosAum(NavDataView[] navDataViews, string currencySymbol)
    {
        var chart = InitializeYtdPortfoliosAumChart(currencySymbol);
        var categoriesX = new string[navDataViews.Count()];
        var dataPortfolioAum = new object[navDataViews.Count()];

        for (var ind = 0; ind < navDataViews.Length; ind++)
        {
            var navDataView = navDataViews[ind];
            categoriesX[ind] = navDataView.AsOfDateString;
            dataPortfolioAum[ind] = navDataView.ClosingNav;
        }
        chart.SetXAxis(new XAxis {Categories = categoriesX, Labels = new XAxisLabels {Rotation = -45}});
        chart.SetSeries(new Series { Name = "AUM", Data = new Data(dataPortfolioAum), Color = Color.FromArgb(Color.Green.ToArgb()) });
        containerYtdPortfoliosAum.Text = chart.ToHtmlString();
    }

    #endregion

    #region YtdPortfolioPnL
    private DotNet.Highcharts.Highcharts InitializeYtdPortfolioPnLChart(string currencySymbol)
    {
        var chart = new DotNet.Highcharts.Highcharts("YtdPortfolioPnL").InitChart(new Chart { Width = 498 }).SetCredits(new Credits { Enabled = false });
        chart.SetTitle(new Title { Text = "Portfolio PnL" });
        chart.SetYAxis(new YAxis { Title = new YAxisTitle { Text = "Millions" }, Labels = new YAxisLabels { Format = currencySymbol + " {value} " } });
        chart.SetTooltip(new Tooltip { ValuePrefix = currencySymbol, ValueDecimals = 2 });
        return chart;
    }

    private void BindYtdPortfolioPnL(NavDataView[] navDataViews, string currencySymbol)
    {
        var chart = InitializeYtdPortfolioPnLChart(currencySymbol);
        var categoriesX = new string[navDataViews.Length];

        var datadMonthlyPnLFof = new object[navDataViews.Length];
        var dataMonthlyGlsTotal = new object[navDataViews.Length];
        var datadMonthlyTotalIncome = new object[navDataViews.Length];
        for (var ind = 0; ind < navDataViews.Length; ind++)
        {
            var navDataView = navDataViews[ind];
            categoriesX[ind] = navDataView.AsOfDateString;
            datadMonthlyPnLFof[ind] = navDataView.FofPnl;
            dataMonthlyGlsTotal[ind] = navDataView.GlsTotal;
            datadMonthlyTotalIncome[ind] = navDataView.TotalIncome;
        }
        chart.SetXAxis(new XAxis { Categories = categoriesX, Labels = new XAxisLabels { Rotation = -45 } });
        chart.SetSeries(new[]
                            {
                                new Series { Name = "FoHF PnL", Data = new Data(datadMonthlyPnLFof), Color = Color.FromArgb(Color.Green.ToArgb()) },
                                new Series { Name = "NonFoHFPnl/Exps/Income", Data = new Data(dataMonthlyGlsTotal), Color = Color.FromArgb(Color.DeepSkyBlue.ToArgb()) },
                                new Series { Name = "Combo of all", Data = new Data(datadMonthlyTotalIncome), Color = Color.FromArgb(Color.Violet.ToArgb()) }
                            });
        containerYtdPortfolioPnL.Text = chart.ToHtmlString();
    }

    #endregion

    #region PortfolioMtdYtdRor
    private DotNet.Highcharts.Highcharts InitializeportfolioMtdYtdRorChart()
    {
        var chart = new DotNet.Highcharts.Highcharts("PortfolioMtdYtdRor").InitChart(new Chart { Width = 498 }).SetCredits(new Credits { Enabled = false });
        chart.SetTitle(new Title { Text = "Portfolio MTD / 1 Year Rolling ROR" });
        chart.SetYAxis(new YAxis { Title = new YAxisTitle { Text = "" }, Labels = new YAxisLabels { Format = " {value} %" } });
        chart.SetTooltip(new Tooltip { ValueSuffix = "%", ValueDecimals = 2 });
        return chart;
    }

    private void BindPortfolioMtdYtdRor(NavDataView[] navDataViews)
    {
        var chart = InitializeportfolioMtdYtdRorChart();
        var categoriesX = new string[navDataViews.Length];
        var dataMtdPortfolio = new object[navDataViews.Count()];
        var dataYtdPortfolio = new object[navDataViews.Count()];

        for (var ind = 0; ind < navDataViews.Length; ind++)
        {
            var navDataView = navDataViews[ind];
            categoriesX[ind] = navDataView.AsOfDateString;
            dataMtdPortfolio[ind] = navDataView.Mtd * 100;
            dataYtdPortfolio[ind] = navDataView.Ytd * 100;
        }
        chart.SetXAxis(new XAxis { Categories = categoriesX, Labels = new XAxisLabels { Rotation = -45 } });
        chart.SetSeries(new[]
                            {
                                new Series { Name = "MTD", Data = new Data(dataMtdPortfolio), Color = Color.FromArgb(Color.Green.ToArgb()) },
                                new Series { Name = "YTD", Data = new Data(dataYtdPortfolio), Color = Color.FromArgb(Color.DeepSkyBlue.ToArgb()) }
                            });
        containerPortfolioMtdYtdRor.Text = chart.ToHtmlString();
    }

    #endregion

    private void SetWarning(IEnumerable<KeyValuePair<string, bool>> selectedPortfolio)
    {
        bool hasSkipped = false;
        var msg = new StringBuilder();
        foreach (var portfolio in selectedPortfolio)
        {
            if (portfolio.Value)
            {
                msg.AppendLine("- " + portfolio.Key + ";<BR>");
                if (!hasSkipped) hasSkipped = true;
            }
        }
        if (hasSkipped)
        {
            ucWarningPopup.WarningMessage = "Please set initial Nav and initial Nav date for the following portfolio(s):<BR><BR>" + msg;
            Page.ClientScript.RegisterStartupScript(GetType(), "ShowWarning", "<script>ShowWarning();</script>");
        }
    }

    /// <summary>
    /// Fill NAV details table for selected portfolio
    /// </summary>
    /// <param name="navData"></param>
    private void SetNavTable(NavDataView navData)
    {
        lblBeginningNetAssetDate.Text = navData.BeginningAsOfDateString;
        lblBeginningNetAssetValue.Text = navData.BeginningNavString;
        lblInvestorReds.Text = navData.InvestorsRedsString;
        lblInvestorSubs.Text = navData.InvestorsSubsString;
        lblInvestorTotal.Text = navData.IssTotalString;
        lblOpeningNetAssetValue.Text = navData.OpeningNavString;
        lblFoFPnL.Text = navData.FofPnlString;
        lblNonFoFPnL.Text = navData.NonFofPnlString;
        lblOtherIncome.Text = navData.OtherIncomeString;
        lblExpenses.Text = navData.ExpensesString;
        lblTotalIncome.Text = navData.TotalIncomeString;
        lblClosingNetAssetDate.Text = navData.AsOfDateString;
        lblClosingNetAssetValue.Text = navData.ClosingNavString;
        lblMTD.Text = navData.MtdString;
        lblYTD.Text = navData.YtdString;
    }

    private const int MONTH_COUNT = 12;

    private static NavDataView[] GetMonthlyData(INavData navData)
    {
        var navDataViews = new NavDataView[MONTH_COUNT];
        INavData prevNavData = navData;
        for (int i = MONTH_COUNT - 1; i >= 0; i--)
        {
            navDataViews[i] = new NavDataView(prevNavData);
            if(prevNavData.PreviousMonthNav != null)
            {
                prevNavData = prevNavData.PreviousMonthNav;
            }
            else
            {
                DateTime prevDate = prevNavData.AsOfDate == DateTime.MinValue ? DateTime.MinValue : new DateTime(prevNavData.AsOfDate.Year, prevNavData.AsOfDate.Month, 1).AddDays(-1);
                prevNavData = prevNavData.EmptyNavData(prevDate);
            }
        }
        return navDataViews;
    }
}