﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using DotNet.Highcharts.Enums;
using DotNet.Highcharts.Helpers;
using DotNet.Highcharts.Options;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Launchpad;
using IFS.Interfaces.Rounding;
using Data = DotNet.Highcharts.Helpers.Data;
using Series = DotNet.Highcharts.Options.Series;

namespace pages.launchpad
{
    public partial class InvestmentSummary : LaunchpadPageBase
    {
        private Dictionary<string, string> _captions = new Dictionary<string, string>();

        public Dictionary<string, string> Captions
        {
            get { return _captions; }
            set { _captions = value; }
        }

        private Color[] _defaultColors =  new[] { FixColorForIE8(Color.Orange), FixColorForIE8(Color.Green), FixColorForIE8(Color.Red), FixColorForIE8(Color.DeepSkyBlue)};

        protected void Page_Load(object sender, EventArgs e)
        {
            var launchpadOptions = IsPostBack ? ChartOptions.GetLaunchpadSettings() : ChartOptions.LoadPreferences();
            InitCatpions(Captions);
            BindPortfolioAllocationData(launchpadOptions);
            //SetChartCurrencySymbol(new[] { NetAssetChart.YtdMonthlyAum, NetAssetChart.YtdMonthlyPnL }, launchpadOptions.CurrencyId);
            SelectedPortfolioList.LaunchpadOptions = launchpadOptions;
            SelectedPortfolioList.BindControls();
        }

        private void InitCatpions(Dictionary<string, string> captions)
        {
            captions.Add(PortfolioAllocationCalculator.HedgeFund, "Hedge Funds");
            captions.Add(PortfolioAllocationCalculator.Cash, "Cash");
            captions.Add(PortfolioAllocationCalculator.PrivateEquityFund, "Private Equity");
            captions.Add(PortfolioAllocationCalculator.NonHedgeFund, "Non Hedge Funds");
        }

        private void BindPortfolioAllocationData(LaunchpadOptionsBase launchpadOptions)
        {
            var toDate = launchpadOptions.ToDate.GetValueOrDefault();
            var fromDate = launchpadOptions.FromDate.GetValueOrDefault();
            var seriesPieChart = new List<Series>();

            var cPortAllocation = new PortfolioAllocationCalculator(CSession.OrganizationID, launchpadOptions.Portfolios,
                                                                    fromDate, launchpadOptions.CurrencyId);
            if (cPortAllocation.CalculatePortfolioAllocationData())
            {
                BindFromDateValuesInTable(cPortAllocation.CurrentMonthDfd);
                seriesPieChart.Add(GetPortAllocPieSerie(cPortAllocation.CurrentMonthDfd, fromDate.ToString("d"), 90));
            }

            cPortAllocation = new PortfolioAllocationCalculator(CSession.OrganizationID, launchpadOptions.Portfolios,
                                                                toDate, launchpadOptions.CurrencyId);
            if (cPortAllocation.CalculatePortfolioAllocationData())
            {
                BindToDateValuesInTable(cPortAllocation.CurrentMonthDfd);
                seriesPieChart.Add(GetPortAllocPieSerie(cPortAllocation.CurrentMonthDfd, toDate.ToString("d"), 350));

                BindStackedChart(cPortAllocation.StackedChartData);
                BindLineGraph(cPortAllocation.LineGraphData);
            }

            GeneratePortAllocPieChart(seriesPieChart.ToArray());
        }

        #region Weight by Asset Class Pie Chart

        private DotNet.Highcharts.Highcharts InitializePortAllocPieChart()
        {
            var chart = new DotNet.Highcharts.Highcharts("PortAllocPieChart").SetCredits(new Credits { Enabled = false });
            chart.SetTitle(new Title {Text = "Weight by Asset Class"});
            chart.SetPlotOptions(new PlotOptions {Pie = new PlotOptionsPie {AllowPointSelect = true, DataLabels = new PlotOptionsPieDataLabels {Enabled = false}, ShowInLegend = true}});
            chart.SetTooltip(new Tooltip {PointFormat = "{series.name}: <b>{point.percentage:.2f}"+PERCENT+"</b>"});
            return chart;
        }

        private void GeneratePortAllocPieChart(Series[] series)
        {
            var pieChartPortAlloc = InitializePortAllocPieChart();
            pieChartPortAlloc.SetSeries(series);
            var captions = new LabelsItems[series.Length];
            for (var i = 0; i < series.Length;i++ )
            {
                captions[i] = new LabelsItems { Html = series[i].Name, Style = "top:0, left:" + (series[i].PlotOptionsPie.Center[0].Value)+"-20" };
            }
                
            pieChartPortAlloc.SetLabels(new Labels { Items = captions});
            containerPieChartWeight.Text = pieChartPortAlloc.ToHtmlString();
        }

        private Series GetPortAllocPieSerie(DerivedFundData portAllocDfd, string title, int xAxis)
        {
            var data = new List<object>();
            var isChartEmpty = AddPieSlice(portAllocDfd, data, PortfolioAllocationCalculator.HedgeFund, Color.Orange);
            isChartEmpty &= AddPieSlice(portAllocDfd, data, PortfolioAllocationCalculator.Cash, Color.Green);
            isChartEmpty &= AddPieSlice(portAllocDfd, data, PortfolioAllocationCalculator.PrivateEquityFund, Color.Red);
            isChartEmpty &= AddPieSlice(portAllocDfd, data, PortfolioAllocationCalculator.NonHedgeFund, Color.DeepSkyBlue);
            if (isChartEmpty)
            {
                data.Add(new { name = "No investments", y = 1, color = FixColorForIE8(Color.LightGray) });
            }

            var serie = new Series
            {
                Type = ChartTypes.Pie,
                Name = title,
                PlotOptionsPie = new PlotOptionsPie { Center = new[] { new PercentageOrPixel (xAxis), new PercentageOrPixel (100) }, Size = new PercentageOrPixel(200)},
                Data = new Data(data.ToArray())
            };
            return serie;
        }

        private bool AddPieSlice(DerivedFundData portAllocDfd, ICollection<object> data, string derivedFundDataName, Color color)
        {
            var weight = GetMarketValueWeighting(portAllocDfd, derivedFundDataName);
            data.Add(new { name = Captions[derivedFundDataName], y = weight, color = FixColorForIE8(color) });
            return weight <= 0;
        }

        private static double GetMarketValueWeighting(DerivedFundData portAllocDfd, string derivedFundDataName)
        {
            var result = 0D;
            var fundData = portAllocDfd.ChildNodes.FirstOrDefault(x => x.Name == derivedFundDataName);
            if (fundData != null)
            {
                result = fundData.FundAccountingData.MarketValueWeighting;
            }
            return result;
        }
#endregion

#region Weight by Asset Class History Line Chart
        private DotNet.Highcharts.Highcharts InitializePortAllocLineChart()
        {
            var chart = new DotNet.Highcharts.Highcharts("PortAllocLineChart").SetCredits(new Credits { Enabled = false });
            chart.SetTitle(new Title { Text = "Weight By Asset Class History" });
            chart.SetYAxis(new YAxis { Title = new YAxisTitle { Text = "" }, Max = 100, Min = 0, Labels = new YAxisLabels { Format = " {value} "+PERCENT } });
            chart.SetTooltip(new Tooltip { ValueSuffix = PERCENT, ValueDecimals = 2});
            chart.SetOptions(new GlobalOptions { Colors = _defaultColors });
            return chart;
        }

        private void BindLineGraph(Dictionary<DateTime, DerivedFundData> lineGraphData)
        {
            var lineChart = InitializePortAllocLineChart();
            var data = new Dictionary<string, List<object>>
                           {
                               {PortfolioAllocationCalculator.HedgeFund, new List<object>()},
                               {PortfolioAllocationCalculator.Cash, new List<object>()},
                               {PortfolioAllocationCalculator.PrivateEquityFund, new List<object>()},
                               {PortfolioAllocationCalculator.NonHedgeFund, new List<object>()},
                           };
            var categoriesX = new List<string>();
            foreach (var pair in lineGraphData)
            {
                categoriesX.Add(pair.Key.ToShortDateString());
                var dfd = pair.Value;
                foreach (var fundData in dfd.ChildNodes)
                {
                    List<object> serie;
                    if (data.TryGetValue(fundData.Name, out serie))
                    {
                        var value = fundData.FundAccountingData.MarketValueWeighting * 100;
                        serie.Add(value);
                    }
                }
            }
            lineChart.SetXAxis(new XAxis { Labels = new XAxisLabels { Rotation = -45 }, Categories = categoriesX.ToArray() });
            lineChart.SetSeries(data.Select(pair => new Series { Name = Captions[pair.Key], Data = new Data(pair.Value.ToArray()) }).ToArray());
            containerLineChartWeight.Text = lineChart.ToHtmlString();
        }
#endregion
#region Weight By Asset Class Comparison Column Chart
        private DotNet.Highcharts.Highcharts InitializePortAllocColumnChart()
        {
            var chart = new DotNet.Highcharts.Highcharts("PortAllocColumnChart").SetCredits(new Credits { Enabled = false });
            chart.SetTitle(new Title { Text = "Weight By Asset Class Comparison" });
            chart.SetYAxis(new YAxis { Title = new YAxisTitle { Text = "" }, Labels = new YAxisLabels { Format = " {value} " + PERCENT } });
            chart.SetTooltip(new Tooltip { ValueSuffix = PERCENT, ValueDecimals = 2 });
            chart.SetOptions(new GlobalOptions { Colors = _defaultColors });
            chart.SetPlotOptions(new PlotOptions { Column = new PlotOptionsColumn { Stacking = Stackings.Percent } });
            return chart;
        }

        private void BindStackedChart(Dictionary<int, DerivedFundData> stackedChartData)
        {
            var colChart = InitializePortAllocColumnChart();
            var data = new Dictionary<string, List<object>>
                           {
                               {PortfolioAllocationCalculator.HedgeFund, new List<object>()},
                               {PortfolioAllocationCalculator.Cash, new List<object>()},
                               {PortfolioAllocationCalculator.PrivateEquityFund, new List<object>()},
                               {PortfolioAllocationCalculator.NonHedgeFund, new List<object>()},
                           };
            var categoriesX = new List<string>();
            foreach (var pair in stackedChartData)
            {
                var id = pair.Key;
                var portfolioDfd = pair.Value;
                foreach (var k in data.Keys)
                {
                    data[k].Add(GetMarketValueWeighting(portfolioDfd.ChildNodes.Find(dfd => dfd.Name == k)));
                }
                var portfolio = Portfolio.Loader.GetById(id);
                categoriesX.Add(portfolio.PortfolioName);
            }
            colChart.SetXAxis(new XAxis { Categories = categoriesX.ToArray() });
            colChart.SetSeries(data.Select(pair => new Series { Type = ChartTypes.Column, Name = Captions[pair.Key], Data = new Data(pair.Value.ToArray()) }).ToArray());
            containerColumnChartWeight.Text = colChart.ToHtmlString();
        }

        private double GetMarketValueWeighting(DerivedFundData dfd)
        {
            return dfd == null ? 0D : (double.IsNaN(dfd.FundAccountingData.MarketValueWeighting) ? 0D : dfd.FundAccountingData.MarketValueWeighting * 100);
        }

#endregion
        private void BindFromDateValuesInTable(DerivedFundData portAllocDfd)
        {
            foreach (DerivedFundData derivedFundData in portAllocDfd.ChildNodes)
            {
                var percentString = new CPercent(derivedFundData.FundAccountingData.MarketValueWeighting).ToString(CPercent.FORMAT_STRING);
                var mvString = derivedFundData.FundAccountingData.MarketValueBase.ToString(CAmount.FORMAT_STRING_ROUNDING);
                switch (derivedFundData.Name)
                {
                    case PortfolioAllocationCalculator.HedgeFund:
                        lblHfFromDateMv.Text = mvString;
                        lblHfFromDateWeight.Text = percentString;
                        break;
                    case PortfolioAllocationCalculator.PrivateEquityFund:
                        lblPeFromDateMv.Text = mvString;
                        lblPeFromDateWeight.Text = percentString;
                        break;
                    case PortfolioAllocationCalculator.Cash:
                        lblCashFromDateMv.Text = mvString;
                        lblCashFromDateWeight.Text = percentString;
                        break;
                    case PortfolioAllocationCalculator.NonHedgeFund:
                        lblNonHfFromDateMv.Text = mvString;
                        lblNonHfFromDateWeight.Text = percentString;
                        break;
                }
            }
            lblTotalFromDateMv.Text = portAllocDfd.FundAccountingData.MarketValueBase.ToString(CAmount.FORMAT_STRING_ROUNDING);
        }

        private void BindToDateValuesInTable(DerivedFundData portAllocDfd)
        {
            foreach (DerivedFundData derivedFundData in portAllocDfd.ChildNodes)
            {
                var percentString = new CPercent(derivedFundData.FundAccountingData.MarketValueWeighting).ToString(CPercent.FORMAT_STRING);
                var mvString = derivedFundData.FundAccountingData.MarketValueBase.ToString(CAmount.FORMAT_STRING_ROUNDING);
                switch (derivedFundData.Name)
                {
                    case PortfolioAllocationCalculator.HedgeFund:
                        lblHfToDateMv.Text = mvString;
                        lblHfToDateWeight.Text = percentString;
                        break;
                    case PortfolioAllocationCalculator.PrivateEquityFund:
                        lblPeToDateMv.Text = mvString;
                        lblPeToDateWeight.Text = percentString;
                        break;
                    case PortfolioAllocationCalculator.Cash:
                        lblCashToDateMv.Text = mvString;
                        lblCashToDateWeight.Text = percentString;
                        break;
                    case PortfolioAllocationCalculator.NonHedgeFund:
                        lblNonHfToDateMv.Text = mvString;
                        lblNonHfToDateWeight.Text = percentString;
                        break;
                }
            }
            lblTotalToDateMv.Text = portAllocDfd.FundAccountingData.MarketValueBase.ToString(CAmount.FORMAT_STRING_ROUNDING);
        }
    }
}