﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using DotNet.Highcharts.Enums;
using DotNet.Highcharts.Options;
using IFS.BusinessLayer;
using IFS.BusinessLayer.FxRates;
using IFS.BusinessLayer.Launchpad;
using IFS.BusinessLayer.Fund.FundProperties;
using Color = System.Drawing.Color;
using Data = DotNet.Highcharts.Helpers.Data;
using Legend = System.Web.UI.DataVisualization.Charting.Legend;
using Series = DotNet.Highcharts.Options.Series;
using Title = DotNet.Highcharts.Options.Title;

public partial class pages_launchpad_OperationsSummary : LaunchpadPageBase
{
    #region Members
    
    private LaunchpadOptionsBase _priceOptions;
    private LaunchpadOptionsBase _tradesOptions;
    private Portfolio _selectedPortfolio;
    private IEnumerable<int> _selectedPortfolioIdsTrade;
    private static readonly string[] PiChartLegendItems = new []
                                        {
                                            "Prices Not Received",
                                            "Estimates Received",
                                            "Finals Received"
                                        };
    #endregion

    #region Properties

    #region Pricing

    protected ILaunchpadPricingCalculator PricingCalculator { get; set; }

    protected Portfolio SelectedPortfolio
    {
        get
        {
            return _selectedPortfolio ??
                  (_selectedPortfolio = PriceOptions.Portfolios != null && PriceOptions.Portfolios.Count > 0
                        ? Portfolio.Loader.GetById(PriceOptions.Portfolios[0]) : null);
        }
    }


    protected LaunchpadOptionsBase PriceOptions
    {
        get
        {
            return _priceOptions ?? (_priceOptions = IsPostBack ? pricingOptions.GetLaunchpadSettings() : pricingOptions.LoadPreferences());
        }
    }


    protected DateTime ToDate
    {
        get { return PriceOptions.ToDate.HasValue ? PriceOptions.ToDate.Value : DateTime.MinValue; }
    }

    protected string AsOfDate
    {
        get { return PriceOptions.ToDate.HasValue ? PriceOptions.ToDate.Value.ToString("M/dd/yyyy") : "Current Month"; }
    }


    #endregion

    #region Trades

    protected IEnumerable<int> SelectedPortfolioIdsTrade
    {
        get
        {
            if (_selectedPortfolioIdsTrade == null && (TradeOptions.Portfolios != null && TradeOptions.Portfolios.Count > 0))
            {
                _selectedPortfolioIdsTrade = TradeOptions.Portfolios;
            }
            return _selectedPortfolioIdsTrade;
        }
    }

    protected LaunchpadOptionsBase TradeOptions
    {
        get
        {
            return _tradesOptions ?? (_tradesOptions = IsPostBack ? tradesOptions.GetLaunchpadSettings() : tradesOptions.LoadPreferences());
        }
    }

    protected DateTime FromDateTrade
    {
        get { return TradeOptions.FromDate.HasValue ? TradeOptions.FromDate.Value : DateTime.MinValue; }
    }

    protected DateTime ToDateTrade
    {
        get { return TradeOptions.ToDate.HasValue ? TradeOptions.ToDate.Value : DateTime.MinValue; }
    }

    protected string CurrencyIdTrade
    {
        get { return TradeOptions.CurrencyId; }
    }

    #endregion

    #endregion

    #region Methods

    protected void Page_Load(object sender, EventArgs e)
    {
        var postbackControl = IsPostBack ? GetPostBackControl(Page) : null;
        
        if (postbackControl == null || postbackControl.ClientID.Contains(pricingOptions.ID))
            SetPricingSection();

        if (postbackControl == null || postbackControl.ClientID.Contains(tradesOptions.ID))
            SetTradesSection();
    }

    private void FillSelectedValues()
    {
        ucTradesSelectedPortfolioList.LaunchpadOptions = TradeOptions;
        ucTradesSelectedPortfolioList.BindControls();
    }

    private void SetTradesSection()
    {
        FillSelectedValues();
        var tradesCalculator = new LaunchpadTradesCalculator(SelectedPortfolioIdsTrade, FromDateTrade, ToDateTrade, CurrencyIdTrade);
        tradesCalculator.CalculateTradesData();
        var tradesData = tradesCalculator.TradesData;
        lblRcvCurrencyId.Text = CurrencyIdTrade;
        lblPrcCurrencyId.Text = CurrencyIdTrade;

        lblSubscriptionsReceived.Text = tradesData.GetAllocationCount(TradesAllocation.Subscription, TradesColumn.Received).ToString();
        lblSubscriptionsReceivedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.Subscription, TradesColumn.Received);
        lblSubscriptionsProcessed.Text = tradesData.GetAllocationCount(TradesAllocation.Subscription, TradesColumn.Processed).ToString();
        lblSubscriptionsProcessedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.Subscription, TradesColumn.Processed);

        lblRedemptionsReceived.Text = tradesData.GetAllocationCount(TradesAllocation.Redemption, TradesColumn.Received).ToString();
        lblRedemptionsReceivedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.Redemption, TradesColumn.Received);
        lblRedemptionsProcessed.Text = tradesData.GetAllocationCount(TradesAllocation.Redemption, TradesColumn.Processed).ToString();
        lblRedemptionsProcessedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.Redemption, TradesColumn.Processed);

        lblTransfersReceived.Text = tradesData.GetAllocationCount(TradesAllocation.Transfer, TradesColumn.Received).ToString();
        lblTransfersReceivedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.Transfer, TradesColumn.Received);
        lblTransfersProcessed.Text = tradesData.GetAllocationCount(TradesAllocation.Transfer, TradesColumn.Processed).ToString();
        lblTransfersProcessedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.Transfer, TradesColumn.Processed);

        lblExchangesReceived.Text = tradesData.GetAllocationCount(TradesAllocation.Exchange, TradesColumn.Received).ToString();
        lblExchangesReceivedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.Exchange, TradesColumn.Received);
        lblExchangesProcessed.Text = tradesData.GetAllocationCount(TradesAllocation.Exchange, TradesColumn.Processed).ToString();
        lblExchangesProcessedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.Exchange, TradesColumn.Processed);

        lblContributionsReceived.Text = tradesData.GetAllocationCount(TradesAllocation.Contribution, TradesColumn.Received).ToString();
        lblContributionsReceivedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.Contribution, TradesColumn.Received);
        lblContributionsProcessed.Text = tradesData.GetAllocationCount(TradesAllocation.Contribution, TradesColumn.Processed).ToString();
        lblContributionsProcessedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.Contribution, TradesColumn.Processed);

        lblDistributionsReceived.Text = tradesData.GetAllocationCount(TradesAllocation.Distribution, TradesColumn.Received).ToString();
        lblDistributionsReceivedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.Distribution, TradesColumn.Received);
        lblDistributionsProcessed.Text = tradesData.GetAllocationCount(TradesAllocation.Distribution, TradesColumn.Processed).ToString();
        lblDistributionsProcessedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.Distribution, TradesColumn.Processed);

        lblCashDistributionsReceived.Text = tradesData.GetAllocationCount(TradesAllocation.CashDistributions, TradesColumn.Received).ToString();
        lblCashDistributionsReceivedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.CashDistributions, TradesColumn.Received);
        lblCashDistributionsProcessed.Text = tradesData.GetAllocationCount(TradesAllocation.CashDistributions, TradesColumn.Processed).ToString();
        lblCashDistributionsProcessedMv.Text = tradesData.GetStringifiedMarketValue(TradesAllocation.CashDistributions, TradesColumn.Processed);

        lblCorporateActionsReceived.Text = tradesData.GetAllocationCount(TradesAllocation.CorporateActions, TradesColumn.Received).ToString();
        lblCorporateActionsProcessed.Text = tradesData.GetAllocationCount(TradesAllocation.CorporateActions, TradesColumn.Processed).ToString();

        BuildTradeActivityCharts(tradesCalculator.TradesData);
        BuildRedemptionPaymentsCharts(tradesCalculator.GetRedemptionPayments());
        BuildAgedRedemptionPaymentChart(tradesCalculator.GetRedemptionPayments());
    }

    #region Trade Activity Chart
    
    private DotNet.Highcharts.Highcharts InitializeTradeActivityChart(string currencySymbol)
    {
        var chart = new DotNet.Highcharts.Highcharts("TradeActivityChart").SetCredits(new Credits { Enabled = false });
        chart.SetTitle(new Title { Text = "Net Trade Activity" });
        chart.SetYAxis(new YAxis { Title = new YAxisTitle { Text = "" }, Labels = new YAxisLabels { Format = currencySymbol + " {value} " } });
        chart.SetTooltip(new Tooltip { ValuePrefix = currencySymbol });
        return chart;
    }

    private void BuildTradeActivityCharts(LaunchpadTradesData tradesData)
    {
        var selectedTradeTypes = TradeOptions.TradeTypes;
        if (selectedTradeTypes.Count == 0)
            return;

        var selectedTrades = new TradesAllocation[selectedTradeTypes.Count];
        for (int i = 0; i < selectedTradeTypes.Count; i++)
        {
            selectedTrades[i] = (TradesAllocation) selectedTradeTypes[i];
        } 

        BuildTradeActivityChart(tradesData, selectedTrades);
    }

    private void BuildTradeActivityChart(LaunchpadTradesData tradesData, TradesAllocation[] tradesAllocation)
    {
        var chart = InitializeTradeActivityChart(Currency.GetSymbol(CurrencyIdTrade));
        var tradesActivityData = tradesData.GetMarketValueByDate(tradesAllocation, TradesColumn.Received);
        var categoriesX = new List<string>();
        var dataChart = new List<object>();
        foreach (var marketValue in tradesActivityData)
        {
            categoriesX.Add(marketValue.Key.ToString("M/dd/yyyy"));
            dataChart.Add(marketValue.Value.Value);
        }
        var seriesName = GetSeriesName(tradesAllocation);
        chart.SetXAxis(new XAxis { Categories = categoriesX.ToArray(), Labels = new XAxisLabels { Rotation = -45 } });
        chart.SetSeries(new Series { Name = seriesName, Data = new Data(dataChart.ToArray()), Color = FixColorForIE8(Color.Red) });
        containerTradesActivity.Text = chart.ToHtmlString();
    }

    private string GetSeriesName(TradesAllocation[] tradesAllocation)
    {
        var seriesName = "All Trades";
        const int allTradesCount = 7;
        if (tradesAllocation.Length < allTradesCount)//All is not selected
        {
            var strLegend = new StringBuilder();
            var enumType = typeof(TradesAllocation);
            foreach (var alloc in tradesAllocation)
            {
                strLegend.AppendLine(Enum.GetName(enumType, alloc)).Append("<br/>");
            }
            seriesName = strLegend.ToString();
        }
        return seriesName;
    }
    #endregion

    #region Redemption Payments Balance
    private DotNet.Highcharts.Highcharts InitializeRedemptionPaymentsBalanceChart(string currencySymbol)
    {
        var chart = new DotNet.Highcharts.Highcharts("RedemptionPaymentsBalanceChart").SetCredits(new Credits { Enabled = false });
        chart.SetTitle(new Title { Text = "Redemption Payments Balance" });
        chart.SetYAxis(new YAxis { Title = new YAxisTitle { Text = "" }, Labels = new YAxisLabels { Format = currencySymbol + " {value} " } });
        chart.SetTooltip(new Tooltip { ValuePrefix = currencySymbol, ValueDecimals = 2 });
        chart.SetPlotOptions(new PlotOptions { Column = new PlotOptionsColumn { Stacking = Stackings.Normal } });
        return chart;
    }


    private void BuildRedemptionPaymentsCharts(IEnumerable<KeyValuePair<DateTime, AgedRedemptionPaymentsSummary>> redemptionPayments)
    {
        var chart = InitializeRedemptionPaymentsBalanceChart(Currency.GetSymbol(CurrencyIdTrade));
        var categoriesX = new List<string>();
        var dataHoldback = new List<object>();
        var dataResidual = new List<object>();
        foreach (var agedRedemptionPaymentsSummary in redemptionPayments.OrderBy(k => k.Key))
        {
            var residualY = agedRedemptionPaymentsSummary.Value.AgedResidual.SumarizePeriods().Value;
            var holdbackY = agedRedemptionPaymentsSummary.Value.AgedHoldback.SumarizePeriods().Value;
            dataHoldback.Add(holdbackY);
            dataResidual.Add(residualY);
            categoriesX.Add(agedRedemptionPaymentsSummary.Key.ToString("M/dd/yyyy"));
        }
        chart.SetXAxis(new XAxis { Categories = categoriesX.ToArray() });
        chart.SetSeries(
            new []
                {
                    new Series { Type = ChartTypes.Column, Name = "Holdback", Data = new Data(dataHoldback.ToArray()), Color = ColorTranslator.FromHtml("#ff4040")},
                    new Series { Type = ChartTypes.Column, Name = "Residual", Data = new Data(dataResidual.ToArray()), Color = ColorTranslator.FromHtml("#336699") }
                });
        containerRedemptionPaymentsBalance.Text = chart.ToHtmlString();
    }

    #endregion

    #region Aged Redemption Payments

    private DotNet.Highcharts.Highcharts InitializeAgedRedemptionPaymentChart(string currencySymbol)
    {
        var chart = new DotNet.Highcharts.Highcharts("AgedRedemptionPaymentChart").SetCredits(new Credits { Enabled = false });
        chart.SetTitle(new Title { Text = "Aged Redemption Payments" });
        chart.SetYAxis(new YAxis { Title = new YAxisTitle { Text = "" }, Labels = new YAxisLabels { Format = currencySymbol + " {value} " } });
        chart.SetTooltip(new Tooltip { ValuePrefix = currencySymbol, ValueDecimals = 2 });
        chart.SetPlotOptions(new PlotOptions { Column = new PlotOptionsColumn { Stacking = Stackings.Normal } });
        return chart;
    }

    private void BuildAgedRedemptionPaymentChart(IEnumerable<KeyValuePair<DateTime, AgedRedemptionPaymentsSummary>> redemptionPayments)
    {
        var chart = InitializeAgedRedemptionPaymentChart(Currency.GetSymbol(CurrencyIdTrade));
        var categoriesX = new List<string>();
        var dataGreaterThanNineMonths = new List<object>();
        var dataSixToNineMonths = new List<object>();
        var dataThreeToSixMonths = new List<object>();
        var dataOneToThreeMonths = new List<object>();
        var dataLessThanOneMonth = new List<object>();

        foreach (var agedRedemptionPaymentsSummary in redemptionPayments.OrderBy(k => k.Key))
        {
            var agedRedemption = agedRedemptionPaymentsSummary.Value;
            categoriesX.Add(agedRedemptionPaymentsSummary.Key.ToString("M/dd/yyyy"));
            dataGreaterThanNineMonths.Add(agedRedemption.GetAgedPaymentsForGreaterThanNineMonths().Value);
            dataSixToNineMonths.Add(agedRedemption.GetAgedPaymentsForSixToNineMonths().Value);
            dataThreeToSixMonths.Add(agedRedemption.GetAgedPaymentsForThreeToSixMonths().Value);
            dataOneToThreeMonths.Add(agedRedemption.GetAgedPaymentsForOneToThreeMonths().Value);
            dataLessThanOneMonth.Add(agedRedemption.GetAgedPaymentsForLessThanOneMonth().Value);
        }
        chart.SetXAxis(new XAxis { Categories = categoriesX.ToArray() });
        chart.SetSeries(
            new[]
                {
                    new Series { Type = ChartTypes.Column, Name = "<1mth", Data = new Data(dataLessThanOneMonth.ToArray()), Color = ColorTranslator.FromHtml("#ff4040")},
                    new Series { Type = ChartTypes.Column, Name = "1-3mths", Data = new Data(dataOneToThreeMonths.ToArray()), Color = ColorTranslator.FromHtml("#8ae602")},
                    new Series { Type = ChartTypes.Column, Name = "3-6mths", Data = new Data(dataThreeToSixMonths.ToArray()), Color = ColorTranslator.FromHtml("#a869fc")},
                    new Series { Type = ChartTypes.Column, Name = "6-9mths", Data = new Data(dataSixToNineMonths.ToArray()), Color = ColorTranslator.FromHtml("#99ccff") },
                    new Series { Type = ChartTypes.Column, Name = ">9mths", Data = new Data(dataGreaterThanNineMonths.ToArray()), Color = ColorTranslator.FromHtml("#336699")}
                });
        containerAgedRedemptionPayments.Text = chart.ToHtmlString();
    }
    #endregion

    private void SetPricingSection()
    {
        SelectedPortfolioList.LaunchpadOptions = PriceOptions;
        SelectedPortfolioList.BindControls();

        PricingCalculator.CalculatePricingData(SelectedPortfolio, ToDate, PriceOptions.FundType);

        //Populate Table
        var pricingCounters = PricingCalculator.PricingData.AsOfDateMonthEndCounters;
        lblFinalsReceivedCount.Text = pricingCounters.FinalsReceived.ToString(CultureInfo.InvariantCulture);
        lblFinalsReceivedWeight.Text = pricingCounters.FinalsReceivedPct.ToString("p");
        lblFinalsReceivedMVWeight.Text = pricingCounters.FinalsReceivedMktValuePct.ToString("P");

        lblEstimateReceivedCount.Text = pricingCounters.EstReceived.ToString(CultureInfo.InvariantCulture);
        lblEstimateReceivedWeight.Text = pricingCounters.EstReceivedPct.ToString("p");
        lblEstimatesReceivedMVWeight.Text = pricingCounters.EstReceivedMktValuePct.ToString("P");

        lblNotReceivedCount.Text = pricingCounters.NotReceived.ToString(CultureInfo.InvariantCulture);
        lblNotReceivedWeight.Text = pricingCounters.NotReceivedPct.ToString("p");
        lblNotReceivedMVWeight.Text = pricingCounters.NotReceivedMktValuePct.ToString("P");

        lblTotalCount.Text = pricingCounters.TotalCount.ToString(CultureInfo.InvariantCulture);
        lblTotalWeight.Text = pricingCounters.TotalPct.ToString("P");
        lblTotalMVWeight.Text = pricingCounters.TotalMktValueWeightPct.ToString("P");

        BuildTop5VarianceTable();
        BuildVarianceChart();
        BuildPieChart();
        BuildNoDaysAfterLockdown();
        BuildLineGraph();
    }

    private void BuildTop5VarianceTable()
    {
        gvTop5Variance.Columns[2].HeaderText = Currency.GetSymbol(PriceOptions.CurrencyId);
         var values = PricingCalculator.PricingData.VarianceByInvestments.
            Where(i => i.Variance>0 && i.DaysAfter >= 0).OrderByDescending(i => i.Variance).Take(5);
        if(SelectedPortfolio != null && PriceOptions.CurrencyId != SelectedPortfolio.CurrencyId)
        {
            foreach (var investmentVarianceData in values)
            {
                investmentVarianceData.FinalMv = Rate.Convert(investmentVarianceData.FinalMv, CSession.CurrentOrganization, SelectedPortfolio.CurrencyId, PriceOptions.CurrencyId, ToDate);
                investmentVarianceData.LockedMv = Rate.Convert(investmentVarianceData.LockedMv, CSession.CurrentOrganization, SelectedPortfolio.CurrencyId, PriceOptions.CurrencyId, ToDate);
            }
        }

        gvTop5Variance.DataSource = values;
        gvTop5Variance.DataBind();
    }


    #region Portfolio Variance line chart

    private DotNet.Highcharts.Highcharts InitializeVarianceChart(LaunchpadOptionsBase.VarianceAs varianceType, string currencySymbol)
    {
        var chart = new DotNet.Highcharts.Highcharts("VarianceChart").SetCredits(new Credits {Enabled = false});
        var prefix = "";
        var suffix = "";
        if(varianceType == LaunchpadOptionsBase.VarianceAs.Amount)
            prefix = currencySymbol;
        else
            suffix = PERCENT;
        chart.SetTitle(new Title { Text = "Portfolio " + prefix + suffix + " Variance" });
        chart.SetYAxis(new YAxis { Title = new YAxisTitle { Text = "Variance" }, Labels = new YAxisLabels { Format = prefix + " {value} " + suffix  } });
        chart.SetTooltip(new Tooltip { ValueDecimals = 2, ValueSuffix = suffix, ValuePrefix = prefix});
        return chart;
    }

    private void BuildVarianceChart()
    {
        var chart = InitializeVarianceChart(PriceOptions.PortfolioVarianceType, Currency.GetSymbol(PriceOptions.CurrencyId));
        ConvertToCurrency(PricingCalculator.PricingData.RollingTwelveMonthVariance, PriceOptions.CurrencyId);

        var monthlyPortVarianceList = PricingCalculator.PricingData.RollingTwelveMonthVariance.Values.ToList();
        chart.SetXAxis(new XAxis { Categories = monthlyPortVarianceList.Select(x => x.MonthEndString).ToArray(), Labels = new XAxisLabels { Rotation = -45 } });
        var data = (PriceOptions.PortfolioVarianceType == LaunchpadOptionsBase.VarianceAs.Amount
                       ? monthlyPortVarianceList.Select(x => ToNullable(x.TotalVarianceAmount))
                       : monthlyPortVarianceList.Select(x => ToNullable(x.TotalVariance*100))).ToArray();
        chart.SetSeries(new Series { Name = "Portfolio Variance", Data = new Data(data)});
        containerPortfolioVariance.Text = chart.ToHtmlString();
    }

    private object ToNullable(double value)
    {
        return double.IsNaN(value) ? null : (object) value;
    }
    #endregion

    #region Portfolio Variance  pie chart
    private DotNet.Highcharts.Highcharts InitializeVariancePieChart(string asOfDate)
    {
        var chart = new DotNet.Highcharts.Highcharts("VariancePieChart").SetCredits(new Credits { Enabled = false });
        chart.SetTitle(new Title { Text = "Percentage Breakdown for " + asOfDate });
        chart.SetPlotOptions(new PlotOptions { Pie = new PlotOptionsPie { AllowPointSelect = true, DataLabels = new PlotOptionsPieDataLabels { Enabled = false }, ShowInLegend = true } });
        chart.SetTooltip(new Tooltip { PointFormat = "{series.name}: <b>{point.percentage:.2f}"+PERCENT+"</b>" });
        return chart;
    }

    private void BuildPieChart()
    {
        var pieChart = InitializeVariancePieChart(AsOfDate);
        var pricingCounters = PricingCalculator.PricingData.AsOfDateMonthEndCounters;
        const double thresholdNumber = 0.00005;
        var chartData = new List<object>();
        if (pricingCounters.NotReceivedPct >= thresholdNumber)
        {
            AddPiePointWithTooltip(chartData, pricingCounters.NotReceivedPct, AsOfDate + " " + PiChartLegendItems[0]);
        }

        if (pricingCounters.EstReceivedPct >= thresholdNumber)
        {
            AddPiePointWithTooltip(chartData, pricingCounters.EstReceivedPct, AsOfDate + " " + PiChartLegendItems[1]);
        }

        if (pricingCounters.FinalsReceivedPct >= thresholdNumber)
        {
            AddPiePointWithTooltip(chartData, pricingCounters.FinalsReceivedPct, AsOfDate + " " + PiChartLegendItems[2]);
        }
        pieChart.SetSeries(new Series
                                {
                                    Type = ChartTypes.Pie,
                                    Name = "Percentage Breakdown",
                                    Data = new Data(chartData.ToArray())
                                });
        containerPiePortfolioVariance.Text = pieChart.ToHtmlString();
    }

    #endregion

    private void ConvertToCurrency(Dictionary<DateTime, MonthlyVarianceData> varianceData, string toCurrencyId)
    {
        foreach (var monthEndData in varianceData.Select(pair => pair.Value))
        {
            monthEndData.Rate = FxRatesImpl.ExchangeRate(CSession.CurrentOrganization, _selectedPortfolio.CurrencyId,
                                                         toCurrencyId, ToDate.Date);
        }
    }

    #region # Days After Month End chart
    private DotNet.Highcharts.Highcharts InitializeDaysAfterMonthEndChart()
    {
        var chart = new DotNet.Highcharts.Highcharts("DaysAfterMonthEndChart").SetCredits(new Credits { Enabled = false });
        chart.SetTitle(new Title { Text = "# Days After Month End" });
        chart.SetYAxis(new YAxis { Title = new YAxisTitle { Text = "Variance Days" } });
        return chart;
    }

    private void BuildNoDaysAfterLockdown()
    {
        var chart = InitializeDaysAfterMonthEndChart();
        var monthlyPortVarianceList = PricingCalculator.PricingData.RollingTwelveMonthVariance.Values.ToList();
        chart.SetXAxis(new XAxis { Categories = monthlyPortVarianceList.Select(x => x.MonthEndString).ToArray(), Labels = new XAxisLabels { Rotation = -45 } });
        var data = monthlyPortVarianceList.Select(x => ToNullable(x.DaysToLockdownAfterMonthEnd)).ToArray();
        chart.SetSeries(new Series { Name = "# Days After Month End", Data = new Data(data), Color = FixColorForIE8(Color.Green) });
        containerNoDaysAfterLockdown.Text = chart.ToHtmlString();
    }
    #endregion

    #region Weight by Price History Chart
    private DotNet.Highcharts.Highcharts InitializeWeightPriceHistoryChart()
    {
        var chart = new DotNet.Highcharts.Highcharts("WeightPriceHistoryChart").SetCredits(new Credits { Enabled = false });
        chart.SetTitle(new Title { Text = "Weight by Price History" });
        chart.SetYAxis(new YAxis { Title = new YAxisTitle { Text = PERCENT }, Max = 100});
        chart.SetTooltip(new Tooltip { ValueSuffix = PERCENT});
        return chart;
    }

    private void BuildLineGraph()
    {
        var chart = InitializeWeightPriceHistoryChart();
        var monthlyPricingDataList = PricingCalculator.PricingData.RollingTwelveMonthPricingData.ToList();
        var categoriesX = new List<string>();
        var dataHedgeFunds = new List<object>();
        var dataNonHedgeFunds = new List<object>();
        foreach (KeyValuePair<DateTime, MonthlyPricingData> pair in monthlyPricingDataList)
        {
            var date = pair.Key.ToShortDateString();
            var pricingData = pair.Value;
            categoriesX.Add(date);
            dataHedgeFunds.Add(ToNullable(pricingData.PricingCounters.EstReceivedPct * 100));
            dataNonHedgeFunds.Add(ToNullable(pricingData.PricingCounters.FinalsReceivedPct * 100));
        }
        chart.SetXAxis(new XAxis { Categories = categoriesX.ToArray(), Labels = new XAxisLabels { Rotation = -45 } });
        chart.SetSeries(
                        new []{
                                new Series { Name = "Hedge Funds", Data = new Data(dataHedgeFunds.ToArray()), Color = FixColorForIE8(Color.Orange) },
                                new Series { Name = "Non Hedge Funds", Data = new Data(dataNonHedgeFunds.ToArray()), Color = FixColorForIE8(Color.DeepSkyBlue) }
                              });
        containerWeightPriceHistory.Text = chart.ToHtmlString();
    }
    #endregion
    #endregion
}