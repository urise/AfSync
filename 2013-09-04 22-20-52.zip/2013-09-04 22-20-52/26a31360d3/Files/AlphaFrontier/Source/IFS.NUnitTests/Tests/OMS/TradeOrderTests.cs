﻿using System;
using System.Collections.Generic;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.Import;
using IFS.BusinessLayer.OrderManagementSystem;
using IFS.BusinessLayer.Utilities;
using IFS.Interfaces.Common;
using IFS.Interfaces.Common.Enums;
using IFS.Interfaces.Rounding;
using IFS.NUnitTests.BusinessLayer.shared;
using NUnit.Framework;
using System.Reflection;

namespace IFS.NUnitTests.Tests.OMS
{
    [TestFixture]
    public class TradeOrderTests
    {
        private ITradeOrderProcessor _orderProcessor;
        private ISequenceProvider _allocationsIdsProvider;
        private Portfolio _portfolioFifo1;
        private Portfolio _portfolioFifo2;
        private int _investmentCounter = 1;

        [SetUp]
        public void SetUpData()
        {
            _allocationsIdsProvider = (ISequenceProvider)SpringUtil.GetObject("AllocationSequenceProvider");
            _orderProcessor = (ITradeOrderProcessor)SpringUtil.GetObject("TradeOrderProcessor");
            _portfolioFifo1 = Portfolio.Loader.GetById(19);
            _portfolioFifo2 = Portfolio.Loader.GetById(18);
            string key = string.Format(Portfolio.PORTFOLIOS_REQUEST_KEY, 1, true);
            var portCollection = new PortfolioCollection { _portfolioFifo1, _portfolioFifo2 };
            RequestCache.Insert(key, portCollection);
        }

        [Test]
        public void TestConvertOrderToSubCTrade()
        {
            BuildDummyInvestments();
            var dummyOrder = GetDummySubscriptionOrder();
            dummyOrder.TradeOrderTransactionId = "TO_5";
            _orderProcessor.TradeOrder = dummyOrder;
            var cTrade = _orderProcessor.ConvertToTrade();

            Assert.AreEqual(dummyOrder.TradeDate, cTrade.TradeData.EffectiveDate);
            Assert.AreEqual(dummyOrder.TradeDate, cTrade.TradeData.TradeDate);
            Assert.AreEqual(dummyOrder.TradeAmount, cTrade.TradeData.AmountLocal);
            Assert.AreEqual(dummyOrder.TradeQuantity, cTrade.TradeData.Quantity);

            Assert.AreEqual(dummyOrder.TradeOrderXmlProperties.TradeFee.FeeAmount, cTrade.TradeData.TradeFeeAmount);
            Assert.AreEqual(dummyOrder.TradeOrderXmlProperties.BrokerFee.FeeAmount, cTrade.TradeData.BrokerFeesAmount);
        }

        [Test]
        public void TestConvertOrderToRedemptionCTrade()
        {
            BuildDummyInvestments();
            var dummyOrder = GetDummyRedemptionOrder();
            dummyOrder.TradeOrderTransactionId = "TO_6";
            _orderProcessor.TradeOrder = dummyOrder;
            var cTrade = _orderProcessor.ConvertToTrade().TradeData;

            Assert.AreEqual(CBulkUploadTrades.TRANSACTION_TYPE_RED, cTrade.TransactionType);
            Assert.AreEqual(1, cTrade.TradeLots.Count);
            Assert.AreEqual(new CAmount(10000), cTrade.AmountLocal);
            Assert.AreEqual(new CQuantity(100), cTrade.Quantity);

            Assert.AreEqual(dummyOrder.TradeOrderXmlProperties.TradeFee.FeeAmount, cTrade.TradeFeeAmount);
            Assert.AreEqual(dummyOrder.TradeOrderXmlProperties.BrokerFee.FeeAmount, cTrade.BrokerFeesAmount);
        }

        [Test]
        public void TestConvertOrderToExchangeCTrade()
        {
            BuildDummyInvestments();
            var dummyOrder = GetDummyExchangeOrder();
            dummyOrder.TradeOrderTransactionId = "TO_7";
            dummyOrder.TradeFund.Id = 3000;
            _orderProcessor.TradeOrder = dummyOrder;
            var cTrade = _orderProcessor.ConvertToTrade().TradeDataImport;

            Assert.AreEqual( 3000, cTrade.ExchangeInFundInstrumentId);
            Assert.AreEqual("Mock Clearer", cTrade.TransferInClearerName);
            Assert.AreEqual(CBulkUploadTrades.TRANSACTION_TYPE_EX, cTrade.TransactionType);
        }

        [Test]
        public void TestConvertOrderToTransferCTrade()
        {
            BuildDummyInvestments();
            var dummyOrder = GetDummyTransferOrder();
            dummyOrder.TradeOrderTransactionId = "TO_8";
            _orderProcessor.TradeOrder = dummyOrder;
            var cTrade = _orderProcessor.ConvertToTrade().TradeDataImport;

            Assert.AreEqual("TSTGLS", cTrade.IfsToIfsTransferPortfolioGlsId);
            Assert.AreEqual("Mock Clearer", cTrade.TransferInClearerName);
            Assert.AreEqual(CBulkUploadTrades.TRANSACTION_TYPE_TRANSFER, cTrade.TransactionType);
        }

        [Test]
        public void TestConvertOrderToContribCTrade()
        {
            BuildDummyInvestments();
            var dummyOrder = GetDummyContributionOrder();
            dummyOrder.TradeOrderTransactionId = "TO_9";
            _orderProcessor.TradeOrder = dummyOrder;
            var cTrade = _orderProcessor.ConvertToTrade();

            Assert.AreEqual(dummyOrder.TradeDate, cTrade.TradeData.EffectiveDate);
            Assert.AreEqual(dummyOrder.TradeDate, cTrade.TradeData.TradeDate);
            Assert.AreEqual(dummyOrder.MoneyMoveDate, cTrade.TradeData.MoneyMoveDate);
            Assert.AreEqual(dummyOrder.TradeAmount, cTrade.TradeData.AmountLocal);
            Assert.AreEqual(dummyOrder.TradeQuantity, cTrade.TradeData.Quantity);
            Assert.AreEqual(CBulkUploadTrades.TRANSACTION_TYPE_CONTRIBUTION, cTrade.TradeData.TransactionType);
        }

        [Test]
        public void TestClientDeleteApprovedTrade()
        {
            Assert.AreEqual(TradeOrderHelper.CLIENT_CANNOT_DELETE_APP_TRADE, TradeOrderHelper.ValidateUserForDeleteAction(TradeOrderHelper.TRADE_BOOKED, Role.IFS_CLIENT_LEVEL1));
        }

        [Test]
        public void TestClientDeleteNonApprovedTrade()
        {
            Assert.IsNull(TradeOrderHelper.ValidateUserForDeleteAction(TradeOrderHelper.PENDING_APPROVAL, Role.IFS_CLIENT_LEVEL1));
        }

        [Test]
        public void TestAcctDeleteNonApprovedTrade()
        {
            Assert.AreEqual(TradeOrderHelper.ACCT_CANNOT_DELETE_INPROC_TRADE, TradeOrderHelper.ValidateUserForDeleteAction(TradeOrderHelper.PENDING_APPROVAL, Role.IFS_ACCOUNTANT));
        }

        [Test]
        public void TestTradeOrderSubscriptions()
        {
            BuildDummyInvestments();
            var investment = _portfolioFifo1.Investments[0];
            var subs1 = new MockAllocationSubscription(_allocationsIdsProvider.GetNextSequenceNumber())
            {
                ExecutionDate = new DateTime(2009, 12, 31),
                TradeDate = new DateTime(2009, 12, 31),
                AllocationQuantity = new CQuantity(150),
                AllocationDeltaLocal = new CAmount(15000),
                AllocationTypeId = AllocationType.SUBSCRIPTION,
                AllocationEnteredAs = AllocationEnteredAs.QTY,
                ClearerID = 1,
                AllocationPriceOverride = new CNav(100),
                RateOverride = double.NaN,
                Investment = investment
            };
            investment.Allocations.Add(subs1);
            var red1 = new MockAllocationRedemption(9)
            {
                Investment = investment,
                ExecutionDate = new DateTime(2010, 01, 05),
                TradeDate = new DateTime(2009, 01, 05),
                AllocationQuantity = new CQuantity(-20),
                AllocationDeltaLocal = new CAmount(-2000),
                AllocationTypeId = AllocationType.REDEMPTION,
                AllocationEnteredAs = AllocationEnteredAs.AMT,
                ClearerID = 2
            };
            red1.RedempLots.Add(new RedemptionLot
                {
                    SubscriptionId = subs1.AllocationID,
                    LotDeltaLocal = new CAmount(-2000),
                    LotEnteredAs = AllocationEnteredAs.AMT,
                    LotQuantity = new CQuantity(-20),
                    RedemptionId = red1.AllocationID,
                    Parent = red1
                });
            investment.Allocations.Add(red1);
            var subs2 = new MockAllocationSubscription(_allocationsIdsProvider.GetNextSequenceNumber())
            {
                ExecutionDate = new DateTime(2010, 03, 01),
                TradeDate = new DateTime(2010, 03, 01),
                AllocationQuantity = new CQuantity(50),
                AllocationDeltaLocal = new CAmount(5000),
                AllocationTypeId = AllocationType.SUBSCRIPTION,
                AllocationEnteredAs = AllocationEnteredAs.QTY,
                ClearerID = 1,
                AllocationPriceOverride = new CNav(100),
                RateOverride = double.NaN,
                Investment = investment
            };
            investment.Allocations.Add(subs2);
            var dummyOrder = GetDummyRedemptionOrder();
            var subs = TradeOrderHelper.TradeOrderSubscriptions(investment, new DateTime(2010, 02, 01), 1, EnumValue.RM_FIFO,
                                                     dummyOrder);
            Assert.AreEqual(subs.Count, 1);//total
            Assert.AreEqual(subs[0].Quantity.Value, 230);
            Assert.AreEqual(subs[0].DeltaLocal.Value, 23000);

            subs = TradeOrderHelper.TradeOrderSubscriptions(investment, new DateTime(2010, 02, 01), 1, EnumValue.RM_SPECIFIC_ID,
                                         dummyOrder);
            Assert.AreEqual(subs.Count, 2);
            Assert.AreEqual(subs[0].Quantity.Value, 130);
            Assert.AreEqual(subs[0].DeltaLocal.Value, 13000);

        }

        [Test]
        public void TestTradeOrderSubscriptionClone()
        {
            BuildDummyInvestments();
            var sub1 = GetDummySubscriptionOrder();
            var copysub1 = TradeOrderHelper.NewTradeOrder(sub1, true);
            TestCloning(sub1, copysub1);
        }

        [Test]
        public void TestTradeOrderRedemptionClone()
        {
            BuildDummyInvestments();
            var ord1 = GetDummyRedemptionOrder();
            var copyord1 = TradeOrderHelper.NewTradeOrder(ord1, true);
            TestCloning(ord1, copyord1);
        }

        [Test]
        public void TestTradeOrderExchangeClone()
        {
            BuildDummyInvestments();
            var ord1 = GetDummyExchangeOrder();
            var copyord1 = TradeOrderHelper.NewTradeOrder(ord1, true);
            TestCloning(ord1, copyord1);
        }

        [Test]
        public void TestTradeOrderTransferClone()
        {
            BuildDummyInvestments();
            var ord1 = GetDummyTransferOrder();
            var copyord1 = TradeOrderHelper.NewTradeOrder(ord1, true);
            TestCloning(ord1, copyord1);
        }

        [Test]
        public void TestTradeOrderContributionClone()
        {
            BuildDummyInvestments();
            var ord1 = GetDummyContributionOrder();
            var copyord1 = TradeOrderHelper.NewTradeOrder(ord1, true);
            TestCloning(ord1, copyord1);
        }

        [Test]
        public void TestGetTradeOrderContribBreakupData()
        {
            BuildDummyInvestments();
            var ord1 = GetDummyContributionOrder();
            var breakupDataList = ord1.GetBreakupData();
            Assert.AreEqual(1, breakupDataList.Count);
            Assert.IsTrue(breakupDataList[0].IsCapitalCall);
            Assert.AreEqual(ord1.TradeAmount, breakupDataList[0].MvLocal);
            Assert.AreEqual("Capital Call", breakupDataList[0].TransactionDetails);
        }

        [Test]
        public void TestGetTradeOrderHfConverter()
        {
            var tradeData = new TradeData {AssetType = CBulkUploadTrades.ASSET_TYPE_HF};
            var converter = TradeOrderProcessor.GetTradeConverter(tradeData);
            Assert.IsInstanceOf(typeof(HedgeFundTrade), converter);
        }

        [Test]
        public void TestGetTradeOrderPeConverter()
        {
            var tradeData = new TradeData { AssetType = CBulkUploadTrades.ASSET_TYPE_PE };
            var converter = TradeOrderProcessor.GetTradeConverter(tradeData);
            Assert.IsInstanceOf(typeof(PvtEquityTrade), converter);
        }

        [Test]
        public void TestGetTradeOrderNullConverter()
        {
            var tradeData = new TradeData();
            var converter = TradeOrderProcessor.GetTradeConverter(tradeData);
            Assert.IsNull(converter);
        }

        #region Other Methods
        private void BuildDummyInvestments()
        {
            _portfolioFifo1.Investments.Clear();
            //Build Investment 1
            InvestableFund invFund = InvestableFund.Loader.GetById(100);
            var investment1 = GetDummyInvestment(invFund, _portfolioFifo1);
            _portfolioFifo1.Investments.Add(investment1);

            //Build Investment 2 for exchange
            InvestableFund invFund2 = InvestableFund.Loader.GetById(3000);
            var investment2 = GetDummyInvestment(invFund2, _portfolioFifo1);
            _portfolioFifo1.Investments.Add(investment2);

            _portfolioFifo2.Investments.Clear();
            var investment3 = GetDummyInvestment(invFund, _portfolioFifo2);
            _portfolioFifo2.Investments.Add(investment3);
        }

        private Investment GetDummyInvestment(InvestableFund fund, Portfolio portfolio)
        {
            var investment = new MockInvestment(_investmentCounter++)
            {
                Portfolio = portfolio,
                PortfolioID = portfolio.PortfolioID,
                Fund = fund,
                DeletedAllocations = new List<Allocation>()
            };

            var subs1 = new MockAllocationSubscription(_allocationsIdsProvider.GetNextSequenceNumber())
            {
                ExecutionDate = new DateTime(2010, 01, 01),
                TradeDate = new DateTime(2010, 01, 01),
                AllocationQuantity = new CQuantity(100),
                AllocationDeltaLocal = new CAmount(10000),
                AllocationTypeId = AllocationType.SUBSCRIPTION,
                AllocationEnteredAs = AllocationEnteredAs.QTY,
                ClearerID = 1,
                AllocationPriceOverride = new CNav(100),
                RateOverride = double.NaN,
                Investment = investment
            };
            investment.Allocations.Add(subs1);
            return investment;
        }

        private TradeOrderSubscription GetDummySubscriptionOrder()
        {
            var dummyTradeOrder = new TradeOrderSubscription
                                      {
                                          TradeInvestment = _portfolioFifo1.Investments[0],
                                          TradeDateReceived = new DateTime(2010, 01, 01),
                                          ExecutionDate = new DateTime(2010, 01, 01),
                                          TradeDate = new DateTime(2010, 01, 01),
                                          MoneyMoveDate = new DateTime(2010, 01, 01),
                                          TradePaymentDate = new DateTime(2010, 01, 01),
                                          TradeDueDate = new DateTime(2010, 01, 01),
                                          TradeAmount = new CAmount(10000),
                                          TradeQuantity = new CQuantity(100),
                                          TradeType = TradeOrderType.TRADE_ORDER_SUBSCRIPTION,
                                          Comment = "Dummy TradeOrder",
                                          TradeClearerId = 1,
                                          UserAction = TradeOrderHelper.USERACTION_NEW,
                                          ETradeEnteredAs = AllocationEnteredAs.QTY
                                      };

            var xmlProperties = dummyTradeOrder.TradeOrderXmlProperties;
            xmlProperties.AmountToBePaid = new CAmount(10200);
            xmlProperties.BrokerFee.FeeAmount = new CAmount(100);
            xmlProperties.BrokerFee.FeeEnteredAsAmt = true;
            xmlProperties.TradeFee.FeeAmount = new CAmount(100);
            xmlProperties.TradeFee.FeeEnteredAsAmt = true;
            xmlProperties.IsCashLessSubscription = true;
            return dummyTradeOrder;
        }

        private TradeOrderRedemption GetDummyRedemptionOrder()
        {
            var dummyTradeOrder = new TradeOrderRedemption
                                      {
                                          TradeInvestment = _portfolioFifo1.Investments[0],
                                          TradeDateReceived = new DateTime(2010, 01, 01),
                                          ExecutionDate = new DateTime(2010, 01, 01),
                                          TradeDate = new DateTime(2010, 01, 01),
                                          MoneyMoveDate = new DateTime(2010, 01, 01),
                                          TradePaymentDate = new DateTime(2010, 01, 01),
                                          TradeDueDate = new DateTime(2010, 01, 01),
                                          TradeAmount = new CAmount(-10000),
                                          TradeQuantity = new CQuantity(-100),
                                          TradeType = TradeOrderType.TRADE_ORDER_REDEMPTION,
                                          Comment = "Dummy TradeOrder",
                                          TradeClearerId = 1,
                                          UserAction = TradeOrderHelper.USERACTION_NEW,
                                          ETradeEnteredAs = AllocationEnteredAs.QTY
                                      };

            var xmlProperties = dummyTradeOrder.TradeOrderXmlProperties;
            xmlProperties.AmountToBePaid = new CAmount(10200);
            xmlProperties.BrokerFee.FeeAmount = new CAmount(100);
            xmlProperties.BrokerFee.FeeEnteredAsAmt = true;
            xmlProperties.TradeFee.FeeAmount = new CAmount(100);
            xmlProperties.TradeFee.FeeEnteredAsAmt = true;
            xmlProperties.IsCashLessSubscription = true;
            dummyTradeOrder.RedemptionLots = new List<TradeOrderRedemptionLot>
                                                 {
                                                     new TradeOrderRedemptionLot
                                                         {
                                                             LotDeltaLocal = new CAmount(-10000),
                                                             LotQuantity = new CQuantity(-100),
                                                             LotEnteredAs = AllocationEnteredAs.QTY,
                                                             SubscriptionId = _portfolioFifo1.Investments[0].Allocations[0].AllocationID,
                                                             CostRemaining = CAmount.NaN,
                                                             BaseCostRemaining = CAmount.NaN,
                                                             Parent = dummyTradeOrder
                                                         }
                                                 };
            return dummyTradeOrder;
        }

        private TradeOrderExchange GetDummyExchangeOrder()
        {
            var dummyTradeOrder = new TradeOrderExchange
                                      {
                                          TradeInvestment = _portfolioFifo1.Investments[0],
                                          TradeToInvestment = _portfolioFifo1.Investments[1],
                                          TradeDateReceived = new DateTime(2010, 01, 01),
                                          ExecutionDate = new DateTime(2010, 01, 01),
                                          TradeDate = new DateTime(2010, 01, 01),
                                          MoneyMoveDate = new DateTime(2010, 01, 01),
                                          TradePaymentDate = new DateTime(2010, 01, 01),
                                          TradeDueDate = new DateTime(2010, 01, 01),
                                          TradeAmount = new CAmount(-10000),
                                          TradeQuantity = new CQuantity(-100),
                                          TradeType = TradeOrderType.TRADE_ORDER_EXCHANGE,
                                          Comment = "Dummy Exchange TradeOrder",
                                          TradeClearerId = 1,
                                          TradeExchangeClearerId = 1,
                                          UserAction = TradeOrderHelper.USERACTION_NEW,
                                          ETradeEnteredAs = AllocationEnteredAs.QTY
                                      };

            var xmlProperties = dummyTradeOrder.TradeOrderXmlProperties;
            xmlProperties.AmountToBePaid = new CAmount(10200);
            xmlProperties.BrokerFee.FeeAmount = new CAmount(100);
            xmlProperties.BrokerFee.FeeEnteredAsAmt = true;
            xmlProperties.TradeFee.FeeAmount = new CAmount(100);
            xmlProperties.TradeFee.FeeEnteredAsAmt = true;
            xmlProperties.IsCashLessSubscription = true;
            dummyTradeOrder.RedemptionLots = new List<TradeOrderRedemptionLot>
                                                 {
                                                     new TradeOrderRedemptionLot
                                                         {
                                                             LotDeltaLocal = new CAmount(-10000),
                                                             LotQuantity = new CQuantity(-100),
                                                             LotEnteredAs = AllocationEnteredAs.QTY,
                                                             SubscriptionId = _portfolioFifo1.Investments[0].Allocations[0].AllocationID,
                                                             CostRemaining = CAmount.NaN,
                                                             BaseCostRemaining = CAmount.NaN,
                                                             Parent = dummyTradeOrder
                                                         }
                                                 };

            return dummyTradeOrder;
        }

        private TradeOrderTransfer GetDummyTransferOrder()
        {
            var dummyTradeOrder = (TradeOrderTransfer)TradeOrderHelper.CreateTradeOrderObj(TradeOrderType.TRADE_ORDER_TRANSFER);
            dummyTradeOrder.TradeInvestment = _portfolioFifo1.Investments[0];
            dummyTradeOrder.TradeToInvestment = _portfolioFifo1.Investments[1];
            dummyTradeOrder.TradeDateReceived = new DateTime(2010, 01, 01);
            dummyTradeOrder.ExecutionDate = new DateTime(2010, 01, 01);
            dummyTradeOrder.TradeDate = new DateTime(2010, 01, 01);
            dummyTradeOrder.MoneyMoveDate = new DateTime(2010, 01, 01);
            dummyTradeOrder.TradePaymentDate = new DateTime(2010, 01, 01);
            dummyTradeOrder.TradeDueDate = new DateTime(2010, 01, 01);
            dummyTradeOrder.TradeAmount = new CAmount(-10000);
            dummyTradeOrder.TradeQuantity = new CQuantity(-100);
            dummyTradeOrder.Comment = "Dummy Transfer TradeOrder";
            dummyTradeOrder.TradeClearerId = 1;
            dummyTradeOrder.TradeExchangeClearerId = 1;
            dummyTradeOrder.UserAction = TradeOrderHelper.USERACTION_NEW;
            dummyTradeOrder.ETradeEnteredAs = AllocationEnteredAs.QTY;

            var xmlProperties = dummyTradeOrder.TradeOrderXmlProperties;
            xmlProperties.AmountToBePaid = new CAmount(10200);
            xmlProperties.BrokerFee.FeeAmount = new CAmount(100);
            xmlProperties.BrokerFee.FeeEnteredAsAmt = true;
            xmlProperties.TradeFee.FeeAmount = new CAmount(100);
            xmlProperties.TradeFee.FeeEnteredAsAmt = true;
            xmlProperties.IsCashLessSubscription = true;
            dummyTradeOrder.RedemptionLots = new List<TradeOrderRedemptionLot>
                                                 {
                                                     new TradeOrderRedemptionLot
                                                         {
                                                             LotDeltaLocal = new CAmount(-10000),
                                                             LotQuantity = new CQuantity(-100),
                                                             LotEnteredAs = AllocationEnteredAs.QTY,
                                                             SubscriptionId = _portfolioFifo1.Investments[0].Allocations[0].AllocationID,
                                                             CostRemaining = CAmount.NaN,
                                                             BaseCostRemaining = CAmount.NaN,
                                                             Parent = dummyTradeOrder
                                                         }
                                                 };
            dummyTradeOrder.TransferToClearerId = 1;
            dummyTradeOrder.TradeTransferPortfolioId = 18;
            return dummyTradeOrder;
        }

        private TradeOrderContribution GetDummyContributionOrder()
        {
            var dummyTradeOrder = (TradeOrderContribution)TradeOrderHelper.CreateTradeOrderObj(TradeOrderType.TRADE_ORDER_CONTRIBUTION);
            dummyTradeOrder.TradeInvestment = _portfolioFifo1.Investments[0];
            dummyTradeOrder.ExecutionDate = new DateTime(2010, 01, 01);
            dummyTradeOrder.TradeDate = new DateTime(2010, 01, 01);
            dummyTradeOrder.MoneyMoveDate = new DateTime(2010, 01, 01);
            dummyTradeOrder.TradeAmount = new CAmount(-10000);
            dummyTradeOrder.TradeQuantity = new CQuantity(-100);
            dummyTradeOrder.Comment = "Dummy Contribution TradeOrder";
            dummyTradeOrder.TradeClearerId = 1;
            dummyTradeOrder.UserAction = TradeOrderHelper.USERACTION_NEW;
            dummyTradeOrder.ETradeEnteredAs = AllocationEnteredAs.QTY;
            return dummyTradeOrder;
        }

        private static void TestCloning(object src, object copy)
        {
            TestCloning(src, copy, new List<string>());
        }

        /// <summary>
        /// Get object fields via reflection and compare copied fields
        /// </summary>
        /// <param name="src">Source object</param>
        /// <param name="copy">Cloned object</param>
        /// <param name="excludeList">List of fields, not needed to compair</param>
        private static void TestCloning(object src, object copy, List<string> excludeList)
        {
            //get fields from cloned object
            var cloneObjFields = copy.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            //go throught source object simple type fields and compare it
            for (int i = 0; i < src.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).Length; i++)
            {
                var fInfo = src.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)[i];
                if (!excludeList.Contains(fInfo.Name))
                {
                    if (!fInfo.FieldType.IsClass)
                        Assert.IsTrue(cloneObjFields[i].GetValue(copy).ToString() == fInfo.GetValue(src).ToString(),
                                      string.Format("Field '{0}' not equal ('{1}'!='{2}')", fInfo.Name,
                                                    fInfo.GetValue(src), cloneObjFields[i].GetValue(copy)));
                    else if (fInfo.FieldType.Name == "CQuantity" || fInfo.FieldType.Name == "CAmount")
                    {
                        var orgVal = fInfo.GetValue(src);
                        var copyVal = cloneObjFields[i].GetValue(copy);
                        Assert.IsFalse((orgVal == null && copyVal != null) || (orgVal != null && copyVal == null),
                                       string.Format("Field '{0}' not equal, one of values null.", fInfo.Name));
                        Assert.IsTrue((copyVal == null && orgVal == null) || (copyVal.ToString() == orgVal.ToString()),
                                      string.Format("Field '{0}' not equal ('{1}'!='{2}')", fInfo.Name, orgVal, copyVal));
                    }
                }
            }
        }
        #endregion
    }
}
