﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IFS.Interfaces.Common;

namespace IFS.BusinessLayer.OrderManagementSystem
{
    public class TradeOrderContribution : BaseTradeOrder
    {
        #region Constructors

        public TradeOrderContribution()
        {
            TradeType = TradeOrderType.TRADE_ORDER_CONTRIBUTION;
        }

        public TradeOrderContribution(TradeOrderContribution copy, bool primaryKey)
            : base(copy, primaryKey)
        {
            TradeType = TradeOrderType.TRADE_ORDER_CONTRIBUTION;
        }

        public TradeOrderContribution(TradeOrderContribution source, double scalingFactor)
            : base(source, scalingFactor)
        {
            TradeType = TradeOrderType.TRADE_ORDER_CONTRIBUTION;
        }

        #endregion

        #region Methods

        public List<TradeBreakup> GetBreakupData()
        {
            return new List<TradeBreakup> { new TradeBreakup { IsCapitalCall = true, MvLocal = TradeAmount, TransactionDetails = "Capital Call" } };
        }

        #endregion

    }
}
