﻿using System.Collections.Generic;
using System.Web;
using IFS.BusinessLayer.Aggregation;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.Import;

namespace IFS.BusinessLayer.OrderManagementSystem
{
    public interface ITradeOrderProcessor
    {
        BaseTradeOrder TradeOrder { get; set;}

        void AddTradeFileCafm(HttpPostedFile inputFile);
        void ValidateTradeOrder();
        BaseTrade ConvertToTrade();

        void SaveTradeOrder(bool performValidation, ObjectContainer oc);
        void BookTradeOrder(List<string> errorMsgs);
        void CancelTradeOrder(string cancellationComments, TradeOrderWorkflowMetaData metaData, User user);
        List<string> BulkApproveOrRejectTradeOrder(Dictionary<ETradeApprovalAction, List<int>> tradeIdsGroupedByAction, string comments, int userId);
        void AddTradeOrderApproval(ETradeApprovalAction action, string comments, int userId);
        void Aggregate(IAggregator aggregator, IAggCalculator aggCalculator, CSearch filter, Organization organization);
        DerivedFundData TradeOrderSnapshot(IAggCalculator aggCalculator, Organization organization);

        //Workflow Methods
        string RunWorkflow(TradeOrderWorkflowMetaData metaData);
        string RunWorkflow(TradeOrderWorkflowMetaData metaData, out string currentStateName);
        void ForceRunTradeOrder(string stateToMoveTo, string comment, User currentUser);
        void SetSessionUserForWorkflow(int userId);
        void ResetSessionUserForWorkflow();
    }
}
