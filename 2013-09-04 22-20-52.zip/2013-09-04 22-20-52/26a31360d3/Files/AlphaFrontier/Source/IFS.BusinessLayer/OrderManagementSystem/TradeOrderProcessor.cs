﻿using System;
using System.Data.Linq;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Web;
using CafmRepositoryFacade;
using IFS.BusinessLayer.Aggregation;
using IFS.BusinessLayer.Common;
using IFS.BusinessLayer.Import;
using Common.Logging;
using IFS.BusinessLayer.Trade;
using IFS.BusinessLayer.Utilities;
using IFS.BusinessLayer.Cache;
using IFS.DataAccess;
using IFS.Interfaces.Common;
using IFS.Interfaces.Rounding;

namespace IFS.BusinessLayer.OrderManagementSystem
{
    public class TradeOrderProcessor:ITradeOrderProcessor
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(TradeOrderProcessor));

        #region Implementation of ITradeOrderProcessor
        public BaseTradeOrder TradeOrder { get; set; }
        public void AddTradeFileCafm(HttpPostedFile inputFile)
        {
            if (inputFile.ContentLength <= 0)
            {
                return;
            }

            try
            {
                var metadata = new MetaData
                {
                    CafmFundId = TradeOrder.TradeFundId.ToString(CultureInfo.InvariantCulture),
                    CafmPortfolioId = TradeOrder.TradePortfolioId.ToString(CultureInfo.InvariantCulture),
                    CafmUserId = CSession.User.Id.ToString(CultureInfo.InvariantCulture),
                    CafmUserLogin = CSession.User.UserName,
                    CafmFileSource = FileSource.TradeOrder,
                    CafmBaseFundId = CafmRepositoryHelper.TryGetBaseFundId(TradeOrder.TradeFundId).ToString(CultureInfo.InvariantCulture)
                };

                var organizationId = TradeOrder.TradeFund.OrganizationID;
                var fundId = TradeOrder.TradeFundId;

                //For QA
                CafmRepositoryHelper.CreateFullFundSharepointStructure(TradeOrder.TradeFund);

                CafmRepositoryHelper.CafmManager.UploadFile(organizationId.ToString(CultureInfo.InvariantCulture),
                                              fundId.ToString(CultureInfo.InvariantCulture),
                                              PreDefinedFolders.TradeOrder,
                                              Path.GetFileName(inputFile.FileName),
                                              new BinaryReader(inputFile.InputStream).ReadBytes(inputFile.ContentLength),
                                              AttachedDocumentType.TradeOrder,
                                              TradeOrder.Id,
                                              metadata,
                                              null);
            }
            catch (Exception ex)
            {
                _log.Error(ex.Message, ex);
                throw new Exception(ex.Message, ex.InnerException);
            }
        }

        public virtual void SaveTradeOrder(bool performValidation, ObjectContainer oc)
        {
            if(performValidation)
                ValidateTradeOrder();
            if (oc == null)
                oc = new ObjectContainer();
            
            TradeOrder.TradeLastModifiedDate = DateTime.Now;
            TradeOrder.BulkSave(oc);
            using(var bsd = new BulkSaveData())
            {
                bsd.SubmitChanges(oc);
            }
        }

        public void ValidateTradeOrder()
        {
            var cTrade = ConvertToTrade();
            var cTrades = new List<BaseTrade> { cTrade };
            var errorMsgs = new List<string>();
            CImport.ProcessIndividualTrades(cTrades, errorMsgs, false, false);
            cTrade.Organization.TransactionIdList = null;
            RequestCache.ClearCache();
            if(errorMsgs.Count > 0)
                throw new ValidationException(errorMsgs[0]);
        }

        public virtual void BookTradeOrder(List<string> errorMsgs)
        {
            var oc = new ObjectContainer();
            var investments = new List<Investment>();
            var cTrade = ConvertToTrade();
            CImport.ProcessTrade(cTrade, errorMsgs,oc,investments);
            if (errorMsgs.Count > 0)
                throw new ValidationException(errorMsgs[0]);
            TradeOrder.CurrentState = TradeOrder.UserAction == TradeOrderHelper.USERACTION_DELETE
                                          ? TradeOrderHelper.TRADE_CANCELLED
                                          : TradeOrderHelper.TRADE_BOOKED;

            TradeOrder.TradeWfInstanceId = Guid.Empty;
            //Get teh allocation Id.
            var investmentCalcMetadaData = InvestmentCalculatorMetaData.GetMetaData();
            var tradeInvestment = investmentCalcMetadaData.ClonedInvestments.Find(i => i.InvestmentID == TradeOrder.TradeInvestmentId);
            if(tradeInvestment != null)
            {
                var allocation =
                    tradeInvestment.Allocations.Find(
                        a => a.AllocationTransactionId == TradeOrder.TradeOrderTransactionId);
                if(allocation != null)
                {
                    TradeOrder.TradeAllocationId = allocation.AllocationID;
                    allocation.TradeOrder = TradeOrder;
                }
            }
            TradeOrder.BulkSave(oc);
            CImport.SubmitChanges(oc, errorMsgs, null);
            if (errorMsgs.Count > 0)
                throw new ValidationException(errorMsgs[0]);
        }

        public void CancelTradeOrder(string cancellationComments, TradeOrderWorkflowMetaData metaData, User user)
        {
            var errMsg = string.Empty;
            TradeOrder.Comment = cancellationComments;
            TradeOrder.UserAction = TradeOrderHelper.USERACTION_DELETE;

            if (Role.IsAdminRole(metaData.TradeUserRoleId))
            {
                errMsg = DeleteTrade();
            } 
            else if (Component.IsAccessible(Component.OMS_PREPARER, user))
            {
                errMsg = RunWorkflow(metaData);
            }
            else if(Role.IsAccountantRole(metaData.TradeUserRoleId))
            {
                errMsg = SoftDeleteTrade(cancellationComments);
            }
           
            if (!string.IsNullOrEmpty(errMsg))
                throw new ValidationException(errMsg);
        }

        public BaseTrade ConvertToTrade()
        {
            var org = Organization.Loader.GetById(TradeOrder.TradePortfolio.OrganizationID);
            var clearers = TradeOrder.TradePortfolio.GetClearers();
            var clearer = clearers.Find(c => c.EnumValueID == TradeOrder.TradeClearerId);

            var newTrade = new TradeDataImport
                               {
                                   OrganizationId = org.OrganizationID,
                                   ClientId = org.OrganizationClientID,
                                   PortfolioId = TradeOrder.TradePortfolio.Id,
                                   PortfolioGlsId = TradeOrder.TradePortfolio.FundGLSID,
                                   TransactionId = TradeOrder.TradeOrderTransactionId,
                                   TradeType = CBulkUploadTrades.TRADE_TYPE_NEW,
                                   AssetType = CBulkUploadTrades.ASSET_TYPE_HF,
                                   UhfFundName = TradeOrder.TradeFund.FullName,
                                   FundId = TradeOrder.TradeFundId,
                                   EffectiveDate = TradeOrder.ExecutionDate,
                                   TradeDate = TradeOrder.TradeDate,
                                   MoneyMoveDate = TradeOrder.MoneyMoveDate,
                                   Percentage = TradeOrder.TradePercentage,
                                   ClearerName = clearer.EnumValueName,
                                   ClearerId = clearer.EnumValueID,
                                   TransSeqNumber = 1,
                                   NotificationDeadline = TradeOrder.Comment,
                                   IsBookedByOms = true
                               };

            var xml = TradeOrder.TradeOrderXmlProperties;
            if (TradeOrder is TradeOrderSubscription)
            {
                newTrade.IsCashlessSubscription = TradeOrder.TradeOrderXmlProperties.IsCashLessSubscription;
                newTrade.AmountLocal = TradeOrder.TradeAmount;
                newTrade.Quantity = TradeOrder.TradeQuantity;
                newTrade.TransactionType = CBulkUploadTrades.TRANSACTION_TYPE_SUB;
                SetFees(newTrade, xml);
            }
            else if(TradeOrder is TradeOrderTransfer)
            {
                var transferTrade = TradeOrder as TradeOrderTransfer;
                switch (TradeOrder.TradeType)
                {
                    case TradeOrderType.TRADE_ORDER_TRANSFER_OUT_3:
                        SetCTradeFromRedemption(newTrade,xml);
                        newTrade.TransactionType = CBulkUploadTrades.TRANSACTION_TYPE_TRANSFER_TO_3RD;
                        break;
                    case TradeOrderType.TRADE_ORDER_TRANSFER:
                        SetCTradeFromRedemption(newTrade, xml);
                        newTrade.TransactionType = CBulkUploadTrades.TRANSACTION_TYPE_TRANSFER;
                        newTrade.IfsToIfsTransferPortfolioGlsId = transferTrade.TradeTransferToPortfolio.FundGLSID;
                        newTrade.IfsToIfsTransferPortfolioId = transferTrade.TradeTransferToPortfolio.PortfolioID;
                        var transferInClearers = transferTrade.TradeTransferToPortfolio.GetClearers();
                        var trasnferInClearer = transferInClearers.Find(c => c.EnumValueID == transferTrade.TradeExchangeClearerId);
                        newTrade.TransferInClearerName = trasnferInClearer.EnumValueName;
                        newTrade.TransferInClearerId = trasnferInClearer.EnumValueID;
                        break;
                    case TradeOrderType.TRADE_ORDER_TRANSFER_IN_3:
                        newTrade.AmountLocal = TradeOrder.TradeAmount;
                        newTrade.Quantity = TradeOrder.TradeQuantity;
                        newTrade.TransactionType = CBulkUploadTrades.TRANSACTION_TYPE_3RD_TO_IFS;
                        break;
                }
            }
            else if (TradeOrder is TradeOrderExchange)
            {
                SetCTradeFromRedemption(newTrade, xml);
                newTrade.TransactionType = CBulkUploadTrades.TRANSACTION_TYPE_EX;
                var exchangeTrade = TradeOrder as TradeOrderExchange;
                newTrade.ExchangeInFundInstrumentId = exchangeTrade.TradeToFundId;
                newTrade.ExchangeInFundName = exchangeTrade.TradeToFund.FullName;
                var exchangeClearer = clearers.Find(c => c.EnumValueID == exchangeTrade.TradeExchangeClearerId);
                newTrade.TransferInClearerName = exchangeClearer.EnumValueName;
                newTrade.TransferInClearerId = exchangeClearer.EnumValueID;
            }
            else if(TradeOrder is TradeOrderRedemption)
            {
                SetCTradeFromRedemption(newTrade, xml);
            }
            else if (TradeOrder is TradeOrderContribution)
            {
                newTrade.AmountLocal = TradeOrder.TradeAmount;
                newTrade.Quantity = TradeOrder.TradeQuantity;
                newTrade.AssetType = CBulkUploadTrades.ASSET_TYPE_PE;
                newTrade.TransactionType = CBulkUploadTrades.TRANSACTION_TYPE_CONTRIBUTION;
                newTrade.Breakups.AddRange((TradeOrder as TradeOrderContribution).GetBreakupData());
            }

            var t = GetTradeConverter(newTrade);

            if(t != null)                          
                t.ValidateTradeImport();
            return t;
        }

        public static BaseTrade GetTradeConverter(TradeData newTrade)
        {
            return newTrade.AssetType == CBulkUploadTrades.ASSET_TYPE_HF 
                       ? (BaseTrade)new HedgeFundTrade(newTrade) { IsUploadedByAdmin = false }
                       : newTrade.AssetType == CBulkUploadTrades.ASSET_TYPE_PE
                             ? new PvtEquityTrade(newTrade) { IsUploadedByAdmin = false }
                             :   null;
        }


        public void Aggregate(IAggregator aggregator, IAggCalculator aggCalculator, CSearch filter, Organization organization)
        {
            if (filter == null)
                aggregator.AggregateTradeOrder(TradeOrder);
            else
            {
                DerivedFundData tradeOrderDfd = TradeOrderSnapshot(aggCalculator, organization);
                if (tradeOrderDfd != null && CSearch.ApplyFilters(tradeOrderDfd, filter))
                    aggregator.AggregateTradeOrder(TradeOrder);
            }
        }

        public DerivedFundData TradeOrderSnapshot(IAggCalculator aggCalculator, Organization organization)
        {
            if (TradeOrder.TradeDate > aggCalculator.ValuationEndDate)
                return null;

            var investment = new Investment(TradeOrder.TradeInvestment, true);
            investment.TradeOrders.Add(TradeOrder);

            DerivedFundData tradeOrderDfd = investment.InvestmentSnapshot(aggCalculator, organization);
            tradeOrderDfd.SourceType = DerivedFundData.ESourceType.TRADEORDER;
            tradeOrderDfd.Source = this;
            tradeOrderDfd.AggregationKey = "tradeOrder";
            tradeOrderDfd.AggregationValue = TradeOrder.TradeDate;
            tradeOrderDfd.TransactionData.IsTradeExecution = false;
            return tradeOrderDfd;
        }

        public string RunWorkflow(TradeOrderWorkflowMetaData metaData)
        {
            string currentStateName;
            return RunWorkflow(metaData, out currentStateName);
        }

        public string RunWorkflow(TradeOrderWorkflowMetaData metaData, out string currentStateName)
        {
            string errorMessages;
            currentStateName = string.Empty;
            try
            {
                //Check if trade order is modified before running the wf.
                TradeOrder.CheckConcurrency();
                
                if (metaData.TradeOrderIn == null)
                    metaData.TradeOrderIn = TradeOrder;

                var omsWorkflowInvoker = (IWorkflowInvoker<TradeOrderWorkflowMetaData>)SpringUtil.GetObject(TradeOrderHelper.SPRING_OMS_WF_INVOKER);
                omsWorkflowInvoker.WorkflowInputs = new Dictionary<string, object>
                            {
                                { "TradeOrderMetaData", metaData }
                            };
                omsWorkflowInvoker.IsNewInstance = TradeOrder.TradeWfInstanceId == Guid.Empty;
                omsWorkflowInvoker.InitializeWorkflow(SQLHelper.ConnectionString);
                if (omsWorkflowInvoker.IsNewInstance)
                {
                    omsWorkflowInvoker.StartWorkflow();
                }
                else
                {
                    omsWorkflowInvoker.ReloadWorkflow(TradeOrder.TradeWfInstanceId, metaData);
                }
                errorMessages = omsWorkflowInvoker.ErrorMessages;
                currentStateName = omsWorkflowInvoker.CurrentStateName;
            }
            catch(ChangeConflictException)
            {
                throw;
            }
            catch (Exception ex)
            {
                _log.Error(ex.Message);
                if (ex.InnerException != null)
                    _log.Error("InnerException", ex.InnerException);
                errorMessages = TradeOrderWorkflowMessages.GENERIC_ERROR_MSG;
            }
            return errorMessages;
        }

        public virtual void SetSessionUserForWorkflow(int userId)
        {
            var user = User.Loader.GetById(userId) ?? User.Admin();
             SessionCache.Insert("User", user);
        }

        public virtual void ResetSessionUserForWorkflow()
        {
            SessionCache.Remove("User");
        }

        public List<string> BulkApproveOrRejectTradeOrder(Dictionary<ETradeApprovalAction, List<int>> tradeIdsGroupedByAction,
                                             string comments, int userId)
        {
            var errMsgs = new List<string>();
            var currentUser = User.Loader.GetById(userId);
            var portIdsToClear = new HashSet<int>();
            foreach (KeyValuePair<ETradeApprovalAction, List<int>> pair in tradeIdsGroupedByAction)
            {
                var approvalAction = pair.Key;
                var trades = TradeOrderHelper.GetClonedTradeOrders(pair.Value);
                foreach (var trade in trades)
                {
                    if (approvalAction == ETradeApprovalAction.APPROVED && trade.IsTradeFundBaseFund)
                    {
                        errMsgs.Add(trade.TradeFundFullName +  " - Trade Order cannot be approved unless the class/series has been specified");
                        continue;
                    }

                    TradeOrder = trade;
                    portIdsToClear.Add(trade.TradePortfolioId);
                    var metadata = new TradeOrderWorkflowMetaData
                                       {
                                           ApprovalAction = approvalAction,
                                           ApprovalComment = comments,
                                           ApproverUserId = userId,
                                           CurrentUserId = userId,
                                           TradeOrderIn = trade,
                                           TradeUserRoleId = currentUser.Role.RoleID
                                       };
                    var errMsg = RunWorkflow(metadata);
                    if(!string.IsNullOrEmpty(errMsg))
                        errMsgs.Add(trade.TradeFundFullName + " - " + errMsg);
                }
            }
            foreach (int id in portIdsToClear)
            {
                Portfolio.Loader.Remove(id);
            }

            return errMsgs;
        }

        public void ForceRunTradeOrder(string stateToMoveTo, string comment, User currentUser)
        {
            //Build Basic MetaData
            var metadata = new TradeOrderWorkflowMetaData
                               {
                                   CurrentUserId = currentUser.UserID,
                                   TradeOrderIn = TradeOrder,
                                   TradeUserRoleId = currentUser.UserRoleID,
                                   IsForceRunByAdmin = true,
                                };
            TradeOrder.TradeWfInstanceId = Guid.Empty;
            
            //start a new workflow
            var omsWorkflowInvoker = (IWorkflowInvoker<TradeOrderWorkflowMetaData>)SpringUtil.GetObject(TradeOrderHelper.SPRING_OMS_WF_INVOKER);
            omsWorkflowInvoker.WorkflowInputs = new Dictionary<string, object>
                            {
                                { "TradeOrderMetaData", metadata }
                            };
            omsWorkflowInvoker.IsNewInstance = TradeOrder.TradeWfInstanceId == Guid.Empty;
            omsWorkflowInvoker.InitializeWorkflow(SQLHelper.ConnectionString);
            omsWorkflowInvoker.StartWorkflow();
            var currentStateName = omsWorkflowInvoker.CurrentStateName;
            var instanceId = omsWorkflowInvoker.WfTradeOrder.TradeWfInstanceId;
            metadata.ApproverUserId = -1;
            metadata.ApprovalComment = comment;
            var loopCount = 0;
            while (currentStateName != stateToMoveTo && !omsWorkflowInvoker.IsCompleted)
            {
                if (loopCount > 1000)
                    throw new Exception("Endless loop when trying to force run workflow. Please try again.");

               if (stateToMoveTo == TradeOrderHelper.TRADE_CANCELLED)
                    TradeOrder.UserAction = TradeOrderHelper.USERACTION_DELETE;
                
                metadata.ApprovalAction = stateToMoveTo == TradeOrderHelper.REJECTED
                                              ? ETradeApprovalAction.REJECTED
                                              : ETradeApprovalAction.APPROVED;

               omsWorkflowInvoker.IsNewInstance = false;
               omsWorkflowInvoker.InitializeWorkflow(SQLHelper.ConnectionString);
               omsWorkflowInvoker.ReloadWorkflow(instanceId, metadata);
               currentStateName = omsWorkflowInvoker.CurrentStateName;
               TradeOrder.CurrentState = currentStateName;
                loopCount++;
            }

            TradeOrder.TradeWfInstanceId = instanceId;
            TradeOrder.TradeLastModifiedUserId = currentUser.UserID;
            SaveTradeOrder(false,null);
        }
        #endregion

        #region Other Methods
        private void SetCTradeFromRedemption(TradeDataImport newTrade, TradeOrderXmlProperties xml)
        {
            var redemptionTrade = (TradeOrderRedemption)TradeOrder;
            newTrade.AmountLocal = RoundingBase.IsNaN(redemptionTrade.TradeAmount) ? CAmount.NaN : -redemptionTrade.TradeAmount;
            newTrade.Quantity = RoundingBase.IsNaN(redemptionTrade.TradeQuantity) ? CQuantity.NaN : -redemptionTrade.TradeQuantity;
            newTrade.Percentage = redemptionTrade.TradePercentage;
            newTrade.TransactionType = CBulkUploadTrades.TRANSACTION_TYPE_RED;
            SetFees(newTrade, xml);
            if (xml.Holdback.FeeEnteredAsAmt)
                newTrade.HoldbackAmount = CAmount.Zero();
            else
                newTrade.HoldbackPct = 0;
            //Set Redemption lots
            redemptionTrade.RedemptionLots.ForEach(rl =>
            {
                var cl = new TradeLot
                {
                    LotAmount = RoundingBase.IsNaN(rl.LotDeltaLocal) ? CAmount.NaN : -rl.LotDeltaLocal,
                    LotQuantity = RoundingBase.IsNaN(rl.LotQuantity) ? CQuantity.NaN : -rl.LotQuantity,
                    LotEnteredAs = rl.LotEnteredAs,
                    LotPercentage = rl.LotPercent,
                    LotSubscriptionId = rl.SubscriptionId
                };
                newTrade.TradeLots.Add(cl);
            });
            newTrade.LotIdentifier = newTrade.TradeLots.Count > 0 ? newTrade.TradeLots[0].LotSubscriptionId : -1;
        }

        private string SoftDeleteTrade(string reasonForCancellation)
        {
            var errMsg = string.Empty;
            //Get TradeOrder Allocation and try Cancel it.
            try
            {
                var allocation = TradeOrder.TradeAllocation;
                Allocation.ValidateTradeForSoftDelete(allocation, TradeOrder.TradePortfolio, reasonForCancellation, DateTime.Now);
                var oc = new ObjectContainer();
                allocation.BulkSoftDelete(reasonForCancellation, oc);
                using(var bsd = new BulkSaveData())
                {
                    bsd.SubmitChanges(oc);
                }
            }
            catch(ValidationException valEx)
            {
                errMsg = valEx.Message;
            }
            return errMsg;
        }

        private string DeleteTrade()
        {
            var errMsg = string.Empty;
            try
            {
                var tradeInvestmentId = TradeOrder.TradeInvestmentId;
                var allocation = TradeOrder.TradeAllocation;
                var oc = new ObjectContainer();
                if(allocation != null)
                {
                    Allocation.ValidateTradeForCancellation(allocation, TradeOrder.TradePortfolio);
                    allocation.BulkDeleteAndUpdateFutureAllocations(oc);
                }
                else
                {
                    TradeOrder.BulkDelete(oc);
                }

                using (var bsd = new BulkSaveData())
                {
                    bsd.SubmitChanges(oc);
                }
                DeleteEmptyInvestment(tradeInvestmentId);
            }
            catch (ValidationException valEx)
            {
                errMsg = valEx.Message;
            }
            return errMsg;
        }

        private void DeleteEmptyInvestment(int investmentId)
        {
            // Reload investment
            var investment = Investment.GetById(investmentId);
            bool isInvestmentDeleted;
            Investment.DeleteInvestmentIfEmpty(investment, investment.Portfolio, out isInvestmentDeleted, null);
        }

        private void SetFees(TradeData newTrade, TradeOrderXmlProperties xml)
        {
            if (xml.TradeFee.FeeEnteredAsAmt)
                newTrade.TradeFeeAmount = xml.TradeFee.FeeAmount;
            else
                newTrade.TradeFeePct = xml.TradeFee.FeePct;

            if (xml.BrokerFee.FeeEnteredAsAmt)
                newTrade.BrokerFeesAmount = xml.BrokerFee.FeeAmount;
            else
                newTrade.BrokerFeesPct = xml.BrokerFee.FeePct;
        }

        public void AddTradeOrderApproval(ETradeApprovalAction approvalAction, string comments, int userId)
        {
            TradeOrder.TradeApprovalAction = Enum.GetName(approvalAction.GetType(), approvalAction);
            TradeOrder.TradeApprovalLevel += 1;
            TradeOrder.TradeLastModifiedDate = DateTime.Now;
            TradeOrder.TradeLastModifiedUserId = userId;
        }
        #endregion
    }
}
