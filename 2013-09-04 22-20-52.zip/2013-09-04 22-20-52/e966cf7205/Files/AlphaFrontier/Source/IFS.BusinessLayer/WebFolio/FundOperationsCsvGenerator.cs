﻿
using System;
using System.Collections.Generic;
using System.Text;
using IFS.BusinessLayer.WebFolio.Export;
using IFS.Interfaces.Rounding;


namespace IFS.BusinessLayer.WebFolio
{
    public class FundOperationsCsvGenerator: IFundOperationsGenerator
    {

        private const string CSV_HEADER =
            @"Portfolio ID,Transaction Type,Sub Type,UHF Fund Name,Local Currency,AF Instrument ID,Clearer,Lot ID,Effective Date,Trade Date,Money Move Date,Shares," +
            @"Amount Expression,Amount Local,Cross Expression,Trade Rate,Trade Price,Trade Price Status,Book Equalization Credit Amount,Last Equalization Credit Amount," +
            @"Last Equalization Credit Shares,Equalization Credit status,Front Load Fees Type,Front Load Fees Amount,Webfolio Trade ID,AF Status";


        public string FundOperationsReport(WfExportDataLine reportLine)
        {
            var builder = new StringBuilder(CSV_HEADER + Environment.NewLine, 512);
            WriteWfExportDataLine(builder, reportLine);
            return builder.ToString();
        }

        public string FundOperationsReport(List<WfExportDataLine> reportLines)
        {
            var builder = new StringBuilder(CSV_HEADER + Environment.NewLine, 512 * reportLines.Count);
            foreach (var line in reportLines)
                WriteWfExportDataLine(builder, line);
            return builder.ToString();
        }

        private void WriteWfExportDataLine(StringBuilder builder, WfExportDataLine line)
        {
            builder.Append(line.PortfolioId).Append(',');
            builder.Append(line.TransactionType).Append(',');
            builder.Append(line.SubType).Append(',');
            builder.Append(line.FundName.Replace(",", string.Empty)).Append(',');
            builder.Append(line.LocalCurrency).Append(',');
            builder.Append(line.AfInstrumentId).Append(',');
            builder.Append(line.ClearerName).Append(',');
            builder.Append(line.LotId).Append(',');
            builder.Append(line.EffectiveDate.ToShortDateString()).Append(',');
            builder.Append(line.TradeDate.ToShortDateString()).Append(',');
            builder.Append(line.MoneyMoveDate.ToShortDateString()).Append(',');
            builder.Append('"').Append(line.Shares.ToString(CQuantity.FORMAT_STRING)).Append("\",");
            builder.Append(line.AmountExpression).Append(',');
            builder.Append('"').Append(line.AmountLocal.ToString(CAmount.FORMAT_STRING)).Append("\",");
            builder.Append(line.CrossExpression).Append(',');
            builder.Append(line.TradeRate).Append(',');
            builder.Append(line.TradePrice).Append(',');
            builder.Append(line.TradePriceStatus).Append(",,,,,");
            builder.Append(line.FrontLoadFeesType).Append(',');
            if(line.FrontLoadFeesAmount != null)
                builder.Append('"').Append(line.FrontLoadFeesAmount.ToString(CAmount.FORMAT_STRING)).Append('"');
            builder.Append(',');
            builder.Append(line.WebFolioTradeId).Append(',');
            builder.Append(line.AfStatus);

            builder.Append(Environment.NewLine);
        }
    }
}
