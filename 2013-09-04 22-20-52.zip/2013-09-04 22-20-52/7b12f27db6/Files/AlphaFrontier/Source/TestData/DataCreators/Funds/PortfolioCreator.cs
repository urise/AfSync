﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using CafmRepositoryFacade;
using Common.Logging;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.Common;
using IFS.Interfaces.Rounding;
using TestData.Classes;
using TestData.Common;
using TestData.DataCreators.Allocations;
using TestData.DataObjects;

namespace TestData.DataCreators.Funds
{
    class PortfolioCreator
    {
        #region <<< Members >>>
        private static readonly ILog _log = LogManager.GetLogger(typeof(PortfolioCreator));


        #endregion

        #region <<< Methods >>>
        private Portfolio InitializaPortfolio(PortfolioData portfolioData)
        {
            var organizationId = String.IsNullOrEmpty(portfolioData.OrganizationName) ? DataProvider.GsmOrganizationId : DataProvider.GetOrganizationIdByName(portfolioData.OrganizationName);
            DataProvider.LoadPortfolios(organizationId);
            var result = new Portfolio
                    {
                        FundName = portfolioData.PortfolioName,
                        OrganizationID = organizationId,
                        IfsPortfolioId = portfolioData.IfsPortfolioId,
                        InitializationDate = portfolioData.InitializationDate == DateTime.MinValue ? portfolioData.IssueDate.AddDays(-1) : portfolioData.InitializationDate,
                        IsTradeExecution = portfolioData.IsTradeExecution,
                        TradeExecutionDate = portfolioData.TradeExecutionDate,
                        IssueDate = portfolioData.IssueDate,
                        OfferPrice = portfolioData.OfferPrice,
                        IsShortSaleEnabled = portfolioData.EnableShortSales,
                        MaxLevelsOfApprovalForOms = portfolioData.LevelsOfApproval,
                        CashBalanceModificationsDisabled = portfolioData.DisableCashBalanceModifications,
                        GlsNonHfMvImportEnabled = portfolioData.EnableNonHfMarketValueImport,
                        ReliefMethodology = DataProvider.GetReliefMethodologyIdFromString(portfolioData.ReliefMethodology.ToLower()),
                        IsRegServiceApprovalRequired = portfolioData.IsRegServicesApprovalRequired,
                        SendGlsMessages = portfolioData.SendGlsMessages
                    };
            if (portfolioData.CashBalanceModificationsDisabled != null)
                result.CashBalanceModificationsDisabled = (bool) portfolioData.CashBalanceModificationsDisabled;
            if (portfolioData.GlsNonHfMvImportEnabled != null)
                result.GlsNonHfMvImportEnabled = (bool) portfolioData.GlsNonHfMvImportEnabled;
            if (portfolioData.IssDataImportEnabled != null)
                result.IssDataImportEnabled = (bool) portfolioData.IssDataImportEnabled;
            if (! double.IsNaN(portfolioData.InitialNav))
            {
                result.InitialNav = new CAmount(portfolioData.InitialNav);
                result.InitialNavDate = portfolioData.InitialNavDate;
            }
            return result;
        }

        public Portfolio Create(PortfolioData portfolioData)
        {
            Portfolio portfolio = null;
            try
            {
                portfolio = InitializaPortfolio(portfolioData);
                CSession.OrganizationID = portfolio.OrganizationID;
                _log.Info("Creating portfolio: name=" + portfolioData.PortfolioName);

                portfolio.SaveAll(false);
                if (AppConfiguration.UseCafm)
                {
                    var bw = new BackgroundWorker();
                    bw.DoWork += delegate
                    {
                        var metaData = new MetaData
                        {
                            CafmClient = portfolio.OrganizationID.ToString(),
                            CafmPortfolioId = portfolio.FundID.ToString(),
                            CafmUserId = DataProvider.User.UserID.ToString(),
                            CafmUserLogin = DataProvider.User.UserName
                        };


                        CafmRepositoryHelper.CafmRepository.CreatePortfolio(
                            portfolio.OrganizationID.ToString(),
                            portfolio.FundID.ToString(),
                            portfolio.FundName,
                            metaData
                            );
                    };
                    bw.RunWorkerAsync();

                }
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(_log, ex);
            }
            return portfolio;
        }
        public void CreateLockdowns(PortfolioData portfolioData)
        {
            try
            {
                var portfolio = DataProvider.GetPortfolioByName(portfolioData.PortfolioName, DataProvider.GetOrganizationIdByName(portfolioData.OrganizationName));
                CSession.OrganizationID = portfolio.OrganizationID;
                if (portfolioData.Lockdowns != null)
                {
                    //portfolio.Investments = null;
                    foreach (var lockdown in portfolioData.Lockdowns)
                    {
                        _log.Info("Creating " + (lockdown.IsSoftLock?"Soft":"Hard") + "Lockdown portfolio " + portfolioData.PortfolioName + " on date " + lockdown.LockdownAsOfDate + ".");
                        var portfolioLockdown = portfolio.NewLockdown(lockdown.LockdownDataEndDate, DateTime.MinValue, CSession.UserID);
                        var lockedAs = string.IsNullOrEmpty(lockdown.LockdownAsOfDateStr) ? DateTime.MinValue : lockdown.LockdownAsOfDate;
                        var sb = new StringBuilder();
                        if (lockedAs != DateTime.MinValue)
                        {
                            portfolioLockdown.LockdownAsOfDate = lockedAs;
                            portfolioLockdown.IsSoftLockdown = lockdown.IsSoftLock;
                            portfolio.LockPortfolio(portfolioLockdown, sb);
                            var error = sb.ToString();
                            if(!string.IsNullOrEmpty(error))
                                _log.Error("Error while creating lockdown: " + error);
                            else
                                portfolio.SetLockdown(portfolioLockdown);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(_log, ex);
            }
        }

        public void CreateAllocations(PortfolioData portfolioData)//, int clearerId)
        {
            try
            {
                var portfolio = DataProvider.GetPortfolioByName(portfolioData.PortfolioName, DataProvider.GetOrganizationIdByName(portfolioData.OrganizationName));
                CSession.OrganizationID = portfolio.OrganizationID;
                
                if (portfolioData.Allocations != null)
                {
                    //_allocationsToUpdate[portfolioData.PortfolioName] = new List<Allocation>();
                    //_allocationsDataForUpdate[portfolioData.PortfolioName] = new List<AllocationData>();
                    CreateAllocations(portfolio, portfolioData.Allocations, portfolioData);
                    portfolio.Investments = null;
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(_log, ex);
            }
        }

        public void CreateBackDateAllocations(PortfolioData portfolioData)
        {
            try
            {
                if (portfolioData.BackDateAllocations != null)
                {
                    var portfolio = DataProvider.GetPortfolioByName(portfolioData.PortfolioName, DataProvider.GetOrganizationIdByName(portfolioData.OrganizationName));
                    CSession.OrganizationID = portfolio.OrganizationID;

                    _log.Info("Creating back date allocations for portfolio " + portfolioData.PortfolioName);
                    CreateAllocations(portfolio, portfolioData.BackDateAllocations, portfolioData);
                    _log.Info("Finished creating back date allocations for portfolio " + portfolioData.PortfolioName);
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(_log, ex);
            }
        }

        public List<EnumValue> CreateEnumValues(PortfolioData portfolioData, Portfolio portfolio,
                                                int enumValueGroupId, EnumValueData[] dataEnumValueDalaList)
        {
            var enumValues = new List<EnumValue>();
            try
            {
                var creator = new EnumValueCreator();
                enumValues.AddRange(
                    dataEnumValueDalaList.Select(enumValueData => creator.Create(enumValueGroupId, enumValueData, portfolio))
                                            .Where(enumValue => enumValue != null));
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(_log, ex);
            }
            return enumValues;
        }

        private void CreateAllocations(Portfolio portfolio, IEnumerable<AllocationData> allocationData, PortfolioData portfolioData)
        {
            foreach (var data in allocationData)
            {
                var creatorFactory = new AllocationCreatorFactory(portfolio, data.Clearer, data.Registrar);
                creatorFactory.GetAllocationCreator(data.AllocationTypeId).Create(data);
                GlobalRuntimeCache.Insert(portfolio);
                //if (data.HasBackdated())
                //{
                //    _allocationsToUpdate[portfolioData.PortfolioName].Add(createdAllocation);
                //    _allocationsDataForUpdate[portfolioData.PortfolioName].Add(data);
                //}
            }
        }

        public void UpdateDeleteAllocations(PortfolioData portfolioData)
        {
            try
            {
                if (portfolioData.Allocations == null)// || _allocationsToUpdate[portfolioData.PortfolioName].Count == 0)
                    return;

                var portfolio = DataProvider.GetPortfolioByName(portfolioData.PortfolioName,
                                                                DataProvider.GetOrganizationIdByName(portfolioData.OrganizationName));
                CSession.OrganizationID = portfolio.OrganizationID;
                //var allocationsData = _allocationsDataForUpdate[portfolioData.PortfolioName];
                //var allocations = _allocationsToUpdate[portfolioData.PortfolioName];

                foreach (var allocationData in portfolioData.Allocations)
                {
                    UpdateDelete(allocationData.GetBackdated(), portfolio, allocationData, allocationData.AllocationId, null);

                    var subAllocations = allocationData.GetSubAllocations();
                    if (subAllocations!=null)
                    {
                        var parent = portfolio.GetAllocationById(allocationData.AllocationId);
                        UpdateDeleteSubAllocations(portfolio, subAllocations, parent);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(_log, ex);
            }
        }

        private void UpdateDeleteSubAllocations(Portfolio portfolio, AllocationData[] subAllocations, Allocation parent)
        {

            foreach (var subAllocationData in subAllocations)
            {
                UpdateDelete(subAllocationData.GetBackdated(), portfolio, subAllocationData, subAllocationData.AllocationId, parent);
            }    
        }

        private void UpdateDelete(IEnumerable<BackdateOperationData> backdated, Portfolio portfolio, AllocationData allocationData, int allocationId, Allocation parent)
        {
            if (backdated == null) return;
            foreach (var backdate in backdated)
            {
                var clearerId = portfolio.Clearers.Find(c => c.EnumValueName == allocationData.Clearer).EnumValueID;
                var registrarId = allocationData.Registrar != null ? portfolio.Registrars.Find(c => c.EnumValueName == allocationData.Registrar).EnumValueID : -1;
                var creatorFactory = new AllocationCreatorFactory(portfolio, clearerId, registrarId);
                // Redemption update/delete works only for single lot.
                var creator = creatorFactory.GetAllocationCreator(allocationData.AllocationTypeId);
                creator.ParentAllocation = parent;
                switch (backdate.Operation)
                {
                    case "update":
                        creator.Update(allocationId, allocationData, backdate);
                        break;
                    case "delete":
                        creator.Delete(allocationId);
                        break;
                }
            }
        }

        public void CreateTradeOrderSubscriptions(PortfolioData portfolioData)
        {
            try
            {
                var portfolio = DataProvider.GetPortfolioByName(portfolioData.PortfolioName, DataProvider.GetOrganizationIdByName(portfolioData.OrganizationName));
                CSession.OrganizationID = portfolio.OrganizationID;
                var clearerId = -1;
                if(portfolio.Clearers != null && portfolio.Clearers.Any())
                {
                    clearerId = portfolio.Clearers.First().EnumValueID;
                }
                if (portfolioData.TradeOrderSubscriptions != null)
                {
                    var tradeOrderSubscriptionCreator = new TradeOrderSubscriptionCreator();
                    foreach (var tradeOrderSubscriptionData in portfolioData.TradeOrderSubscriptions)
                    {
                        tradeOrderSubscriptionCreator.Create(tradeOrderSubscriptionData, portfolio, clearerId);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(_log, ex);
            }
        }

        public void CreateEstimatesBySecurity(Dictionary<Portfolio, List<AllocationData>> portfolioAllocationData)
        {
            try
            {
                var estimateList = new List<EstimateWrapper>();
                foreach (var item in portfolioAllocationData)
                {
                    CSession.OrganizationID = item.Key.OrganizationID;
                    foreach (var subscriptionData in item.Value)
                    {
                        estimateList.AddRange(AllocationCreator.SaveEstimates(subscriptionData, item.Key));
                    }
                }
                EstimateCreator.CafmSaveEstimateAttachments(estimateList);
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(_log, ex);
            }
        }

        public void Delete(PortfolioData portfolioData)
        {
            _log.Info("Deleting portfolio " + portfolioData.PortfolioName);
            var organizationId = DataProvider.GetOrganizationIdByName(portfolioData.OrganizationName);
            var portfolio = DataProvider.GetPortfolioByName(portfolioData.PortfolioName, organizationId);
            if (portfolio != null)
                DeletePortfolioData(portfolio);
            else
                _log.Warn("Portfolio wasn't found, skiping...");
        }
        public StringBuilder Ids=new StringBuilder();

        private void DeletePortfolioData(Portfolio p)
        {
            //Ids.Append(p.FundID).Append(",");
            p.AdminDelete();
            if (!DataProvider.CafmBulkDelete && CafmRepositoryHelper.CafmRepository.IsFolderExists(p.OrganizationID.ToString(), CafmRepository.GetAlphaFrontierEntityFolderName(p.FundID.ToString())))
                CafmRepositoryHelper.RemoveAlphaFrontierEntity(p);
        }

        #endregion
    }
}
