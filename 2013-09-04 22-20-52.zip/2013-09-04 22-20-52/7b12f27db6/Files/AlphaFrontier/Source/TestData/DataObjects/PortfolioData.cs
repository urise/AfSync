﻿using System;
using System.Xml.Serialization;
using IFS.BusinessLayer;
using TestData.Common;
using System.Collections.Generic;

namespace TestData.DataObjects
{
    [Serializable, XmlType("portfolio")]
    public class PortfolioData
    {
        #region <<< Properties >>>
        [XmlAttribute("name")]
        public string PortfolioName { get; set; }

        [XmlAttribute("client")]
        public string OrganizationName { get; set; }

        [XmlAttribute("ifsportfolioid")]
        public string IfsPortfolioId { get; set; }

        [XmlIgnore]
        public DateTime InitializationDate { get; set; }
        [XmlAttribute("initializationdate")]
        public string InitializationDateStr { get { return InitializationDate.ToShortDateString(); } set { if (!string.IsNullOrEmpty(value)) InitializationDate = DateTime.Parse(value); } }

        [XmlAttribute("tradeexecution")]
        public bool IsTradeExecution { get; set; }

        [XmlIgnore]
        public DateTime IssueDate { get; set; }
        [XmlAttribute("issuedate")]
        public string IssueDateStr { get { return IssueDate.ToShortDateString(); } set { if (!string.IsNullOrEmpty(value)) IssueDate = DateTime.Parse(value); } }

        [XmlIgnore]
        public DateTime TradeExecutionDate { get; set; }
        [XmlAttribute("tradeexecutiondate")]
        public string TradeExecutionDateStr { get { return TradeExecutionDate.ToShortDateString(); } set { if (!string.IsNullOrEmpty(value)) TradeExecutionDate = DateTime.Parse(value); } }

        [XmlAttribute("offerprice")]
        public double OfferPrice { get; set; }

        [XmlAttribute("enableshortsales")]
        public bool EnableShortSales { get; set; }

        [XmlAttribute("levelsofapprovalfordirecttradeentry")]
        public int LevelsOfApproval { get; set; }

        [XmlAttribute("proxy")]
        public bool Proxy { get; set; }

        [XmlAttribute("regservicesapprovalrequired")]
        public bool IsRegServicesApprovalRequired { get; set; }

        [XmlAttribute("disablecashbalancemodifications")]
        public bool DisableCashBalanceModifications { get; set; }

        [XmlAttribute("enablenonhfmarketvalueimport")]
        public bool EnableNonHfMarketValueImport { get; set; }

        [XmlAttribute("reliefmethodology")]
        public string ReliefMethodology { get; set; }

        [XmlAttribute("sendglsmessages")]
        public bool SendGlsMessages { get; set; }

        [XmlAttribute("CashBalanceModificationsDisabled")]
        public string CashBalanceModificationsDisabledStr { get; set; }

        [XmlIgnore]
        public bool? CashBalanceModificationsDisabled
        {
            get { return ConversionHelper.ToNullableBool(CashBalanceModificationsDisabledStr); }
        }

        [XmlAttribute("GlsNonHfMvImportEnabled")]
        public string GlsNonHfMvImportEnabledStr { get; set; }

        [XmlIgnore]
        public bool? GlsNonHfMvImportEnabled
        {
            get { return ConversionHelper.ToNullableBool(GlsNonHfMvImportEnabledStr); }
        }

        [XmlAttribute("IssDataImportEnabled")]
        public string IssDataImportEnabledStr { get; set; }

        [XmlIgnore]
        public bool? IssDataImportEnabled
        {
            get { return ConversionHelper.ToNullableBool(IssDataImportEnabledStr); }
        }

        [XmlAttribute("InitialNav")]
        public double InitialNav { get; set; }

        [XmlIgnore]
        public DateTime InitialNavDate { get; set; }
        [XmlAttribute("InitialNavDate")]
        public string InitialNavDateStr
        {
            get { return InitialNavDate.ToString(); } 
            set { if (!string.IsNullOrEmpty(value)) InitialNavDate = DateTime.Parse(value); }
        }
        
        [XmlArray("clearers")]
        public ClearerData[] Clearers { get; set; }

        [XmlArray("registrars")]
        public RegistrarData[] Registrars { get; set; }

        [XmlArray("subscriptions")]
        [XmlArrayItem(typeof(SubscriptionData)), XmlArrayItem(typeof(RedemptionData)),
         XmlArrayItem(typeof(TransferInData)), XmlArrayItem(typeof(TransferOutData)),
         XmlArrayItem(typeof(TransferIfsToIfsData)), XmlArrayItem(typeof(ExchangeData)), XmlArrayItem(typeof(EqualizationData)),
        XmlArrayItem(typeof(ContingentRedemptionData)), XmlArrayItem(typeof(CashDistributionData))]
        public AllocationData[] Allocations { get; set; }

        [XmlArray("backdateallocations")]
        [XmlArrayItem(typeof(SubscriptionData)), XmlArrayItem(typeof(RedemptionData)),
         XmlArrayItem(typeof(TransferInData)), XmlArrayItem(typeof(TransferOutData)),
         XmlArrayItem(typeof(TransferIfsToIfsData)), XmlArrayItem(typeof(ExchangeData)), XmlArrayItem(typeof(EqualizationData)),
        XmlArrayItem(typeof(ContingentRedemptionData)), XmlArrayItem(typeof(CashDistributionData))]
        public AllocationData[] BackDateAllocations { get; set; }

        [XmlArray("tradeordersubscriptions")]
        public TradeOrderSubscriptionData[] TradeOrderSubscriptions { get; set; }

        [XmlArray("lockdowns")]
        public LockdownData[] Lockdowns { get; set; }
        #endregion

        #region <<< Counstructor >>>
        public PortfolioData()
        {
            PortfolioName = string.Empty;
            OrganizationName = string.Empty;
            IfsPortfolioId = string.Empty;
            InitializationDate = DateTime.MinValue;
            OfferPrice = 100.0;
            IssueDate = DataProvider.DefaultDate;
            TradeExecutionDate = DateTime.MinValue;
            LevelsOfApproval = 1;
            ReliefMethodology = EnumValue.RM_FIFO;
            InitialNav = double.NaN;

            Clearers = new ClearerData[0];
            //Subscriptions = new SubscriptionData[0];
            TradeOrderSubscriptions = new TradeOrderSubscriptionData[0];
        }
        #endregion
    }
}
