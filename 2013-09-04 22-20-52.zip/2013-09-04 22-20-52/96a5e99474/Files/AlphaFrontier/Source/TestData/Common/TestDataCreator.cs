﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Common.Logging;
using IFS.BusinessLayer;
using IFS.BusinessLayer.Cache;
using IFS.BusinessLayer.GSM.CompanyContactManagement;
using IFS.BusinessLayer.GSM.MergeTool;
using IFS.BusinessLayer.Price;
using IFS.BusinessLayer.SecurityPricing;
using IFS.Interfaces.Factories;
using IFS.Interfaces.Rounding;
using TestData.Classes;
using TestData.DataCreators;
using TestData.DataCreators.Funds;
using TestData.DataObjects;
using TestData.InfoClasses;
using File = System.IO.File;

namespace TestData.Common
{
    /// <summary>
    /// Creates data for QA
    /// </summary>
    class TestDataCreator
    {
        #region <<< Members >>>
        private static readonly ILog Log = LogManager.GetLogger(typeof(TestDataCreator));

        #endregion

        #region <<< Public methods >>>
        public void Process(ProgramParameters programParameters)
        {
            DataProvider.Action = programParameters.Action;
            switch (programParameters.Action)
            {
                case ProgramAction.CreateData:
                    CreateData(programParameters.ActionParameter);
                    break;
                case ProgramAction.DeleteData:
                    DeleteData(programParameters.ActionParameter);
                    break;
                case ProgramAction.Maintenance:
                    DbMaintenance();
                    break;
                case ProgramAction.ReloadCache:
                    ReloadCache(programParameters.ActionParameter);
                    break;
                case ProgramAction.DeleteAndCreate:
                    DeleteData(programParameters.ActionParameter);
                    CreateData(programParameters.ActionParameter);
                    break;
            }
        }

        private void CheckExistance(string fileName)
        {
            if (!File.Exists(fileName) && !Directory.Exists(fileName))
            {
                throw new ValidationException("File or Directory " + fileName + " not found");
            }
        }
        #endregion

        #region <<< Private methods >>>

        private void CreateData(string fileName)
        {
            CheckExistance(fileName);
            DataProvider.InitializeCache();
            if (File.GetAttributes(fileName).HasFlag(FileAttributes.Directory))
            {
                BulkCreateFromFile(Directory.GetFiles(fileName, "*.xml", SearchOption.AllDirectories));
            }
            else
            {
                CreateFromFile(fileName);
            }
        }

        private void DeleteData(string fileName)
        {
            CheckExistance(fileName);
            DataProvider.InitializeCache();
            if (File.GetAttributes(fileName).HasFlag(FileAttributes.Directory))
            {
                DataProvider.CafmBulkDelete = true;
                foreach (var file in Directory.GetFiles(fileName, "*.xml", SearchOption.AllDirectories))
                {
                    Delete(file);
                }
            }
            else
            {
                DataProvider.CafmBulkDelete = false;
                Delete(fileName);
            }
        }

        private void DbMaintenance()
        {
            using (var repository = DbRepositoryFactory.GetDbMaintenanceDbRepository())
            {
                repository.DeleteExtraLogs();
                repository.NotificationCleanup();
            }
        }

        private void ReloadCache(string organizationName)
        {
            try
            {
                var organization = Organization.GetByOrganizationName(organizationName);
                if (organization == null) throw new Exception("Organization is not found");
                GlobalRuntimeCache.ReloadCacheForOrganization(organization.OrganizationID);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                if (ex.InnerException != null) Log.Error(ex.InnerException);
            }
        }

        private static void CheckEnvironment()
        {
            if (DataProvider.User == null)
            {
                var username = AppConfiguration.Username;
                throw new CriticalException("User " + username + " not found in database.", null);
            }
        }

        private void CreateFromFile(string fileName)
        {
            Create(GetData(fileName));
        }

        private void BulkCreateFromFile(IEnumerable<string> files)
        {
            var firstSuite = new List<TestDataContainer>();
            var parallelSuite = new List<TestDataContainer>();
            foreach (var fileName in files)
            {
                var testData = GetData(fileName);
                if (testData.Clients != null || testData.Users != null)
                    firstSuite.Add(testData);
                else
                    parallelSuite.Add(testData);
            }
            foreach (var testData in firstSuite)
            {
                Create(testData);
            }
            var parallelOptions = new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount * 4 };
            Parallel.ForEach(parallelSuite, parallelOptions, Create);
        }

        private void Create(TestDataContainer testData)
        {
            DataProvider.ProcessingFile = testData.FileName;
            Log.Info("Started creating data from " + testData.FileName);
            ProcessOrganization(testData, true);
            CreateUsers(testData);
            CheckEnvironment();
            CreateGlobalCompanies(testData);
            CreatePortfolios(testData);
            CreateFunds(testData);
            CreateClientCompanies(testData);
            CreateAllocations(testData);
            AcceptCpPrices(testData);
            UpdateOrganization(testData);
            Log.Info("Finished creating data from " + testData.FileName);
        }
        private static TestDataContainer GetData(string fileName)
        {
            TestDataContainer testData;
            try
            {
                using (var reader = File.OpenRead(fileName))
                {
                    var propertiesSerializer = new XmlSerializer(typeof(TestDataContainer));
                    testData = (TestDataContainer)propertiesSerializer.Deserialize(reader);
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.LogError(Log, ex, "Error parsing xml from file: " + fileName);
                testData = new TestDataContainer();
            }
            testData.FileName = Path.GetFileName(fileName);
            return testData;
        }
        private static void ProcessOrganization(TestDataContainer testData, bool isCreation)
        {
            if (testData.Clients != null)
            {
                var creator = new OrganizationCreator();
                foreach (var organizationData in testData.Clients)
                {
                    if (isCreation)
                        creator.Create(organizationData);
                    else
                        creator.Delete(organizationData);
                }
            }
        }
        private static void UpdateOrganization(TestDataContainer testData)
        {
            if (testData.UpdateClients != null)
            {
                var creator = new OrganizationCreator();
                foreach (var updateOrganizationData in testData.UpdateClients)
                {
                    creator.Update(updateOrganizationData);
                }
            }
        }
        private void CreateUsers(TestDataContainer testData)
        {
            if (testData.Users != null)
            {
                var creator = new UserCreator();
                foreach (var userData in testData.Users)
                {
                    creator.Create(userData);
                }
            }
        }
        private static void CreateGlobalCompanies(TestDataContainer testData)
        {
            if (testData.GlobalCompanies != null)
            {
                var creator = new GlobalCompanyCreator();

                foreach (var globalCompanyData in testData.GlobalCompanies)
                {
                    try
                    {
                        var company = creator.Create(globalCompanyData);
                        if (company != null)
                        {
                            DataProvider.GlobalCompanies.Add(company);
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorHandler.LogError(Log, ex);
                    }
                }
                GsmCompany.Loader.Remove(null);
                GsmCompany.Loader.SelectAll();
                GsmOffice.Loader.Remove(null);
                GsmOffice.Loader.SelectAll();

            }
            //TODO: check if this functionality is used
            if (testData.GlobalPersons != null)
            {
                var creator = new ContactPersonCreator();
                foreach (var contactPersonData in testData.GlobalPersons)
                {
                    try
                    {
                        creator.Create(contactPersonData, null);
                    }
                    catch (Exception ex)
                    {
                        ErrorHandler.LogError(Log, ex);
                    }
                }
                GsmContactPerson.Loader.Remove(null);
                GsmContactPerson.Loader.SelectAll();
            }
        }

        private void CreatePortfolios(TestDataContainer testData)
        {
            if (testData.Portfolios != null)
            {
                CSession.User = DataProvider.User;
                var portfolioCreator = new PortfolioCreator();

                foreach (var portfolio in testData.Portfolios)
                {
                    var p = portfolioCreator.Create(portfolio);
                    if (p == null) continue;

                    DataProvider.AddPortfolioToCache(p);
                    if (portfolio.Clearers != null)
                    {
                        var ids = portfolioCreator.CreateEnumValues(portfolio, p, EnumGroup.CLEARER, portfolio.Clearers);
                        DataProvider.AddEnumValuesToCache(portfolio, EnumGroup.CLEARER, ids);
                    }

                    if (portfolio.Registrars != null)
                    {
                        var ids = portfolioCreator.CreateEnumValues(portfolio, p, EnumGroup.REGISTRARS, portfolio.Registrars);
                        DataProvider.AddEnumValuesToCache(portfolio, EnumGroup.REGISTRARS, ids);
                    }
                }
            }
        }

        private void CreateAllocations(TestDataContainer testData)
        {
            if (testData.Portfolios != null)
            {
                RequestCache.ClearCache();
                //foreach (var organizationId in DataProvider.GetPortfolioOrganizations())
                //{
                //    RequestCache.Remove(string.Format(Portfolio.PORTFOLIOS_REQUEST_KEY, organizationId, true));
                //    RequestCache.Remove(string.Format(Portfolio.PORTFOLIOS_REQUEST_KEY, organizationId, false));
                //}
                var portfolioCreator = new PortfolioCreator();//testData.Portfolios.Length);
                foreach (var portfolio in testData.Portfolios)
                {
                    portfolioCreator.CreateAllocations(portfolio);//, DataProvider.GetClearerByPortfolio(portfolio).EnumValueID);
                }
                //RequestCache.Remove("Portfolios");
                //RequestCache.ClearCache();

                //allocation data have to be groupped by securities to avoid cross cafm asyncronous saving between securities
                var allocationList =
                    testData.Portfolios.Where(portfolioData => portfolioData.Allocations != null)
                        .Select(
                            portfolioData => new
                                                {
                                                    Portfolio = DataProvider.GetPortfolioByName(portfolioData.PortfolioName,
                                                                                                DataProvider.GetOrganizationIdByName(portfolioData.OrganizationName)),
                                                    PortfolioData = portfolioData
                                                })
                        .SelectMany(
                            portfolioInfo => portfolioInfo.PortfolioData.Allocations.Select(allocationData => new
                                                                                                    {
                                                                                                        portfolioInfo.PortfolioData.PortfolioName,
                                                                                                        portfolioInfo.Portfolio,
                                                                                                        AllocationData = allocationData
                                                                                                    }))
                        .GroupBy(portfolioAllocationData => new { portfolioAllocationData.AllocationData.ClientFund, portfolioAllocationData.AllocationData.SecurityName })
                        .Select(groupByFund => groupByFund.GroupBy(groupItem => groupItem.PortfolioName)
                                        .ToDictionary(groupItem => groupItem.FirstOrDefault().Portfolio, groupItem => groupItem.Select(item => item.AllocationData).ToList()))
                        .ToList();
                foreach (var allocationGroup in allocationList)
                {
                    portfolioCreator.CreateEstimatesBySecurity(allocationGroup);
                }
                foreach (var portfolio in testData.Portfolios)
                {
                    portfolioCreator.CreateLockdowns(portfolio);
                }
                foreach (var portfolio in testData.Portfolios)
                {
                    portfolioCreator.CreateTradeOrderSubscriptions(portfolio);
                    portfolioCreator.CreateBackDateAllocations(portfolio);
                    portfolioCreator.UpdateDeleteAllocations(portfolio);
                }
            }
        }

        private void CreateFunds(TestDataContainer testData)
        {
            ProcessBaseFunds(testData.GsmFunds, true, true);
            ProcessBaseFunds(testData.ClientFunds, false, true);
        }

        private void ProcessBaseFunds(IEnumerable<BaseFundData> fundsData, bool isGsm, bool isCreate)
        {
            if (fundsData != null)
            {
                var baseFundCreator = new BaseFundCreator();

                var curFile = DataProvider.ProcessingFile;
                var parallelOptions = new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount * 2 };
                Parallel.ForEach(fundsData, parallelOptions, f =>
                                                {
                                                    DataProvider.ProcessingFile = curFile;
                                                    try
                                                    {
                                                        if (isCreate)
                                                        {
                                                            var baseFund = baseFundCreator.Create(f, isGsm);
                                                            if (baseFund != null)
                                                                DataProvider.AddFundToCache(baseFund);
                                                        }
                                                        else
                                                        {
                                                            baseFundCreator.Delete(f, isGsm);
                                                        }
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        ErrorHandler.LogError(Log, ex);
                                                    }
                                                });
            }
        }

        private void CreateClientCompanies(TestDataContainer testData)
        {
            if (testData.ClientFunds == null) return;

            var clientCompanyCreator = new ClientCompanyCreator();
            var fundOfficeCreator = new FundOfficeCreator();
            var clientFunds = testData.ClientFunds.Where(fundData => fundData.ClientCompanyOffices != null).ToList();

            foreach (var fundData in clientFunds)
            {
                foreach (var companyOfficeData in fundData.ClientCompanyOffices)
                {
                    companyOfficeData.OrganizationName = fundData.Client;
                    var company = clientCompanyCreator.Create(companyOfficeData);
                    if (company != null)
                        DataProvider.GlobalCompanies.Add(company);
                }
            }
            GsmCompany.Loader.Remove(null);
            GsmCompany.Loader.SelectAll();
            GsmOffice.Loader.Remove(null);
            GsmOffice.Loader.SelectAll();
            GsmContactPerson.Loader.Remove(null);
            GsmContactPerson.Loader.SelectAll();
            //System.Threading.Tasks.Parallel.Invoke(() => GsmCompany.Loader.SelectAll(),
            //                                       () => GsmOffice.Loader.SelectAll(),
            //                                       () => GsmContactPerson.Loader.SelectAll());
            foreach (var fundData in clientFunds)
            {
                foreach (var companyOfficeData in fundData.ClientCompanyOffices)
                {
                    var fundOfficeData = new FundOfficeData
                    {
                        CompanyName = companyOfficeData.Name,
                        CompanyType = companyOfficeData.CompanyGroupsString,
                        OfficeCity = companyOfficeData.City,
                        OfficeName = companyOfficeData.OfficeName,
                        OfficeContacts = companyOfficeData.Persons.Select(p => new PersonEmail { Email = p.ContactEmail }).ToArray(),
                        IsApproved = companyOfficeData.IsApproved,
                        IsRSContact = companyOfficeData.IsRsContact
                    };
                    fundOfficeCreator.Create(fundOfficeData,
                                DataProvider.GetBaseFundByName(fundData.FundName, DataProvider.GetOrganizationIdByName(fundData.Client)),
                                DataProvider.GlobalCompanies);
                }
            }
        }

        private Estimate CreateEstimate(Data data, SecurityPricingData cprice, SecurityPricing securityPricing)
        {
            var estimate = data.NewEstimate(false);
            estimate.EstimateReturn = cprice.Return / 100;
            estimate.EstimateCNav = new CNav(cprice.Return + 100);

            estimate.PriceSource = -1;

            estimate.EstimateDate = cprice.EffectiveDate;
            estimate.EstimateIsFlatStale = false;

            estimate.EstimateAsReturn = true;
            estimate.EstimateLastUpdateTimeStamp = DateTime.Now;
            estimate.SecurityPricingId = securityPricing.SecurityPricingId;

            estimate.EnsureEstimateIdSet();
            return estimate;
        }

        private void PublishAttachment(int estimateId, List<string> publishedFileNames)
        {
            var attachments = EstimateAttachment.GetEstimateAttachments(estimateId);
            if (publishedFileNames != null)
                attachments = attachments.Where(r => publishedFileNames.Contains(r.AttachmentName)).ToList();
            PortfolioPublishAttachment.PublishAttachments(attachments);
        }

        private void AcceptCpPriceForClientFundId(int clientId, int clientFundId, FundClass gsmFundClass, 
            Portfolio portfolio, SecurityPricingData cprice, List<string> attachmentNames)
        {
            var fund = new BaseFund(clientFundId);
            var fundClass = fund.FundClasses.Single(f => f.GsmFundId == gsmFundClass.FundID &&
                (string.IsNullOrEmpty(cprice.ClientClassName) || f.FundName == cprice.ClientClassName));
            var series = Series.GetAllSerieses(new List<int> { clientId }).
                Single(s => s.SeriesFundID == fundClass.FundID);
            var data = Series.GetDataPoint(series, cprice.EffectiveDate, fund, true);
            var investment =
                fundClass.InvestmentsAcrossPortfolios().Single(i => i.PortfolioID == portfolio.PortfolioID);
            var estimate = CreateEstimate(data, cprice, gsmFundClass.SecurityPricingList.SecurityPricings.First());
            new EstimateAttachmentManager(estimate.Id, cprice.EffectiveDate, estimate.EstimateIsFinal, estimate.SecurityPricingId,
                fundClass.FundID, fund.OrganizationID, null).CopyFromSecurityPricing(portfolio.PortfolioID);

            data.RefreshDataPoint();
            data.SyncDatapoint(fundClass, series, cprice.EffectiveDate);

            series.UpdatePrices(cprice.EffectiveDate, true, investment); 
            var iCalculator = Investment.GetInvestmentCalculator();
            var messages = new StringBuilder();
            iCalculator.UpdateAndSaveInvestment(cprice.EffectiveDate, series, messages, true);

            if (attachmentNames.Count > 0)
                PublishAttachment(estimate.EstimateId, attachmentNames);
        }

        private void AcceptCpPrice(BaseFundData gsmFundData, FundClassData gsmClassData, SecurityPricingData cprice, AcceptPriceInfo acceptPriceInfo)
        {
            var organization = Organization.GetByOrganizationName(acceptPriceInfo.ClientName);
            if (organization == null)
            {
                Log.Error("Organization " + cprice.OrganizationName + " is not found for cp price");
                return;
            }
            var gsmFund = DataProvider.GetGsmFundByName(gsmFundData.FundName);
            var gsmFundClass = gsmFund.FundClasses.Single(f => f.FundName == gsmClassData.FundName);

            var portfolio = Portfolio.GetPortfoliosForClient(organization.OrganizationID).FirstOrDefault(p => p.PortfolioName == acceptPriceInfo.PortfolioName);
            if (portfolio == null)
            {
                Log.Error("Portfolio " + cprice.PortfolioName + " is not found for organizationID=" + organization.OrganizationID);
                return;
            }
            portfolio.NewLockdown(cprice.EffectiveDate, DateTime.MinValue, DataProvider.User.UserID);

            var clientFundIds = GsmFundLink.GetGsmChildIds(gsmFund.FundID, organization.OrganizationID);
            if (!clientFundIds.Any())
            {
                Log.Error("Cannot find client funds linked to gsm fund");
                return;
            }
            foreach (var clientFundId in clientFundIds)
            {
                AcceptCpPriceForClientFundId(organization.OrganizationID, clientFundId, gsmFundClass, portfolio, 
                    cprice, acceptPriceInfo.AttachmentNames);
            }

        }

        private void AcceptCpPrices(TestDataContainer testData)
        {
            Log.Info("Started accepting CP prices...");
            if (testData.GsmFunds == null) return;

            string prevFundName = string.Empty, prevClassName = string.Empty;
            foreach (var gsmFund in testData.GsmFunds)
            {
                if (gsmFund.Classes == null) continue;
                foreach (var gsmClass in gsmFund.Classes)
                {
                    if (gsmClass.SecurityPricings == null) continue;
                    foreach (var cprice in gsmClass.SecurityPricings.Where(r => r.NeedsToBeAccepted()))
                    {
                        if (gsmFund.FundName != prevFundName)
                        {
                            Log.Info("Fund=" + gsmFund.FundName);
                            prevFundName = gsmFund.FundName;
                        }
                        if (gsmClass.FundName != prevClassName)
                        {
                            Log.Info("Class=" + gsmClass.FundName);
                            prevClassName = gsmClass.FundName;
                        }
                        Log.Info("Price Return=" + cprice.Return);
                        try
                        {
                            var acceptPricesInfo = cprice.GetAcceptPricesInfo();
                            foreach (var warning in acceptPricesInfo.Warnings)
                            {
                                Log.Warn(warning);
                            }
                            foreach (var acceptPriceInfo in acceptPricesInfo.Prices)
                            {
                                AcceptCpPrice(gsmFund, gsmClass, cprice, acceptPriceInfo);
                            }
                        }
                        catch(Exception ex)
                        {
                            ErrorHandler.LogError(Log, ex);
                        }
                    }
                }
            }
        }

        private void Delete(string fileName)
        {
            Log.Info("Started deleting data from " + fileName);
            var testData = GetData(fileName);
            DataProvider.ProcessingFile = testData.FileName;
            ProcessOrganization(testData, false);
            RemovePortfolios(testData);
            RemoveFunds(testData);
            RemoveNotActualDrafts(testData);
            RemoveCompanies(testData);
            RemoveClientCompanies(testData);
            DataProvider.ClearLocalCache();
            Log.Info("Finished deleting data from " + fileName);
        }
        private void RemoveCompanies(TestDataContainer testData)
        {
            if (testData.GlobalCompanies != null)
            {
                var creator = new GlobalCompanyCreator();
                foreach (var globalCompanyData in testData.GlobalCompanies)
                {
                    try
                    {
                        creator.Delete(globalCompanyData);
                    }
                    catch (Exception ex)
                    {
                        ErrorHandler.LogError(Log, ex);
                    }
                }
            }
            //TODO: check if this functionality is used
            if (testData.GlobalPersons != null)
            {
                var creator = new ContactPersonCreator();
                foreach (var contactPersonData in testData.GlobalPersons)
                {
                    try
                    {
                        creator.Delete(contactPersonData);
                    }
                    catch (Exception ex)
                    {
                        ErrorHandler.LogError(Log, ex);
                    }
                }
            }
        }
        private void RemoveClientCompanies(TestDataContainer testData)
        {
            Log.Info("Started deleting client companies");
            var creator = new ClientCompanyCreator();
            if (testData.ClientFunds != null)
            {
                foreach (var companyOffice in testData.ClientFunds.Where(clientFund => clientFund.ClientCompanyOffices != null).
                    SelectMany(clientFund => clientFund.ClientCompanyOffices))
                {
                    creator.Delete(companyOffice);
                }
            }
            Log.Info("Finished deleting client companies");
        }

        private void RemovePortfolios(TestDataContainer testData)
        {
            if (testData.Portfolios != null)
            {
                var portfolioCreator = new PortfolioCreator();
                foreach (var portfolioData in testData.Portfolios)
                {
                    try
                    {
                        portfolioCreator.Delete(portfolioData);
                    }
                    catch (Exception ex)
                    {
                        ErrorHandler.LogError(Log, ex);
                    }
                }
            }
        }
        private void RemoveFunds(TestDataContainer testData)
        {
            ProcessBaseFunds(testData.ClientFunds, false, false);
            ProcessBaseFunds(testData.GsmFunds, true, false);
        }


        private void RemoveNotActualDrafts(TestDataContainer testData)
        {
            if (testData.MergeTool == null || !testData.MergeTool.DeleteDrafts) return;

            Log.Info(string.Format("Start deleting not-actual MergeTool drafts."));
            var draftsContainer = new DraftsContainer();
            var toDelete = draftsContainer.Drafts.Where(draft => DraftView.GetBaseFund(draft.MainFundId) == null).ToList();
            foreach (var draft in toDelete)
            {
                Log.Info(string.Format("Deleting draft: {0}", draft.DraftName));
                draftsContainer.RemoveDraft(draft);
            }
            Log.Info(string.Format("Finished deleting not-actual MergeTool drafts."));
        }
        #endregion
    }
}
