﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestData.InfoClasses
{
    public class AcceptPriceInfo
    {
        public string ClientName { get; set; }
        public string PortfolioName { get; set; }
        public string ClientClassName { get; set; }
        public List<string> AttachmentNames { get; set; }

        public AcceptPriceInfo()
        {
            AttachmentNames = new List<string>();
        }

        public AcceptPriceInfo(string clientName, string portfolioName, string clientClassName = null)
        {
            ClientName = clientName;
            PortfolioName = portfolioName;
            ClientClassName = clientClassName;
            AttachmentNames = new List<string>();
        }

        public AcceptPriceInfo(string clientName, string portfolioName, List<string> attachmentNames)
        {
            ClientName = clientName;
            PortfolioName = portfolioName;
            AttachmentNames = attachmentNames;
        }
    }
}
