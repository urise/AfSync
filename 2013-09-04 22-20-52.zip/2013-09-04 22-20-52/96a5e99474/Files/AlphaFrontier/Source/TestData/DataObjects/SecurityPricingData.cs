﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using TestData.Common;
using TestData.InfoClasses;

namespace TestData.DataObjects
{
    [Serializable, XmlType("price")]
    public class SecurityPricingData
    {
        #region <<< Properties >>>
        [XmlAttribute("return")]
        public double Return { get; set; }

        [XmlAttribute("nav")]
        public double Nav { get; set; }

        [XmlAttribute("mv")]
        public double Mv { get; set; }

        [XmlAttribute("shares")]
        public double Shares { get; set; }

        [XmlAttribute("isfinal")]
        public bool IsFinal { get; set; }

        [XmlAttribute("isflat")]
        public bool IsFlat { get; set; }

        [XmlIgnore]
        public DateTime Received { get; set; }
        [XmlAttribute("received")]
        public string ReceivedStr { get { return Received.ToString(); } set { if (!string.IsNullOrEmpty(value)) Received = DateTime.Parse(value); } }

        [XmlIgnore]
        public DateTime EffectiveDate { get; set; }
        [XmlAttribute("effectivedate")]
        public string EffectiveDateStr { get { return EffectiveDate.ToString(); } set { if (!string.IsNullOrEmpty(value)) EffectiveDate = DateTime.Parse(value); } }
        [XmlAttribute("effectivedateshift")]
        public string EffectiveDateShift { get { return string.Empty; } set { if (!string.IsNullOrEmpty(value)) EffectiveDate = GetShiftedByMonthDate(int.Parse(value)); } }

        [XmlIgnore]
        public DateTime PriceDate { get; set; }
        [XmlAttribute("pricedate")]
        public string PriceDateStr { get { return PriceDate.ToString(); } set { if (!string.IsNullOrEmpty(value)) PriceDate = DateTime.Parse(value); } }
        [XmlAttribute("pricedateshift")]
        public string PriceDateShift { get { return string.Empty; } set { if (!string.IsNullOrEmpty(value)) PriceDate = GetShiftedByMonthDate(int.Parse(value)); } }

        [XmlAttribute("isapproved")]
        public bool IsApproved { get; set; }

        [XmlAttribute("isrejected")]
        public bool IsRejected { get; set; }

        [XmlAttribute("source")]
        public string Source { get; set; }

        [XmlArray("attachments")]
        public AttachmentData[] Attachments { get; set; }

        [XmlArray("comments")]
        public PricingCommentData[] Comments { get; set; }

        [XmlAttribute("portfolio")]
        public string PortfolioName { get; set; }

        [XmlArray("portfolios")]
        public PortfolioRefData[] Portfolios { get; set; }

        [XmlAttribute("client")]
        public string OrganizationName { get; set; }

        [XmlAttribute("group")]
        public int Group { get; set; }

        [XmlAttribute("isgross")]
        public bool IsGross { get; set; }

        [XmlAttribute("isaccepted")]
        public string IsAcceptedStr { get; set; }

        [XmlAttribute("clientclass")]
        public string ClientClassName { get; set; }

        [XmlIgnore]
        public bool? IsAccepted
        {
            get { return ConversionHelper.ToNullableBool(IsAcceptedStr); }
            set { IsAcceptedStr = Convert.ToString(value); }
        }

        [XmlAttribute("ispublished")]
        public string IsPublishedStr { get; set; }

        [XmlIgnore]
        public bool? IsPublished
        {
            get { return ConversionHelper.ToNullableBool(IsPublishedStr); }
            set { IsPublishedStr = Convert.ToString(value); }
        }

        [XmlArray("accepts")]
        public AcceptPriceData[] Accepts { get; set; }

        #endregion

        #region <<< Counstructor >>>
        public SecurityPricingData()
        {
            Return = double.NaN;
            Nav = double.NaN;
            Mv = double.NaN;
            Shares = double.NaN;
            Received = DataProvider.DefaultDate;
            EffectiveDate = DataProvider.DefaultDate;
            PriceDate = DataProvider.DefaultDate;
            Source = "client";
            Attachments = new AttachmentData[0];
            Comments = new PricingCommentData[0];
            Group = -1;
            Portfolios = new PortfolioRefData[0];
        }
        #endregion

        #region Auxilliary Properties and Methods

        public bool PriceIsForOneClient()
        {
            return OrganizationName != null && OrganizationName != Constants.ALL_CLIENTS;
        }

        public bool PriceIsForOnePortfolio()
        {
            return PortfolioName != null;
        }

        public bool WholePriceIsAccepted()
        {
            return IsAccepted ?? false;
        }

        public bool AllAttachmentsArePublished()
        {
            return IsPublished ?? false;
        }

        public bool AcceptsSessionIsFilledUp()
        {
            return Accepts != null && Accepts.Length > 0;
        }

        #endregion

        #region Main Methods

        protected DateTime GetShiftedByMonthDate(int shiftValue)
        {
            var shiftedDate = DateTime.Today.AddMonths(-shiftValue);
            return new DateTime(shiftedDate.Year, shiftedDate.Month, 
                    DateTime.DaysInMonth(shiftedDate.Year, shiftedDate.Month));
        }

        public bool NeedsToBeAccepted()
        {
            return WholePriceIsAccepted() || Accepts != null && Accepts.Length > 0;
        }

        // covered by unit tests
        public List<string> GetAllAttachmentNames()
        {
            return Attachments == null || Attachments.Length == 0
                       ? new List<string> {Constants.ATTACHMENT_CP_NAME_DEFAULT}
                       : Attachments.Select(r => r.FileName).ToList();
        }

        // covered by unit tests
        public AcceptPricesInfo GetAcceptPricesInfo()
        {
            var result = new AcceptPricesInfo();
            
            if (Accepts != null && Accepts.Length == 0)
                result.AddWarning(Messages.ACCEPT_PRICE_ACCEPTS_SECTION_IS_EMPTY);

            if (AllAttachmentsArePublished() && !NeedsToBeAccepted())
                result.AddWarning(Messages.ACCEPT_PRICE_PUBLISHED_BUT_NOT_ACCEPTED);

            if (!NeedsToBeAccepted()) return result;

            if (!IsApproved) return result.AddWarning(Messages.ACCEPT_PRICE_IS_NOT_APPROVED);

            if (PriceIsForOneClient() && PriceIsForOnePortfolio())
            {
                if (!WholePriceIsAccepted()) return result;
                var acceptPriceInfo = new AcceptPriceInfo(OrganizationName, PortfolioName, ClientClassName);
                if (AllAttachmentsArePublished() && Attachments.Length == 0)
                    acceptPriceInfo.AttachmentNames.Add(Constants.ATTACHMENT_CP_NAME_DEFAULT);
                foreach (var attachment in Attachments)
                {
                    if (attachment.NeedsToBePublished() || AllAttachmentsArePublished() && attachment.IsPublished == null)
                    {
                        acceptPriceInfo.AttachmentNames.Add(attachment.FileName);
                    }
                }
                result.Prices.Add(acceptPriceInfo);
            }
            else
            {
                if (WholePriceIsAccepted() || Attachments.Any(r => r.NeedsToBePublished()))
                    result.AddWarning(Messages.ACCEPT_PRICE_WHOLE_ACCEPTED_FOR_ALL_CLIENTS_PORTOLIOS);

                if (Accepts == null) return result;

                foreach (var accept in Accepts)
                {
                    var acceptPriceInfo = GetAcceptPriceInfoByAcceptPriceData(accept, result.AddWarning);
                    if (acceptPriceInfo != null) result.Prices.Add(acceptPriceInfo);
                }
            }
            return result;
        }

        private AcceptPriceInfo GetAcceptPriceInfoByAcceptPriceData(AcceptPriceData accept, Func<string, AcceptPricesInfo> addWarning)
        {
            if (!string.IsNullOrEmpty(accept.Publish) && accept.Publishing != null)
                addWarning(Messages.ACCEPT_PRICE_PUBLISH_IGNORED);

            if (PriceIsForOneClient() && !string.IsNullOrEmpty(accept.Client))
                addWarning(Messages.ACCEPT_PRICE_CLIENT_ALREADY_DEFINED);

            if (string.IsNullOrEmpty(accept.Portfolio))
            {
                addWarning(Messages.ACCEPT_PRICE_NO_PORTFOLIO_IN_ACCEPT);
                return null;
            }

            string clientName = string.IsNullOrEmpty(OrganizationName) ? accept.Client : OrganizationName;
            if (string.IsNullOrEmpty(clientName))
            {
                addWarning(Messages.ACCEPT_PRICE_NO_CLIENT_IN_ACCEPT);
                return null;
            }

            var result = new AcceptPriceInfo(clientName, accept.Portfolio);
            if (accept.Publishing != null)
            {
                var allAttachmentNames = GetAllAttachmentNames();
                result.AttachmentNames.AddRange(accept.Publishing.Where(r => allAttachmentNames.Contains(r.FileName)).
                    Select(r => r.FileName));
                if (result.AttachmentNames.Count < accept.Publishing.Length)
                    addWarning(Messages.ACCEPT_PRICE_WRONG_ATTACHMENT_NAMES);
            }
            else if (accept.Publish != null)
            {
                if (accept.Publish == Constants.ALL)
                    result.AttachmentNames.AddRange(GetAllAttachmentNames());
                else
                    result.AttachmentNames.Add(accept.Publish);
            }

            return result;
        }

        #endregion
    }
}
