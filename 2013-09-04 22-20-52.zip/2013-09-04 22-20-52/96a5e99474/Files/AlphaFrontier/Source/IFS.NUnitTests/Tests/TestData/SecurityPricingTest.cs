﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using TestData.Common;
using TestData.DataObjects;

namespace IFS.NUnitTests.Tests.TestData
{
    [TestFixture]
    public class SecurityPricingTest
    {
        #region GetAcceptPricingInfo() Tests

        #region Simple Negative Cases

        [Test]
        public void GetAcceptPricingInfoTest_SimplestNegative1()
        {
            var price = new SecurityPricingData();
            var result = price.GetAcceptPricesInfo();
            Assert.IsEmpty(result.Prices);
        }

        [Test]
        public void GetAcceptPricingInfoTest_SimplestNegative2()
        {
            var price = new SecurityPricingData()
            {
                IsAccepted = false,
                Accepts = new AcceptPriceData[]{}
            };
            var result = price.GetAcceptPricesInfo();
            Assert.IsEmpty(result.Prices);
            Assert.Contains(Messages.ACCEPT_PRICE_ACCEPTS_SECTION_IS_EMPTY, result.Warnings);
        }

        [Test]
        public void GetAcceptPricingInfoTest_IsAcceptedButIsNotApproved()
        {
            var price = new SecurityPricingData()
            {
                IsApproved = false,
                IsAccepted = true
            };
            var result = price.GetAcceptPricesInfo();
            Assert.IsEmpty(result.Prices);
            Assert.Contains(Messages.ACCEPT_PRICE_IS_NOT_APPROVED, result.Warnings);
        }

        [Test]
        public void GetAcceptPricingInfoTest_IsPublishedButIsNotAccepted()
        {
            var price = new SecurityPricingData()
            {
                IsApproved = true,
                IsAccepted = false,
                IsPublished = true
            };
            var result = price.GetAcceptPricesInfo();
            Assert.IsEmpty(result.Prices);
            Assert.Contains(Messages.ACCEPT_PRICE_PUBLISHED_BUT_NOT_ACCEPTED, result.Warnings);
        }

        #endregion

        #region One Client, One Portfolio

        [Test]
        public void GetAcceptPricingInfoTest_SimplestPositive1()
        {
            var price = new SecurityPricingData()
            {
                OrganizationName = "Some Client",
                PortfolioName = "Some Portfolio",
                ClientClassName = "Some Class",
                IsApproved = true,
                IsAccepted = true
            };
            var result = price.GetAcceptPricesInfo();
            Assert.AreEqual(1, result.Prices.Count);
            Assert.AreEqual("Some Client", result.Prices[0].ClientName);
            Assert.AreEqual("Some Portfolio", result.Prices[0].PortfolioName);
            Assert.AreEqual("Some Class", result.Prices[0].ClientClassName);
            Assert.AreEqual(0, result.Prices[0].AttachmentNames.Count);
        }

        [Test]
        public void GetAcceptPricingInfoTest_DefaultAttachment()
        {
            var price = new SecurityPricingData()
            {
                OrganizationName = "Some Client",
                PortfolioName = "Some Portfolio",
                IsApproved = true,
                IsAccepted = true,
                IsPublished = true
            };
            var result = price.GetAcceptPricesInfo();
            Assert.AreEqual(1, result.Prices.Count);
            Assert.AreEqual("Some Client", result.Prices[0].ClientName);
            Assert.AreEqual("Some Portfolio", result.Prices[0].PortfolioName);
            Assert.AreEqual(1, result.Prices[0].AttachmentNames.Count);
            Assert.AreEqual(Constants.ATTACHMENT_CP_NAME_DEFAULT, result.Prices[0].AttachmentNames[0]);
        }

        [Test]
        public void GetAcceptPricingInfoTest_AttachmentsPublishedByDefault()
        {
            var price = new SecurityPricingData()
            {
                OrganizationName = "Some Client",
                PortfolioName = "Some Portfolio",
                IsApproved = true,
                IsAccepted = true,
                IsPublished = true,
                Attachments = new []
                    {
                        new AttachmentData { FileName = "1.txt" },
                        new AttachmentData { FileName = "2.txt", IsPublished = false },
                        new AttachmentData { FileName = "3.txt" }
                    }
            };
            var result = price.GetAcceptPricesInfo();
            Assert.AreEqual(1, result.Prices.Count);
            Assert.AreEqual("Some Client", result.Prices[0].ClientName);
            Assert.AreEqual("Some Portfolio", result.Prices[0].PortfolioName);
            CollectionAssert.AreEqual(new List<string> { "1.txt", "3.txt" }, result.Prices[0].AttachmentNames);
        }

        [Test]
        public void GetAcceptPricingInfoTest_AttachmentsNotPublishedByDefault()
        {
            var price = new SecurityPricingData()
            {
                OrganizationName = "Some Client",
                PortfolioName = "Some Portfolio",
                IsApproved = true,
                IsAccepted = true,
                IsPublished = false,
                Attachments = new[]
                    {
                        new AttachmentData { FileName = "1.txt", IsPublished = true },
                        new AttachmentData { FileName = "2.txt", IsPublished = false },
                        new AttachmentData { FileName = "3.txt" },
                        new AttachmentData { FileName = "4.txt", IsPublished = true }
                    }
            };
            var result = price.GetAcceptPricesInfo();
            Assert.AreEqual(1, result.Prices.Count);
            Assert.AreEqual("Some Client", result.Prices[0].ClientName);
            Assert.AreEqual("Some Portfolio", result.Prices[0].PortfolioName);
            CollectionAssert.AreEqual(new List<string> { "1.txt", "4.txt" }, result.Prices[0].AttachmentNames);
        }

        [Test]
        public void GetAcceptPricingInfoTest_AttachmentsWithoutDefault()
        {
            var price = new SecurityPricingData()
            {
                OrganizationName = "Some Client",
                PortfolioName = "Some Portfolio",
                IsApproved = true,
                IsAccepted = true,
                Attachments = new[]
                    {
                        new AttachmentData { FileName = "1.txt", IsPublished = true },
                        new AttachmentData { FileName = "2.txt", IsPublished = false },
                        new AttachmentData { FileName = "3.txt" },
                        new AttachmentData { FileName = "4.txt", IsPublished = true }
                    }
            };
            var result = price.GetAcceptPricesInfo();
            Assert.AreEqual(1, result.Prices.Count);
            Assert.AreEqual("Some Client", result.Prices[0].ClientName);
            Assert.AreEqual("Some Portfolio", result.Prices[0].PortfolioName);
            CollectionAssert.AreEqual(new List<string> { "1.txt", "4.txt" }, result.Prices[0].AttachmentNames);
        }

        #endregion

        #region One Client, All Portfolios

        [Test]
        public void GetAcceptPricingInfoTest_AllPortfoliosWholeAcceptNegative()
        {
            var price = new SecurityPricingData()
            {
                OrganizationName = "Some Client",
                IsApproved = true,
                IsAccepted = true
            };
            var result = price.GetAcceptPricesInfo();
            Assert.IsEmpty(result.Prices);
            Assert.Contains(Messages.ACCEPT_PRICE_WHOLE_ACCEPTED_FOR_ALL_CLIENTS_PORTOLIOS, result.Warnings);
        }

        [Test]
        public void GetAcceptPricingInfoTest_AllPortfoliosAttachmentAcceptNegative()
        {
            var price = new SecurityPricingData()
            {
                OrganizationName = "Some Client",
                IsApproved = true,
                Attachments = new[]
                    {
                        new AttachmentData { FileName = "1.txt" },
                        new AttachmentData { FileName = "2.txt", IsPublished = true }
                    },
                Accepts = new[]
                        {
                            new AcceptPriceData()
                        }
            };
            var result = price.GetAcceptPricesInfo();
            Assert.IsEmpty(result.Prices);
            Assert.Contains(Messages.ACCEPT_PRICE_WHOLE_ACCEPTED_FOR_ALL_CLIENTS_PORTOLIOS, result.Warnings);
        }

        [Test]
        public void GetAcceptPricingInfoTest_AllPortfoliosNoAcceptDefined()
        {
            var price = new SecurityPricingData()
                {
                    OrganizationName = "Some Client",
                    IsApproved = true,
                    Accepts = new[]
                        {
                            new AcceptPriceData()
                        }
                };
            var result = price.GetAcceptPricesInfo();
            Assert.IsEmpty(result.Prices);
            Assert.Contains(Messages.ACCEPT_PRICE_NO_PORTFOLIO_IN_ACCEPT, result.Warnings);
        }

        [Test]
        public void GetAcceptPricingInfoTest_AllPortfoliosNoAttachments()
        {
            var price = new SecurityPricingData()
            {
                OrganizationName = "Some Client",
                IsApproved = true,
                Accepts = new []
                    {
                        new AcceptPriceData { Portfolio = "Portfolio 1" },
                        new AcceptPriceData { Portfolio = "Portfolio 2" }
                    }
            };
            var result = price.GetAcceptPricesInfo();
            Assert.AreEqual(2, result.Prices.Count);
            Assert.AreEqual("Some Client", result.Prices[0].ClientName);
            Assert.AreEqual("Portfolio 1", result.Prices[0].PortfolioName);
            Assert.IsEmpty(result.Prices[0].AttachmentNames);
            Assert.AreEqual("Some Client", result.Prices[1].ClientName);
            Assert.AreEqual("Portfolio 2", result.Prices[1].PortfolioName);
            Assert.IsEmpty(result.Prices[1].AttachmentNames);
        }

        [Test]
        public void GetAcceptPricingInfoTest_AllPortfoliosDefaultAttachments()
        {
            var price = new SecurityPricingData()
            {
                OrganizationName = "Some Client",
                IsApproved = true,
                Accepts = new[]
                    {
                        new AcceptPriceData { Portfolio = "Portfolio 1" },
                        new AcceptPriceData { Portfolio = "Portfolio 2", Publish = Constants.ALL }
                    }
            };
            var result = price.GetAcceptPricesInfo();
            Assert.AreEqual(2, result.Prices.Count);
            Assert.AreEqual("Some Client", result.Prices[0].ClientName);
            Assert.AreEqual("Portfolio 1", result.Prices[0].PortfolioName);
            Assert.IsEmpty(result.Prices[0].AttachmentNames);
            Assert.AreEqual("Some Client", result.Prices[1].ClientName);
            Assert.AreEqual("Portfolio 2", result.Prices[1].PortfolioName);
            CollectionAssert.AreEqual(new List<string>{ Constants.ATTACHMENT_CP_NAME_DEFAULT }, result.Prices[1].AttachmentNames);
        }

        [Test]
        public void GetAcceptPricingInfoTest_AllPortfoliosManyAttachments()
        {
            var price = new SecurityPricingData()
            {
                OrganizationName = "Some Client",
                IsApproved = true,
                Attachments = new[]
                    {
                        new AttachmentData { FileName = "1.txt" },
                        new AttachmentData { FileName = "2.txt" },
                        new AttachmentData { FileName = "3.txt" },
                        new AttachmentData { FileName = "4.txt" }
                    },
                Accepts = new[]
                    {
                        new AcceptPriceData { Portfolio = "Portfolio 1", Publish = "All" },
                        new AcceptPriceData { Portfolio = "Portfolio 2", Publishing = new []
                            {
                                new PublishAttachmentData { FileName = "1.txt" },
                                new PublishAttachmentData { FileName = "3.txt" }
                            }}
                    }
            };
            var result = price.GetAcceptPricesInfo();
            Assert.AreEqual(2, result.Prices.Count);
            Assert.AreEqual("Some Client", result.Prices[0].ClientName);
            Assert.AreEqual("Portfolio 1", result.Prices[0].PortfolioName);
            CollectionAssert.AreEqual(new List<string> { "1.txt", "2.txt", "3.txt", "4.txt" }, result.Prices[0].AttachmentNames);

            Assert.AreEqual("Some Client", result.Prices[1].ClientName);
            Assert.AreEqual("Portfolio 2", result.Prices[1].PortfolioName);
            CollectionAssert.AreEqual(new List<string> { "1.txt", "3.txt" }, result.Prices[1].AttachmentNames);
        }

        [Test]
        public void GetAcceptPricingInfoTest_AllPortfoliosClientAlreadyDefined()
        {
            var price = new SecurityPricingData()
            {
                OrganizationName = "Some Client",
                IsApproved = true,
                Accepts = new[]
                    {
                        new AcceptPriceData { Client = "Some Another Client", Portfolio = "Portfolio 1" }
                    }
            };
            var result = price.GetAcceptPricesInfo();
            Assert.AreEqual(1, result.Prices.Count);
            Assert.AreEqual("Some Client", result.Prices[0].ClientName);
            Assert.AreEqual("Portfolio 1", result.Prices[0].PortfolioName);
            Assert.IsEmpty(result.Prices[0].AttachmentNames);
            Assert.Contains(Messages.ACCEPT_PRICE_CLIENT_ALREADY_DEFINED, result.Warnings);
        }

        [Test]
        public void GetAcceptPricingInfoTest_AllPortfoliosWrongAttachmentNames()
        {
            var price = new SecurityPricingData()
            {
                OrganizationName = "Some Client",
                IsApproved = true,
                Attachments = new[]
                    {
                        new AttachmentData { FileName = "1.txt" },
                        new AttachmentData { FileName = "2.txt" },
                        new AttachmentData { FileName = "3.txt" },
                        new AttachmentData { FileName = "4.txt" }
                    },
                Accepts = new[]
                    {
                        new AcceptPriceData { Portfolio = "Portfolio 1", Publishing = new []
                            {
                                new PublishAttachmentData { FileName = "1.txt" },
                                new PublishAttachmentData { FileName = "12.txt" },
                                new PublishAttachmentData { FileName = "3.txt" },
                                new PublishAttachmentData { FileName = "5.txt" }
                            }
                        }
                    }
            };
            var result = price.GetAcceptPricesInfo();
            Assert.AreEqual(1, result.Prices.Count);
            Assert.AreEqual("Some Client", result.Prices[0].ClientName);
            Assert.AreEqual("Portfolio 1", result.Prices[0].PortfolioName);
            CollectionAssert.AreEqual(new List<string> { "1.txt", "3.txt" }, result.Prices[0].AttachmentNames);
            Assert.Contains(Messages.ACCEPT_PRICE_WRONG_ATTACHMENT_NAMES, result.Warnings);
        }

        #endregion

        #region All Clients, All Portfolios

        [Test]
        public void GetAcceptPricingInfoTest_AllClientsNoClientDefined()
        {
            var price = new SecurityPricingData
            {
                IsApproved = true,
                Accepts = new[]
                        {
                            new AcceptPriceData { Portfolio = "Portfolio 1" }
                        }
            };
            var result = price.GetAcceptPricesInfo();
            Assert.IsEmpty(result.Prices);
            Assert.Contains(Messages.ACCEPT_PRICE_NO_CLIENT_IN_ACCEPT, result.Warnings);
        }

        [Test]
        public void GetAcceptPricingInfoTest_AllClientsManyAttachments()
        {
            var price = new SecurityPricingData()
            {
                IsApproved = true,
                Attachments = new[]
                    {
                        new AttachmentData { FileName = "1.txt" },
                        new AttachmentData { FileName = "2.txt" },
                        new AttachmentData { FileName = "3.txt" },
                        new AttachmentData { FileName = "4.txt" }
                    },
                Accepts = new[]
                    {
                        new AcceptPriceData { Client = "Some Client 1", Portfolio = "Portfolio 1", Publish = "All" },
                        new AcceptPriceData { Client = "Some Client 2", Portfolio = "Portfolio 2", Publishing = new []
                            {
                                new PublishAttachmentData { FileName = "1.txt" },
                                new PublishAttachmentData { FileName = "3.txt" }
                            }}
                    }
            };
            var result = price.GetAcceptPricesInfo();
            Assert.AreEqual(2, result.Prices.Count);
            Assert.AreEqual("Some Client 1", result.Prices[0].ClientName);
            Assert.AreEqual("Portfolio 1", result.Prices[0].PortfolioName);
            CollectionAssert.AreEqual(new List<string> { "1.txt", "2.txt", "3.txt", "4.txt" }, result.Prices[0].AttachmentNames);

            Assert.AreEqual("Some Client 2", result.Prices[1].ClientName);
            Assert.AreEqual("Portfolio 2", result.Prices[1].PortfolioName);
            CollectionAssert.AreEqual(new List<string> { "1.txt", "3.txt" }, result.Prices[1].AttachmentNames);
        }

        #endregion

        #endregion

        #region GetAllAttachmentNames Tests

        [Test]
        public void GetAllAttachmentNames_Default()
        {
            var price = new SecurityPricingData();
            CollectionAssert.AreEqual(new List<string> { Constants.ATTACHMENT_CP_NAME_DEFAULT }, price.GetAllAttachmentNames());
        }

        [Test]
        public void GetAllAttachmentNames_DefinedAttachments()
        {
            var price = new SecurityPricingData
                {
                    Attachments = new[]
                        {
                            new AttachmentData {FileName = "1.txt"},
                            new AttachmentData {FileName = "2.txt", IsPublished = false},
                            new AttachmentData {FileName = "3.txt"}
                        }
                };
            CollectionAssert.AreEqual(new List<string>{"1.txt","2.txt","3.txt"}, price.GetAllAttachmentNames());
        }

        #endregion
    }
}
