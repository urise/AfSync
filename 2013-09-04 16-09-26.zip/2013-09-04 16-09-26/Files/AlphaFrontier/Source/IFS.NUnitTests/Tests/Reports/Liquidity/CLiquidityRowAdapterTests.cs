﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IFS.BusinessLayer;
using IFS.BusinessLayer.FundProperty.Fund;
using IFS.BusinessLayer.Reports;
using IFS.BusinessLayer.Reports.Liquidity;
using IFS.Interfaces.Rounding;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Reports.Liquidity
{
    [TestFixture]
    public class CLiquidityRowAdapterTests
    {
        [Test]
        public void TestWhen3LiquidityRowsPassedGet3Back()
        {
            //Given
            var liquidityRows = new LiquidityRows();
            liquidityRows.AddNewRow(new RedemptionEventRow{ MarketValue = CAmount.Zero()});
            liquidityRows.AddNewRow(new RedemptionEventRow { MarketValue = CAmount.Zero() });
            liquidityRows.AddNewRow(new RedemptionEventRow { MarketValue = CAmount.Zero() });
            var sourceRow = new CLiquidityReportRow();
            //When
            var adapter = new CLiquidityReportRowAdapter(sourceRow, liquidityRows);
            var rows = adapter.GetRows();

            //then
            Assert.AreEqual(3,rows.Count);
        }

        [Test]
        public void TestSourceRowPassedValueCopiedInNewRows()
        {
            //Given
            var liquidityRows = new LiquidityRows();
            liquidityRows.AddNewRow(new RedemptionEventRow{MarketValue = CAmount.Zero()});
            var sourceRow = new CLiquidityReportRow
                            {
                                RedemptiononAfterLockUpExpire = true,
                                FundID = 1,
                                FundName = "TEST",
                                IsFundSidePocket = true,
                                Currency = "USD",
                                ExecutionDate = new DateTime(2013,1,31),
                                TradeDate = new DateTime(2013, 2, 2),
                                RedemptionMethodString = "lockupterm",
                                AsOf = new DateTime(2013, 6, 2),
                                NoticeDays = 10,
                                RedmeptionNoticeMethodString = "redemptionNoticeMethodString",
                                AllocationsCount = 5,
                                Gate = "Y" ,
                                RedemptionPolicyType = "Standard",
                                MarketValue = CAmount.Zero()
                            };
            
            //When
            var adapter = new CLiquidityReportRowAdapter(sourceRow,liquidityRows);
            var rows = adapter.GetRows();
            var row = rows[0];

            //then
            Assert.AreEqual(1,rows.Count);
            Assert.IsTrue(row.RedemptiononAfterLockUpExpire);
            Assert.AreEqual(sourceRow.FundID, row.FundID);
            Assert.AreEqual(sourceRow.FundName, row.FundName);
            Assert.IsTrue(row.IsFundSidePocket);
            Assert.AreEqual(sourceRow.Currency, row.Currency);
            Assert.AreEqual(sourceRow.ExecutionDate, row.ExecutionDate);
            Assert.AreEqual(sourceRow.TradeDate, row.TradeDate);
            Assert.AreEqual(sourceRow.RedemptionMethodString, row.RedemptionMethodString);
            Assert.AreEqual(sourceRow.AsOf, row.AsOf);
            Assert.AreEqual(sourceRow.NoticeDays, row.NoticeDays);
            Assert.AreEqual(sourceRow.RedmeptionNoticeMethodString, row.RedmeptionNoticeMethodString);
            Assert.AreEqual(sourceRow.AllocationsCount, row.AllocationsCount);
            Assert.AreEqual(sourceRow.Gate, row.Gate);
            Assert.AreEqual(sourceRow.RedemptionPolicyType, row.RedemptionPolicyType);
        }

        [Test]
        public void TestLiquidityRowsValueCopiedInNewRows()
        {
            //Given
            var liquidityRows = new LiquidityRows();
            liquidityRows.AddNewRow(new RedemptionEventRow
                                        {
                                            DeltaLocal = new CAmount(100),
                                            MarketValue = new CAmount(100),
                                            RedeemDate = new DateTime(2013,02,01)
                                        });
            var sourceRow = new CLiquidityReportRow();
            //When
            var adapter = new CLiquidityReportRowAdapter(sourceRow, liquidityRows);
            var rows = adapter.GetRows();
            var row = rows[0];
            //then
            Assert.AreEqual(new CAmount(100).Value, row.DeltaLocal.Value);
            Assert.AreEqual(new CAmount(100).Value, row.MarketValue.Value);
            Assert.AreEqual(new DateTime(2013, 02, 01), row.NextEligibleRedemDate);
        }

        [Test]
        public void TestPopulateNoticeDateAndDays()
        {
            //Given
            var liquidityRows = new LiquidityRows();
           
            var row = new CLiquidityReportRow { NextEligibleRedemDate = new DateTime(2013, 10, 31)};
            var schedule = "Business";
            var selectedDate = new DateTime(2013, 09, 30);
            var noticedays = 10;
            //When
            var adapter = new CLiquidityReportRowAdapter(row, liquidityRows);
            adapter.PopulateNoticeDateAndDays(row, schedule, selectedDate, noticedays);

            //then
            Assert.AreEqual(new DateTime(2013,10,17), row.DateToGiveNotice);
            Assert.AreEqual(17, row.DaysToGiveNotice);
            Assert.AreEqual(14, row.NoticeDaysCalendar);
        }

        [Test]
        public void TestScheduleParameterPassedGetCorrectNoticeDays()
        {
            //Given
            var liquidityRows = new LiquidityRows();
            liquidityRows.AddNewRow(new RedemptionEventRow
            { RedeemDate = new DateTime(2013, 10,31) , MarketValue = CAmount.Zero()});
            var srow = new CLiquidityReportRow {  NoticeDays = 10, AsOf = new DateTime(2013,09, 30) };
            var parames = new CLiquidityReportRowAdapterParams
                              {NoticePeriodSchedule = "Business"};
            
            //When
            var adapter = new CLiquidityReportRowAdapter(srow, liquidityRows, parames);
            var rows = adapter.GetRows();
            var row = rows[0];

            //then
            Assert.AreEqual(new DateTime(2013, 10, 17), row.DateToGiveNotice);
            Assert.AreEqual(17, row.DaysToGiveNotice);
            Assert.AreEqual(14, row.NoticeDaysCalendar);
        }

        [Test]
        public void TestApplyFeeOnlyGeneralRedFeePercentage()
        {
            //Given
            var srow = new CLiquidityReportRow { MarketValue = new CAmount(1000) };
            var genRedFee = new CDollarPercentTabNumber{ DollarOrPercent = "%", Number = 10};

            //when
            var adapter = new CLiquidityReportRowAdapter(srow, null);
            adapter.ApplyFees(srow, genRedFee,null);
            //Then
            Assert.AreEqual(900, srow.MarketValueAfterRedeemFee.Value);
        }


        [Test]
        public void TestApplyFeeOnlyGeneralRedFeeAmount()
        {
            //Given
            var srow = new CLiquidityReportRow { MarketValue = new CAmount(1000) };
            var genRedFee = new CDollarPercentTabNumber { Number = 10 };

            //when
            var adapter = new CLiquidityReportRowAdapter(srow, null);
            adapter.ApplyFees(srow, genRedFee,null);
            //Then
            Assert.AreEqual(990, srow.MarketValueAfterRedeemFee.Value);
        }

        [Test]
        public void TestApplyFeesWithLockupPercentage()
        {
            //Given
            var srow = new CLiquidityReportRow { MarketValue = new CAmount(1000), NextEligibleRedemDate = new DateTime(2013, 01, 01) };
            var genRedFee = new CDollarPercentTabNumber { Number = 10 };
            var lockups = new List<Lockup>
                              {
                                  new Lockup
                                      {
                                          LockupType = "Soft",
                                          Fee = new CDollarPercentTabNumber { DollarOrPercent = "%", Number = 10},
                                          Years = 1,
                                          Months = 0
                                      }
                              };

            var lockupCalculator = new LockupCalculator(lockups, new DateTime(2013, 01, 01), "Calendar");
            //when
            var adapter = new CLiquidityReportRowAdapter(srow, null);
            adapter.ApplyFees(srow, genRedFee, lockupCalculator);
            //Then
            Assert.AreEqual(890, srow.MarketValueAfterRedeemFee.Value);
        }

        [Test]
        public void TestApplyFeesWithLockupAmount()
        {
            //Given
            var srow = new CLiquidityReportRow { MarketValue = new CAmount(1000), NextEligibleRedemDate = new DateTime(2013, 01, 01) };
            var genRedFee = new CDollarPercentTabNumber { Number = 10 };
            var lockups = new List<Lockup>
                              {
                                  new Lockup
                                      {
                                          LockupType = "Soft",
                                          Fee = new CDollarPercentTabNumber { Number = 10},
                                          Years = 1,
                                          Months = 0
                                      }
                              };

            var lockupCalculator = new LockupCalculator(lockups, new DateTime(2013, 01, 01), "Calendar");
            //when
            var adapter = new CLiquidityReportRowAdapter(srow, null);
            adapter.ApplyFees(srow, genRedFee, lockupCalculator);
            //Then
            Assert.AreEqual(980, srow.MarketValueAfterRedeemFee.Value);
        }

        [Test]
        public void TestApplyFeesWithLockupExpired()
        {
            //Given
            var srow = new CLiquidityReportRow { MarketValue = new CAmount(1000), NextEligibleRedemDate = new DateTime(2014, 01, 01) };
            var genRedFee = new CDollarPercentTabNumber { Number = 10 };
            var lockups = new List<Lockup>
                              {
                                  new Lockup
                                      {
                                          LockupType = "Soft",
                                          Fee = new CDollarPercentTabNumber { Number = 10},
                                          Years = 1,
                                          Months = 0
                                      }
                              };

            var lockupCalculator = new LockupCalculator(lockups, new DateTime(2013, 01, 01), "Calendar");
            //when
            var adapter = new CLiquidityReportRowAdapter(srow, null);
            adapter.ApplyFees(srow, genRedFee, lockupCalculator);
            //Then
            Assert.AreEqual(990, srow.MarketValueAfterRedeemFee.Value);
        }
    }
}
