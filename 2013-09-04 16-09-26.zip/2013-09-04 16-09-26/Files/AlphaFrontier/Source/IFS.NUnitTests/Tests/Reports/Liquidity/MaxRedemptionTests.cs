﻿using System;
using IFS.BusinessLayer.Reports.Liquidity;
using IFS.Interfaces.Rounding;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.Reports.Liquidity
{
    [TestFixture]
    public class MaxRedemptionTests
    {
        [Test]
        public void TestWhenNoMaxRedemptionSpecifiedThereIsOneLiquidityEvent()
        {
            //given
            MaxRedemptionTerms terms = new MaxRedemptionNoneTerms();
            var mr = new MaxRedemption(terms);
            var state = new LotInitialState { MarketValue = new CAmount(1000), Date = DateTime.Now};
            //when
            LiquidityRows rows = mr.GetLiquidityRows(state);
            //then
            Assert.AreEqual(1, rows.GetCount());
        }

        [Test]
        public void TestWhenNoMaxRedemptionSpecifiedGet100PercentRedemption()
        {
            //given
            MaxRedemptionTerms terms = new MaxRedemptionNoneTerms();
            var mr = new MaxRedemption(terms);
            var state = new LotInitialState {DeltaLocal = new CAmount(100),  MarketValue = new CAmount(100), Date = DateTime.Now };
            //when
            LiquidityRows rows = mr.GetLiquidityRows(state);
            RedemptionEventRow row = rows.GetRow(0);
            //then
            Assert.AreEqual(100,row.DeltaLocal.Value);
            Assert.AreEqual(100, row.MarketValue.Value);
        }

        [Test]
        public void TestWhen50PercentMaxRedemptionSpecifiedGet50PercentRedemptionTwoTimesWithEqualPaymentAmount()
        {
            //given
            var terms = new MaxRedemptionTermsAsPercent { MaxRedeemingPercent = 50 };
            var mr = new MaxRedemption(terms);
            var state = new LotInitialState { DeltaLocal = new CAmount(100), MarketValue = new CAmount(100), Date = DateTime.Now };
            //when
            LiquidityRows rows = mr.GetLiquidityRows(state);
            RedemptionEventRow row1 = rows.GetRow(0);
            RedemptionEventRow row2 = rows.GetRow(1);
            //then
            Assert.AreEqual(50, row1.DeltaLocal.Value);
            Assert.AreEqual(50, row2.DeltaLocal.Value);
            Assert.AreEqual(50, row1.MarketValue.Value);
            Assert.AreEqual(50, row2.MarketValue.Value);
        }

        [Test]
        public void TestWhen33PercentMaxRedemptionSpecifiedGet33PercentRedemption3TimesAnd1PercentRedemption1Time()
        {
            //given
            var terms = new MaxRedemptionTermsAsPercent { MaxRedeemingPercent = 33 };
            var mr = new MaxRedemption(terms);
            var state = new LotInitialState { DeltaLocal = new CAmount(100), MarketValue = new CAmount(100), Date = DateTime.Now };
            //when
            LiquidityRows rows = mr.GetLiquidityRows(state);
            Assert.AreEqual(4, rows.GetCount());
            RedemptionEventRow row1 = rows.GetRow(0);
            RedemptionEventRow row2 = rows.GetRow(1);
            RedemptionEventRow row3 = rows.GetRow(2);
            RedemptionEventRow row4 = rows.GetRow(3);
            //then
            Assert.AreEqual(33, row1.DeltaLocal.Value);
            Assert.AreEqual(33, row2.DeltaLocal.Value);
            Assert.AreEqual(33, row3.DeltaLocal.Value);
            Assert.AreEqual(1, row4.DeltaLocal.Value);
            Assert.AreEqual(33, row1.MarketValue.Value);
            Assert.AreEqual(33, row2.MarketValue.Value);
            Assert.AreEqual(33, row3.MarketValue.Value);
            Assert.AreEqual(1, row4.MarketValue.Value);
        }
    }
}
