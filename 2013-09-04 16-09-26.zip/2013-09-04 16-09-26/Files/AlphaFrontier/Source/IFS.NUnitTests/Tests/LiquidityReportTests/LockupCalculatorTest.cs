﻿using System;
using System.Collections.Generic;
using IFS.BusinessLayer.FundProperty.Fund;
using IFS.BusinessLayer.Reports.Liquidity;
using NUnit.Framework;

namespace IFS.NUnitTests.Tests.LiquidityReportTests
{
    [TestFixture]
    public class LockupCalculatorTest
    {
        private List<Lockup> _lockups;

        [SetUp]
        public void SetupData()
        {
            _lockups = new List<Lockup>();
            var lockup = new Lockup
            {
                LockupType = "Hard",
                Fee = new IFS.BusinessLayer.CDollarPercentTabNumber(),
                Years = 1,
                Months = 0
            };
            _lockups.Add(lockup);

            lockup = new Lockup
            {
                LockupType = "Soft",
                Fee = new IFS.BusinessLayer.CDollarPercentTabNumber(),
                Years = 1,
                Months = 0
            };
            lockup.Fee.DollarOrPercent = "%";
            lockup.Fee.Number = 2;
            _lockups.Add(lockup);

            lockup = new Lockup
            {
                LockupType = "Rolling",
                Fee = new IFS.BusinessLayer.CDollarPercentTabNumber(),
                Years = 1,
                Months = 0
            };
            lockup.Fee.DollarOrPercent = "%";
            lockup.Fee.Number = 1;
            _lockups.Add(lockup);
        }

        [Test]
        public void TestCalendarSchedule()
        {
            var lockupCalculator = new LockupCalculator(_lockups, new DateTime(2010, 01, 01), "Calendar");
            lockupCalculator.MoveFirst();
            var lookupInfo = ((LockupInfo)lockupCalculator.Current);

            Assert.IsTrue(new DateTime(2010, 12, 31).Equals(lookupInfo.CorrectedLockupExpiryDate));

            lockupCalculator.MoveNext();
            Assert.IsTrue(new DateTime(2011, 12, 31).Equals(lookupInfo.CorrectedLockupExpiryDate));

        }

        [Test]
        public void TestGetActiveLockup()
        {
            //Given
            var lockupCalculator = new LockupCalculator(_lockups, new DateTime(2010, 01, 01), "Calendar");
            var firstDate = new DateTime(2010, 06, 30);
            var secondDate = new DateTime(2011, 06, 30);
            var thirdDate = new DateTime(2012, 06, 30);
            //when
            var firstLockup = lockupCalculator.GetActiveLockup(firstDate);
            var secondLockup = lockupCalculator.GetActiveLockup(secondDate);
            var thirdLockup = lockupCalculator.GetActiveLockup(thirdDate);
            
            //Then
            Assert.AreEqual("Hard", firstLockup.LockupDetails.LockupType);
            Assert.AreEqual(new DateTime (2010,12,31), firstLockup.LockupExpiryDate);
            Assert.AreEqual(new DateTime(2010, 12, 31), firstLockup.CorrectedLockupExpiryDate);

            Assert.AreEqual("Soft", secondLockup.LockupDetails.LockupType);
            Assert.AreEqual(new DateTime(2011, 12, 30), secondLockup.LockupExpiryDate);
            Assert.AreEqual(new DateTime(2011, 12, 30), secondLockup.CorrectedLockupExpiryDate);

            Assert.AreEqual("Rolling", thirdLockup.LockupDetails.LockupType);
            Assert.AreEqual(new DateTime(2012, 12, 29), thirdLockup.LockupExpiryDate);
            Assert.AreEqual(new DateTime(2012, 12, 29), thirdLockup.CorrectedLockupExpiryDate);


        }

        [Test]
        public void TestBusinessSchedule()
        {
            var lockupCalculator = new LockupCalculator(_lockups, new DateTime(2010, 01, 01), "Business");
            lockupCalculator.MoveFirst();
            var lookupInfo = ((LockupInfo)lockupCalculator.Current);

            Assert.IsTrue(new DateTime(2010, 12, 31).Equals(lookupInfo.CorrectedLockupExpiryDate));

            lockupCalculator.MoveNext();
            Assert.IsTrue(new DateTime(2011, 12, 30).Equals(lookupInfo.CorrectedLockupExpiryDate));

        }

        [Test]
        public void TestForInfiniteLoop()
        {
            var lockups = new List<Lockup>();
            var lockup = new Lockup
            {
                LockupType = "Soft",
                Fee = new IFS.BusinessLayer.CDollarPercentTabNumber(),
            };
            lockups.Add(lockup);
            var lockupCalculator = new LockupCalculator(lockups,
                                                        new DateTime(2010, 01, 01),
                                                        "Calendar");
            Assert.False(lockupCalculator.MoveFirst());
            Assert.False(lockupCalculator.MoveNext());
            Assert.False(lockupCalculator.MoveLast());
        }
    }
}
