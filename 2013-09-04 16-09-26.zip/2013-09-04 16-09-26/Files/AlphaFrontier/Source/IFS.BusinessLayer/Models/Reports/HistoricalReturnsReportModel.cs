﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IFS.Interfaces.CloudContracts.DataContracts;

namespace IFS.BusinessLayer.Models.Reports
{
    public class HistoricalReturnsReportModel
    {
        //public DropDownListModel Portfolios { get; set; }
        public List<string> NavDatesList { get; set; }
    }


}
