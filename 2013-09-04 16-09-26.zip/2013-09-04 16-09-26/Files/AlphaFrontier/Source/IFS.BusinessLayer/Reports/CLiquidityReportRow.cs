using System;
using System.Collections.Generic;
using IFS.Interfaces.CloudContracts.DataContracts.Reports.Liquidity;
using IFS.Interfaces.Rounding;

namespace IFS.BusinessLayer.Reports
{
    public class CLiquidityReportData
    {
        public List<CLiquidityReportRow> ReportRows { get; set; }
        public List<MsChartGraphRow> Graph1 { get; set; }
        public List<MsChartGraphRow> Graph2 { get; set; }

        public CLiquidityReportData()
        {
            ReportRows = new List<CLiquidityReportRow>();
            Graph1 = new List<MsChartGraphRow>();
            Graph2 = new List<MsChartGraphRow>();
        }
    }

    public class RedemptionPaymentData
    {
        public double PmtPct { get; set; }
        public DateTime PmtDate { get; set; }
        public double PmtDays { get; set; }
        public CAmount PmtAmount { get; set; }
        public CAmount PmtAmountAfterRedeemFee { get; set; }
        public CAmount HardLockupPmtAmount { get; set; }
        public DateTime HardLockupPmtDate { get; set; }
        public string PmtPctString 
        {
            get { return PmtPct == 0 ? string.Empty : Property.FormatPercentage(PmtPct/100, true); }
        }
        public string PmtDateString
        {
            get { return PmtDate != DateTime.MinValue ? PmtDate.ToShortDateString() : string.Empty; }
        }
        public RedemptionPaymentData(double pmtPct, double pmtDays, DateTime pmtDate)
        {
            PmtPct = pmtPct;
            PmtDays = pmtDays;
            PmtDate = pmtDate;
        }
        public RedemptionPaymentData(double pmtPct, double pmtDays)
        {
            PmtPct = pmtPct;
            PmtDays = pmtDays;
        }

        public RedemptionPaymentData(double pmtPct,double pmtDays,DateTime pmtDate,DateTime hardLockupPmtDate)
        {
            PmtPct = pmtPct;
            PmtDays = pmtDays;
            PmtDate = pmtDate;
            HardLockupPmtDate = hardLockupPmtDate;
        }
    }
    
    public class CLiquidityReportRow
    {
        #region Members
        private double _redeemFeeSofLockups = double.NaN;
        private double _redeemFeeGeneral = double.NaN;
        //_redeemFeeAccelerated is calculated the same way as _redeemFeeSofLockups but foe Accelerated Red. Policy
        private double _redeemFeeAccelerated = double.NaN;
        // Only "Standard", "Accelerated" and "Hybrid" value should be allowed
        private string _redemptionPolicyType = "Standard";
        private List<RedemptionPaymentData> _redemptionPaymentList;
        #endregion
        # region properties
        public bool IsPerfect { get; set; }
        public bool RedemptiononAfterLockUpExpire { get; set; }
        public int LockUpTerm { get; set; }
        public int FundID { get; set; }
        public string FundName { get; set; }
        public bool IsFundSidePocket { get; set; }
        public string Currency { get; set; }
        public CAmount DeltaLocal { get; set; }
        public DateTime ExecutionDate { get; set; }
        public DateTime TradeDate { get; set; }
        public DateTime FirstSubscriptionExecutionDate { get; set; }
        public CAmount MarketValue { get; set; }
        public CAmount MarketValueAfterRedeemFee { get; set; }
        public DateTime AsOf { get; set; }
        public string LockUpExpired { get; set; }
        public string LockUpExpiredType { get; set; }
        public DateTime LockUpExpirationDate { get; set; }

        public BaseFund BaseFund { get; set; }
        public double RedeemFeeSoftLockups
        {
            get { return _redeemFeeSofLockups; }
            set { _redeemFeeSofLockups = value; }
        }
        public double RedeemFeeGeneral
        {
            get { return _redeemFeeGeneral; }
            set { _redeemFeeGeneral = value; }
        }
        public double RedeemFeeAccelerated
        {
            get { return _redeemFeeAccelerated; }
            set { _redeemFeeAccelerated = value; }
        }
        public double RedeemFee
        {
            get
            {
                if (_redemptionPolicyType == "Standard")
                    return _redeemFeeSofLockups + _redeemFeeGeneral;
                if (_redemptionPolicyType == "Accelerated")
                    return _redeemFeeAccelerated + _redeemFeeGeneral;
                if (_redemptionPolicyType == "Hybrid")
                {
                    throw new InvalidOperationException("Total Redemption Fee cannot be calculated for hybrid redemption policy.");
                }
                throw new InvalidOperationException("Unknown redemption policy type.");
            }
        }
        //Redeem. Fee columns are always in percents
        //public bool RedeemFeeIsPct { get; set; }
        public string RedemptionPolicyType
        {
            get { return _redemptionPolicyType; }
            set
            {
                if (value == "Standard" | value == "Accelerated")
                    _redemptionPolicyType = value;
                else
                {
                    throw new ArgumentOutOfRangeException("RedemptionPolicyType");
                }
            }
        }
        public int DaysToLockUpExpiry { get; set; }
        public string LiquidityTerm { get; set; }
        public int NoticeDays { get; set; }
        public int NoticeDaysCalendar { get; set; }
        public DateTime NextEligibleRedemDate { get; set; }
        public DateTime DateToGiveNotice { get; set; }
        public int DaysToGiveNotice { get; set; }
        public List<RedemptionPaymentData> RedemptionPaymentList
        {
            get { return _redemptionPaymentList ?? (_redemptionPaymentList = new List<RedemptionPaymentData>()); }
            set { _redemptionPaymentList = value; }
        }
        public int AllocationsCount { get; set; }
        public bool IsCashProjectionReport { get; set; }
        public string Gate { get; set; }
        public DateTime HardLockupEligibleRedDate { get; set; }
        public CAmount HardLockupMvAfterRedFee { get; set; }
        # endregion

        #region View Columns
        public string NameString { get { return IsPerfect ? FundName : FundName + " *"; } }
        public string RedemptionMethodString { get; set; }
        public string MarketValueString { get { return CAmount.FormatValue(MarketValue); } }
        public string DeltaLocalString { get { return CAmount.FormatValue(DeltaLocal); } }
        public string ExecutionDateString { get { return ExecutionDate.ToShortDateString(); } }
        public string TradeDateString { get { return TradeDate.ToShortDateString(); } }
        public string LockUpExpirationDateString
        {
            get
            {
                return LockUpExpirationDate != DateTime.MinValue ? LockUpExpirationDate.ToString("MM/dd/yy") : string.Empty;
            }
        }
        public string AsOfString
        {
            get
            {
                return AsOf != DateTime.MinValue ? AsOf.ToString("MM/dd/yy") : string.Empty;
            }
        }
        public string ExpirationDateRedmptionString
        {
            get
            {
                return LockUpExpirationDate != DateTime.MinValue ? (RedemptiononAfterLockUpExpire ? "N" : "Y") : string.Empty;
            }
        }
       
        public string RedeemFeeSoftLockupsPercentString
        {
            get
            {
                return PaintString(RedeemFeeSoftLockups == -1 || double.IsNaN(RedeemFeeSoftLockups)
                                       ? string.Empty
                                       : Property.FormatPercentage(RedeemFeeSoftLockups/100),
                                   RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_ACCELERATED);
            }
        }

        public string RedeemFeeSoftLockupsCurrencyString
        {
            get
            {
                return PaintString(RedeemFeeSoftLockups == -1 || double.IsNaN(RedeemFeeSoftLockups)
                                       ? string.Empty
                                       : Property.FormatCurrency(RedeemFeeSoftLockups*MarketValue.Value/100, FundID).
                                             Replace(Currency, ""),
                                   RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_ACCELERATED);
            }
        }

        public string RedeemFeeGeneralPercentString
        {
            get
            {
                return RedeemFeeGeneral == -1 || double.IsNaN(RedeemFeeGeneral)
                           ? string.Empty
                           : Property.FormatPercentage(RedeemFeeGeneral/100);
            }
        }

        public string RedeemFeeGeneralCurrencyString
        {
            get
            {
                return RedeemFeeGeneral == -1 || double.IsNaN(RedeemFeeGeneral)
                           ? string.Empty
                           : Property.FormatCurrency(RedeemFeeGeneral * MarketValue.Value / 100, FundID).Replace(Currency,"");
            }
        }

        public string RedeemFeeAcceleratedPercentString
        {
            get
            {
                return PaintString(RedeemFeeAccelerated == -1 || double.IsNaN(RedeemFeeAccelerated)
                           ? string.Empty
                           : Property.FormatPercentage(RedeemFeeAccelerated/100), RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_STANDARD);
            }
        }

        public string RedeemFeeAcceleratedCurrencyString
        {
            get
            {
                return PaintString(
                    RedeemFeeAccelerated == -1 || double.IsNaN(RedeemFeeAccelerated)
                        ? string.Empty
                        : Property.FormatCurrency(RedeemFeeAccelerated*MarketValue.Value/100, FundID).Replace(Currency,
                                                                                                              ""),
                    RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_STANDARD);
            }
        }

        public string DaysToLockupExpirationString
        {
            get { return DaysToLockUpExpiry != -1 ? DaysToLockUpExpiry.ToString() : string.Empty; }
        }

        public string NoticeDaysString
        {
            get { return NoticeDays > 0 ? NoticeDays.ToString() : string.Empty; }
        }

        public string NextEligibleLiquidityAsOfString
        {
            get { return NextEligibleRedemDate != DateTime.MinValue ? NextEligibleRedemDate.ToString("MM/dd/yy") : string.Empty; }
        }

        public string DateToGiveNoticeString
        {
            get { return DateToGiveNotice != DateTime.MinValue ? DateToGiveNotice.ToString("MM/dd/yy") : string.Empty; }
        }

        public string DaysToGiveNoticeString
        {
            get { return DaysToGiveNotice == -1 ? string.Empty : DaysToGiveNotice.ToString(); }
        }
        public string RedmeptionNoticeMethodString { get;set; }
        #endregion

        #region Constructors
        public CLiquidityReportRow()
        {
        }
        public CLiquidityReportRow(CLiquidityReportRow row)
        {
            AsOf = row.AsOf;
            BaseFund = row.BaseFund;
            Currency = row.Currency;
            DateToGiveNotice = row.DateToGiveNotice;
            DaysToGiveNotice = row.DaysToGiveNotice;
            DaysToLockUpExpiry = row.DaysToLockUpExpiry;
            DeltaLocal = row.DeltaLocal;
            ExecutionDate = row.ExecutionDate;
            TradeDate = row.TradeDate;
            RedemptionPaymentList = row.RedemptionPaymentList;
            FirstSubscriptionExecutionDate = row.FirstSubscriptionExecutionDate;
            FundID = row.FundID;
            FundName = row.FundName;
            IsPerfect = row.IsPerfect;
            LiquidityTerm = row.LiquidityTerm;
            LockUpExpirationDate = row.LockUpExpirationDate;
            LockUpExpired = row.LockUpExpired;
            LockUpExpiredType = row.LockUpExpiredType;
            MarketValue = row.MarketValue;
            MarketValueAfterRedeemFee = row.MarketValueAfterRedeemFee;
            NextEligibleRedemDate = row.NextEligibleRedemDate;
            NoticeDays = row.NoticeDays;
            NoticeDaysCalendar = row.NoticeDaysCalendar;
            RedeemFeeSoftLockups = row.RedeemFeeSoftLockups;
            RedeemFeeGeneral = row.RedeemFeeGeneral;
            RedeemFeeAccelerated = row.RedeemFeeAccelerated;
            RedemptionPolicyType = row.RedemptionPolicyType;
            RedemptiononAfterLockUpExpire = row.RedemptiononAfterLockUpExpire;
            AllocationsCount = row.AllocationsCount;
            RedmeptionNoticeMethodString = row.RedmeptionNoticeMethodString;
            RedemptionMethodString = row.RedemptionMethodString;
            Gate = row.Gate;
            IsFundSidePocket = row.IsFundSidePocket;
            HardLockupEligibleRedDate = row.HardLockupEligibleRedDate;
        }

        

        #endregion

        #region Methods


        private string PaintString(string stringToBePainted, bool condition)
        {
            if (condition)
            {
                return "<font color=gray>" + stringToBePainted + "</font>";
            }
            else
                return stringToBePainted;

        }
        #endregion
    }
}