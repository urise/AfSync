﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IFS.BusinessLayer.Utilities;
using IFS.Interfaces.Rounding;

namespace IFS.BusinessLayer.Reports.Liquidity
{
    public class CLiquidityReportRowAdapter
    {
        private readonly LiquidityRows _liquidityRows;
        private readonly CLiquidityReportRow _sourceRow;
        private readonly CLiquidityReportRowAdapterParams _params;

        #region Constructors
        public CLiquidityReportRowAdapter(CLiquidityReportRow sourceRow, 
                                            LiquidityRows liquidityRows, 
                                CLiquidityReportRowAdapterParams parameters = null)
        {
            _liquidityRows = liquidityRows;
            _sourceRow = sourceRow;
            _params = parameters?? new CLiquidityReportRowAdapterParams();
        }

        #endregion


        #region Methods

        public List<CLiquidityReportRow> GetRows()
        {
            var cLiquidityReportRows = new List<CLiquidityReportRow>();

            foreach (var lqRow in _liquidityRows)
            {
                var clqRow = new CLiquidityReportRow(_sourceRow);
                clqRow.DeltaLocal = lqRow.DeltaLocal;
                clqRow.MarketValue = lqRow.MarketValue;
                clqRow.NextEligibleRedemDate = lqRow.RedeemDate;
                PopulateNoticeDateAndDays(clqRow,_params.NoticePeriodSchedule,clqRow.AsOf, clqRow.NoticeDays);
                ApplyFees(clqRow, _params.GeneralRedemptionFee,_params.LockupCalculator);
                cLiquidityReportRows.Add(clqRow);
            }
            return cLiquidityReportRows;
        }

        public void PopulateNoticeDateAndDays(CLiquidityReportRow row, string schedule, DateTime selectedDate, int noticeDays)
        {
            var noticeDate = DateTime.MinValue;
            if (row.NextEligibleRedemDate != DateTime.MinValue)
            {
                noticeDate = schedule == "Business" ? DateUtil.AddBusinessDays(row.NextEligibleRedemDate, -noticeDays)
                    : row.NextEligibleRedemDate.AddDays(-noticeDays);
            }
            row.DateToGiveNotice = noticeDate;
            row.DaysToGiveNotice = noticeDate == DateTime.MinValue ? -1 : noticeDate.Subtract(selectedDate).Days;
            row.NoticeDaysCalendar = row.NextEligibleRedemDate.Subtract(noticeDate).Days;
        }
        
        public void ApplyFees(CLiquidityReportRow row, CDollarPercentTabNumber genRedFee,
                            LockupCalculator lockupCalculator)
        {
            double totalFeePct = NormalizeToPercent(genRedFee, row.MarketValue);
            totalFeePct = double.IsNaN(totalFeePct) ? 0 : totalFeePct;

            if (lockupCalculator != null)
            {
                var activeLockup = lockupCalculator.GetActiveLockup(row.NextEligibleRedemDate);
                if (activeLockup != null)
                totalFeePct += NormalizeToPercent(activeLockup.LockupDetails.Fee, row.MarketValue);
            }
            row.MarketValueAfterRedeemFee = row.MarketValue - (row.MarketValue * totalFeePct / 100);
        }

        private static double NormalizeToPercent(CDollarPercentTabNumber fee, CAmount amount)
        {
            double pct = 0;
            if (fee != null && !double.IsNaN(fee.Number))
            {
                pct = fee.IsPercent ? fee.Number : (fee.Number / amount.Value) * 100;
            }
            return pct;
        }
        #endregion
    }

    public class CLiquidityReportRowAdapterParams
    {
        public string NoticePeriodSchedule { get; set; }
        public CDollarPercentTabNumber GeneralRedemptionFee { get; set; }
        public LockupCalculator LockupCalculator { get; set; }
    }
}
