﻿using System;
using IFS.Interfaces.Rounding;

namespace IFS.BusinessLayer.Reports.Liquidity
{
    public class RedemptionEventRow
    {
        public CAmount DeltaLocal { get; set; }
        public CAmount MarketValue { get; set; }
        public DateTime RedeemDate { get; set; }
    }
}
