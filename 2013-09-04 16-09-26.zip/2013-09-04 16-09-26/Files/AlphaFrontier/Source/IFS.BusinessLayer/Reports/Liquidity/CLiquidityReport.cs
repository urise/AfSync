﻿using System;
using System.Collections.Generic;
using System.Linq;
using IFS.BusinessLayer.FundProperty;
using IFS.BusinessLayer.FundProperty.Fund;
using IFS.BusinessLayer.FxRates;
using IFS.BusinessLayer.Launchpad.Liquidity;
using IFS.BusinessLayer.Utilities;
using IFS.Interfaces.Rounding;
using Spring.Expressions;

namespace IFS.BusinessLayer.Reports.Liquidity
{
    public class CLiquidityReport
    {
        #region methods
        //TODO: T.Zavorotnii (ALPHA-508) move method to CCashProjectionReportGenerator
        public CLiquidityReportData GenerateCashPaymentsForCashProjection(Portfolio portfolio, DateTime dateSelected)
        {
            var cLiquidityReportData = new CLiquidityReportData();

            //Generate Cash Payment dates based on Redemptions.
            var cRedPaymentRows = GenerateCashProjectionPmtsForReds(portfolio, dateSelected).ReportRows;
            cLiquidityReportData.ReportRows.AddRange(cRedPaymentRows);

            //Generate Cash Payment dates based on Subscriptions that have Qty remaining until the last Redemption
            var cSubPaymentRows = GenerateCashProjectionPmtsForSubs(portfolio, dateSelected).ReportRows;
            cLiquidityReportData.ReportRows.AddRange(cSubPaymentRows);

            return cLiquidityReportData;
        }

        private static bool IsInvestmentIsNotEligable(InvestableFund fund, Investment investment, DateTime dateSelected)
        {
            return fund is ContingentRedemption || fund is ShortSale || fund is Equalization || investment.AllocationQuantity(dateSelected) <= 0;
        }

        //TODO: T.Zavorotnii (ALPHA-508) move method to CCashProjectionReportGenerator
        private CLiquidityReportData GenerateCashProjectionPmtsForReds(Portfolio portfolio, DateTime dateSelected)
        {
            var cLiquidityReportData = new CLiquidityReportData();
            var ivc = portfolio.Investments;
            var organization = Organization.Loader.GetById(portfolio.OrganizationID);
            foreach (Investment investment in ivc)
            {
                var fund = investment.Fund;
                if (IsInvestmentIsNotEligable(fund, investment, dateSelected))
                    continue;

                var redPolicy = fund.InvestableFundPropeties.RedemptionPolicy;
                var lockupTerm = EnumValue.GetEnumValueName(redPolicy.RedemptionLockupTerm);
                bool isRedAfterLockup = redPolicy.RedemptionAfterLockupExpire;
                var liquidityTerm = redPolicy.Liquidity > 0 ? EnumValue.GetEnumValueName(redPolicy.Liquidity) : null;
                var liquidityAsOf = redPolicy.LiquidityAsOf > 0 ? EnumValue.GetEnumValueName(redPolicy.LiquidityAsOf) : null;
                var properties = fund.InvestableFundPropeties;
                var policy = properties.RedemptionPolicy;
                var paymentPolicy = properties.RedemptionPaymentPolicy;
                DateTime custFreqDate = redPolicy.RedemptionFrequencyDate;
                var canNotPopulateRow = !AreDefaultValuesPopulated(liquidityTerm, liquidityAsOf, lockupTerm,
                    paymentPolicy.FullPaymentScheduleList.Items,
                    policy.Lockups, policy.NoticePeriodFullDays);
                foreach (AllocationRedemption redemption in investment.Redemptions(DateTime.MaxValue))
                {
                    if (redemption.AllocationTypeId == AllocationType.SECURITIES_DELIVERED_OUT_EX)
                        continue; //No payments for Ex out

                    var redemptionAmount = -redemption.GetCAmountDeltaBase(organization);
                    var redemptionDate = redemption.ExecutionDate;

                    var newRow = new CLiquidityReportRow
                    {
                        IsCashProjectionReport = true,
                        FundID = fund.FundID,
                        NoticeDays = policy.NoticePeriodFullDays,
                        ExecutionDate = redemptionDate,
                        TradeDate = redemption.TradeDate,
                        FirstSubscriptionExecutionDate = CalcExecutionDate(investment.FirstAllocationSubscription),
                        RedemptiononAfterLockUpExpire = isRedAfterLockup,
                        MarketValue = redemptionAmount,
                        DeltaLocal = redemptionAmount   //In case of Redemptions .. MarketValue/DeltaLocal are the same for Payment generator engine
                    };

                    if (canNotPopulateRow)
                    {
                        newRow.IsPerfect = false;
                        cLiquidityReportData.ReportRows.Add(newRow);
                        continue;
                    }


                    DateTime lockUpPeriodStartDate = lockupTerm == EnumValue.LOCKUPTERM_INITIALINCEPTIONBASED ? newRow.FirstSubscriptionExecutionDate : newRow.ExecutionDate;
                    var lockupCalculator = new LockupCalculator(policy.Lockups, lockUpPeriodStartDate, policy.Schedule);

                    var liquidityCalc = new LiquidityDateCalculator(policy.Lockups, lockUpPeriodStartDate,
                        policy.Schedule, liquidityTerm, redemption.ExecutionDate, custFreqDate, liquidityAsOf, dateSelected, isRedAfterLockup);

                    var parameters = new LiquidityReportParameters(EnumValue.REDEMPTION_POLICY_STANDARD_TYPE_ID, EnumValue.REDEMPTION_FEE_FORMAT_PERCENT_ID) { AnalisysAsOfDate = dateSelected };
                    CalculateLockUpAnalysisColumns(organization, newRow, fund, lockupCalculator, investment, parameters);

                    newRow.LiquidityTerm = liquidityTerm;
                    newRow.NextEligibleRedemDate = redemptionDate;
                    CalculateRedemptionDatesColumns(newRow, fund, redemption.IsFullyReedemed);

                    //Generate MaxRedemptionsRows. For a real Redemption .. maxRedemption is always 100%
                    var cLiquidityMaxRedemptionRows = CalculateMaxRedemptionRows(newRow, new RedemptionPolicyProperties { Maxredemption = new CDollarPercentTabNumber() }, 
                        dateSelected, liquidityCalc, fund, null);

                    foreach (var row in cLiquidityMaxRedemptionRows)
                    {
                        double totalRedemptionPct = row.RedemptionPaymentList.Sum(payment => payment.PmtPct);
                        if (totalRedemptionPct.Equals(100) && row.RedemptionPaymentList[0].PmtDate != DateTime.MinValue)
                        {
                            CalculateRedemptionDatesColumns(row, fund, redemption.IsFullyReedemed);
                            CalculatePaymentAmounts(row);
                        }

                        cLiquidityReportData.ReportRows.Add(row);
                    }
                }
            }
            return cLiquidityReportData;
        }

        //TODO: T.Zavorotnii (ALPHA-508) move method to CCashProjectionReportGenerator
        private void ProcessCashProjectionRow(Organization organization, DateTime dateSelected, List<CLiquidityReportRow> cPerfectInvestments,
            CLiquidityReportData cLiquidityReportData, InvestableFund fund, Investment inv, CAmount mvLocal, DateTime executionDate, DateTime tradeDate,
            RedemptionPolicyProperties redemptionPolicy, RedemptionPaymentProperties paymentPolicy, string lockupTerm, string redemptionNoticeMethodString,
            string liquidityTerm, string liquidityAsOf, DateTime lockUpPeriodStartDate, DateTime lastRedemptionDate)
        {
            var newRow = new CLiquidityReportRow
            {
                IsCashProjectionReport = true,
                RedemptiononAfterLockUpExpire = redemptionPolicy.RedemptionAfterLockupExpire,
                FundID = fund.FundID,
                FundName = fund.FullNameInvestable,
                IsFundSidePocket = fund.IsSidePocket,
                Currency = fund.CurrencyId,
                DeltaLocal = mvLocal,
                ExecutionDate = executionDate,
                TradeDate = tradeDate,
                RedemptionMethodString = lockupTerm,
                MarketValue = Rate.Convert(mvLocal, organization, inv, dateSelected),
                AsOf = dateSelected,
                NoticeDays = redemptionPolicy.NoticePeriodFullDays,
                RedmeptionNoticeMethodString = redemptionNoticeMethodString,
                AllocationsCount = inv.Allocations.Count
            };

            if (!AreDefaultValuesPopulated(liquidityTerm, liquidityAsOf, lockupTerm, paymentPolicy.FullPaymentScheduleList.Items, redemptionPolicy.Lockups, newRow.NoticeDays))
            {
                newRow.IsPerfect = false;
                cLiquidityReportData.ReportRows.Add(newRow);
                return;
            }

            var lockupCalc = new LockupCalculator(redemptionPolicy.Lockups, lockUpPeriodStartDate, redemptionPolicy.Schedule);

            var liquidityCalc = new LiquidityDateCalculator(redemptionPolicy.Lockups, lockUpPeriodStartDate,
                                                            redemptionPolicy.Schedule, liquidityTerm,
                                                            newRow.ExecutionDate,
                                                            redemptionPolicy.RedemptionFrequencyDate, liquidityAsOf,
                                                            dateSelected, redemptionPolicy.RedemptionAfterLockupExpire);
            var parameters = new LiquidityReportParameters(EnumValue.REDEMPTION_POLICY_STANDARD_TYPE_ID, EnumValue.REDEMPTION_FEE_FORMAT_PERCENT_ID) { AnalisysAsOfDate = dateSelected };

            CalculateLockUpAnalysisColumns(organization, newRow, fund, lockupCalc, inv, parameters);

            newRow.LiquidityTerm = liquidityTerm;

            CalculateNextEligibleRedemption(newRow, lastRedemptionDate > dateSelected ? lastRedemptionDate : dateSelected, -1, liquidityCalc,
                                            redemptionPolicy.GeneralRedemptionFee, redemptionPolicy.NoticePeriodSchedule);

            newRow.DateToGiveNotice = newRow.NextEligibleRedemDate == DateTime.MinValue ?
                                            DateTime.MinValue : newRow.NextEligibleRedemDate.AddDays(-newRow.NoticeDays);

            newRow.DaysToGiveNotice = newRow.DateToGiveNotice == DateTime.MinValue
                                           ? -1 : newRow.DateToGiveNotice.Subtract(dateSelected).Days;

            CalculateRedemptionDatesColumns(newRow, fund, true);

            //get MaxRedemptionsRows here.
            var cLiquidityMaxRedemptionRows = CalculateMaxRedemptionRows(newRow, redemptionPolicy, dateSelected, liquidityCalc,
                fund, null);

            // Use the redemption RowsCollection to add to total Redemption Pct
            // If the TotalRedemptionPcts is 100, then it is a perfect investment, to use in graph generation
            foreach (var row in cLiquidityMaxRedemptionRows)
            {
                double totalRedemptionPct = row.RedemptionPaymentList.Sum(payment => payment.PmtPct);
                row.IsPerfect = totalRedemptionPct.Equals(100) && row.RedemptionPaymentList[0].PmtDate != DateTime.MinValue;
                if (row.IsPerfect)
                {
                    CalculateRedemptionDatesColumns(row, fund, true);
                    CalculatePaymentAmounts(row);
                    cPerfectInvestments.Add(row);
                }
                cLiquidityReportData.ReportRows.Add(row);
            }
        }

        //TODO: T.Zavorotnii (ALPHA-508) move method to CCashProjectionReportGenerator
        private CLiquidityReportData GenerateCashProjectionPmtsForSubs(Portfolio portfolio, DateTime dateSelected)
        {
            var cLiquidityReportData = new CLiquidityReportData();
            var cPerfectInvestments = new List<CLiquidityReportRow>();
            var ivc = portfolio.Investments;
            var organization = Organization.Loader.GetById(portfolio.OrganizationID);

            foreach (Investment investment in ivc)
            {
                var fund = investment.Fund;
                if (IsInvestmentIsNotEligable(fund, investment, dateSelected))
                    continue;

                var redPolicy = fund.InvestableFundPropeties.RedemptionPolicy;
                Allocation lastRedemption = investment.GetLastRedemption();
                DateTime lastRedemptionDate = lastRedemption == null || lastRedemption.ExecutionDate < dateSelected
                                                  ? dateSelected
                                                  : lastRedemption.ExecutionDate;
                //DateTime lastRedemptionDate = dateSelected;
                var liquidityTerm = EnumValue.GetEnumValueName(redPolicy.Liquidity);
                var redemptionNoticeMethod = redPolicy.NoticePeriodFullMethod;
                var redemptionNoticeMethodString = redemptionNoticeMethod > 0 ? redemptionNoticeMethod.ToString() : "N/A";
                redemptionNoticeMethodString = redemptionNoticeMethodString == "0" ? "N/A" : redemptionNoticeMethodString;
                var liquidityAsOf = EnumValue.GetEnumValueName(redPolicy.LiquidityAsOf);
                var properties = fund.InvestableFundPropeties;
                var firstAllocationExecutionDate = CalcExecutionDate(investment.FirstAllocationSubscription);
                var lockupTerm = EnumValue.GetEnumValueName(redPolicy.RedemptionLockupTerm);
                var series = fund.SeriesOriginal();
                if (portfolio.ReliefMethodologyString == EnumValue.RM_AVERAGE)
                {
                    var mvLocal = Investment.ComputeMarketValueLocalViaNavs(investment,series, dateSelected);

                    if (mvLocal <= 0)
                        continue;

                    var executionDate = firstAllocationExecutionDate;

                    ProcessCashProjectionRow(organization, dateSelected, cPerfectInvestments, cLiquidityReportData, fund, investment,
                                             mvLocal, executionDate, investment.FirstAllocationSubscription.TradeDate, properties.RedemptionPolicy,
                                             properties.RedemptionPaymentPolicy, lockupTerm,
                                             redemptionNoticeMethodString, liquidityTerm, liquidityAsOf,
                                             firstAllocationExecutionDate, lastRedemptionDate);
                }
                else
                {
                   
                    foreach (AllocationSubscription a in investment.Subscriptions(DateTime.MinValue, lastRedemptionDate))
                    {
                        if (a.ExecutionDate <= lastRedemptionDate && a.AllocationQuantityRemaining(lastRedemptionDate) > 0)
                        {
                            var mvLocal = a.MarketValueRemainingWithPriceOverride(fund,series,dateSelected);
                            var executionDate = CalcExecutionDate(a);
                            var lockUpPeriodStartDate = lockupTerm == EnumValue.LOCKUPTERM_INITIALINCEPTIONBASED
                                                            ? firstAllocationExecutionDate
                                                            : a.ExecutionDate;
                            ProcessCashProjectionRow(organization, dateSelected, cPerfectInvestments, cLiquidityReportData, fund,
                                                     investment, mvLocal, executionDate, a.TradeDate, properties.RedemptionPolicy,
                                                     properties.RedemptionPaymentPolicy, lockupTerm,
                                                     redemptionNoticeMethodString, liquidityTerm, liquidityAsOf,
                                                     lockUpPeriodStartDate, lastRedemptionDate);
                        }
                    }
                }

            }
            return cLiquidityReportData;
        }

        /// <summary>
        /// Do not calculate liquidity if the default values are not populated. The default values that need to be 
        /// populated are: Liquidity, LiquidityAsOf,LockupTerm,NoticePeriod(Full),atleast one full pament schedule
        /// </summary>
        private static bool AreDefaultValuesPopulated(string liquidityTerm, string liquidityAsOf, string lockupTerm, List<PaymentSchedule> paymentSchedules, 
            IEnumerable<Lockup> lockups, int noticeDays)
        {
            if (lockups.Any(details => (details.Years + details.Months + details.Days) == 0 && (details.Type == ELockupType.Rolling || details.Type == ELockupType.RollingHard)))
                return false;
            return !string.IsNullOrEmpty(liquidityTerm) &&
                   (!string.IsNullOrEmpty(liquidityAsOf) || liquidityTerm == EnumValue.FREQUENCY_DAILY) &&
                   !string.IsNullOrEmpty(lockupTerm) &&
                   paymentSchedules != null && paymentSchedules.Count > 0 && noticeDays > 0;
        }

        public CLiquidityReportData PopulateLiquidityReportRows(InvestmentCollection ivc, Portfolio p, LiquidityReportParameters parameters)
        {
            var cLiquidityReportData = new CLiquidityReportData();
            var cPerfectInvestments = new List<CLiquidityReportRow>();
            var organization = Organization.Loader.GetById(p.OrganizationID);
            foreach (var inv in ivc)
            {
                var fund = inv.Fund;
                if (fund is ContingentRedemption || fund is ShortSale || fund is Equalization)
                    continue;
                //skip investments where all allocations were deleted
                if (inv.Allocations == null || inv.Allocations.Count == 0)
                    continue;
                
                var series = fund.SeriesOriginal();
                var firstAllocationExecutionDate = CalcExecutionDate(inv.FirstAllocationSubscription);
                var paymentPolicy = GetEffectiveProperties(fund, FundPropertiesBase.REDEMPTION_PAYMENT_POLICY, parameters.AnalisysAsOfDate) as RedemptionPaymentProperties ??
                                       fund.InvestableFundPropeties.RedemptionPaymentPolicy;

                if (p.ReliefMethodologyString == EnumValue.RM_AVERAGE)
                {
                    var mvLocal = Investment.ComputeMarketValueLocalViaNavs(inv,series, parameters.AnalisysAsOfDate);

                    if (mvLocal <= 0)
                        continue;

                    var costRemaining = inv.GetCostRemainingForAverageReliefMethod(parameters.AnalisysAsOfDate);
                    var executionDate = firstAllocationExecutionDate;

                    ProcessLiquidityRowAdvanced(organization, parameters, cPerfectInvestments, cLiquidityReportData, fund, inv, mvLocal,
                                            costRemaining.LocalCost, executionDate, inv.FirstAllocationSubscription.TradeDate, paymentPolicy, null);
                }
                else
                {
                    foreach (var a in inv.Subscriptions().Where(a => a.ExecutionDate <= parameters.AnalisysAsOfDate))
                    {
                        var quantity = a.AllocationQuantityRemaining(parameters.AnalisysAsOfDate);
                        if (quantity <= 0)
                            continue;
                        var mvLocal = quantity * a.GetPriceWithPriceOverride(fund, series, parameters.AnalisysAsOfDate);
                        var cost = CalculateCost(a, parameters.AnalisysAsOfDate);
                        var executionDate = CalcExecutionDate(a);

                        ProcessLiquidityRowAdvanced(organization, parameters, cPerfectInvestments, cLiquidityReportData, fund, inv, mvLocal,
                                            cost, executionDate, a.TradeDate, paymentPolicy, a);
                    }
                }
            }

            //Make a collection of all the Dates and Percentages
            if (parameters.ShouldGenerateGraphData)
                LiquidityChartDataGenerator.GenerateGraphData(cLiquidityReportData, cPerfectInvestments);

            return cLiquidityReportData;
        }


        private void ProcessLiquidityRowAdvanced(Organization organization, LiquidityReportParameters parameters, List<CLiquidityReportRow> cPerfectInvestments,
            CLiquidityReportData cLiquidityReportData, InvestableFund fund, Investment inv, CAmount mvLocal, CAmount cost, DateTime executionDate, DateTime tradeDate,
            RedemptionPaymentProperties paymentPolicy, Allocation allocation)
        {
            // Retrieving liquidity rows for standard red. policy 
            var standartParameters = new LiquidityReportParameters(parameters)
                            {
                                RedemptionPolicyType = EnumValue.REDEMPTION_POLICY_STANDARD_TYPE_ID,
                                CurrencyId = parameters.CurrencyId
                            };
            
            var standardLiquidityReportData = new CLiquidityReportData();
            var standardPerfectInvestments = new List<CLiquidityReportRow>();
            ProcessLiquidityRow(organization, standartParameters, standardPerfectInvestments, standardLiquidityReportData, fund, inv, mvLocal,
                                cost, executionDate, tradeDate, paymentPolicy, allocation);

            // Retrieving liquidity rows for accelerated red. policy
            var acceleratedParameters = new LiquidityReportParameters(parameters)
            {
                RedemptionPolicyType = EnumValue.REDEMPTION_POLICY_ACCELERATED_TYPE_ID,
                CurrencyId = parameters.CurrencyId
            };
            var acceleratedLiquidityReportData = new CLiquidityReportData();
            var acceleratedPerfectInvestments = new List<CLiquidityReportRow>();
            ProcessLiquidityRow(organization, acceleratedParameters, acceleratedPerfectInvestments, acceleratedLiquidityReportData, fund, inv, mvLocal,
                                cost, executionDate, tradeDate, paymentPolicy, allocation);

            var acceleratedRedemptionPolicy = GetRedemptionPolicyForInvestment(inv, acceleratedParameters);
            var isAcceleratedRedemptionPolicyCopied = acceleratedRedemptionPolicy.IsStandardPolicyCopy;
            //Copying Soft. Lock Redeem fee between them for reference
            CopyFees(standardLiquidityReportData.ReportRows, acceleratedLiquidityReportData.ReportRows, isAcceleratedRedemptionPolicyCopied);
            
            //adding appropriate (standard / accelerated / hybrid) data to collections
            if (parameters.RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_STANDARD_TYPE_ID)
            {
                cLiquidityReportData.ReportRows.AddRange(standardLiquidityReportData.ReportRows);
                cPerfectInvestments.AddRange(standardPerfectInvestments);
            }
            else if (parameters.RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_ACCELERATED_TYPE_ID)
            {
                cLiquidityReportData.ReportRows.AddRange(acceleratedLiquidityReportData.ReportRows);
                cPerfectInvestments.AddRange(acceleratedPerfectInvestments);
            }
            else // Hybrid
            {
                var standardTotalFee = standardLiquidityReportData.ReportRows.Sum(r => r.RedeemFee);
                var acceratedTotalFee = acceleratedLiquidityReportData.ReportRows.Sum(r => r.RedeemFee);
                if (acceratedTotalFee < standardTotalFee)
                {
                    cLiquidityReportData.ReportRows.AddRange(acceleratedLiquidityReportData.ReportRows);
                    cPerfectInvestments.AddRange(acceleratedPerfectInvestments);
                }
                else
                {
                    cLiquidityReportData.ReportRows.AddRange(standardLiquidityReportData.ReportRows);
                    cPerfectInvestments.AddRange(standardPerfectInvestments);
                }
            }
        }

        private static void CopyFees(List<CLiquidityReportRow> standardRows, List<CLiquidityReportRow> acceleratedRows, bool isAcceleratedPolicyCopied)
        {
            if (standardRows.Count == 0 | acceleratedRows.Count == 0)
                return;
            foreach (var sr in standardRows)
            {
                var acceleratedRow =
                    acceleratedRows.SingleOrDefault(ar => ar.NextEligibleRedemDate == sr.NextEligibleRedemDate);
                if (acceleratedRow != null && !isAcceleratedPolicyCopied)
                    sr.RedeemFeeAccelerated = acceleratedRow.RedeemFeeAccelerated;
            }
            foreach (var ar in acceleratedRows)
            {
                var standardRow =
                    standardRows.SingleOrDefault(sr => sr.NextEligibleRedemDate == ar.NextEligibleRedemDate);
                if (standardRow != null)
                    ar.RedeemFeeSoftLockups = standardRow.RedeemFeeSoftLockups;
                if (isAcceleratedPolicyCopied)
                    ar.RedeemFeeAccelerated = -1;
            }

        }

        private void ProcessLiquidityRow(Organization organization, LiquidityReportParameters parameters, List<CLiquidityReportRow> cPerfectInvestments,
            CLiquidityReportData cLiquidityReportData, InvestableFund fund, Investment inv, CAmount mvLocal, CAmount cost, DateTime executionDate, DateTime tradeDate,
            RedemptionPaymentProperties paymentPolicy, Allocation allocation)
        {
            var redemptionPolicy = GetRedemptionPolicyForInvestment(inv, parameters);
            var lockupTerm = EnumValue.GetEnumValueName(redemptionPolicy.RedemptionLockupTerm);
            
            var redemptionNoticeMethod = redemptionPolicy.NoticePeriodFullMethod;
            var redemptionNoticeMethodString = redemptionNoticeMethod > 0 ? redemptionNoticeMethod.ToString() : "N/A";
            var liquidityProperty = redemptionPolicy.Liquidity;
            var liquidityTerm = EnumValue.GetEnumValueName(liquidityProperty);
            var liquidityAsOf = EnumValue.GetEnumValueName(redemptionPolicy.LiquidityAsOf);
            var firstAllocationExecutionDate = CalcExecutionDate(inv.FirstAllocationSubscription);

            var lockUpPeriodStartDate = lockupTerm != EnumValue.LOCKUPTERM_INITIALINCEPTIONBASED && allocation != null ?CalcExecutionDate( allocation) : firstAllocationExecutionDate;

            var generalRedFee = redemptionPolicy.GeneralRedemptionFee;
            var isRedAfterLockup = redemptionPolicy.RedemptionAfterLockupExpire;
            var custFreqDate = redemptionPolicy.RedemptionFrequencyDate;
            var noticeDays = redemptionPolicy.NoticePeriodFullDays;

            var newRow = new CLiquidityReportRow
            {
                RedemptiononAfterLockUpExpire = isRedAfterLockup,
                FundID = fund.FundID,
                FundName = fund.FullNameInvestable,
                IsFundSidePocket = fund.IsSidePocket,
                Currency = fund.CurrencyId,
                DeltaLocal = cost,
                ExecutionDate = executionDate,
                TradeDate = tradeDate,
                RedemptionMethodString = lockupTerm,
                MarketValue = Rate.Convert(mvLocal, organization, inv, parameters.AnalisysAsOfDate),
                AsOf = parameters.AnalisysAsOfDate,
                NoticeDays = noticeDays,
                RedmeptionNoticeMethodString = redemptionNoticeMethodString,
                AllocationsCount = inv.Allocations.Count,
                Gate = redemptionPolicy.RedemptionGate ? "Y" : "N",
                RedemptionPolicyType = EnumValue.GetEnumValueName(parameters.RedemptionPolicyType),
                BaseFund = fund.Basefund
            };


            if (!AreDefaultValuesPopulated(liquidityTerm, liquidityAsOf, lockupTerm, paymentPolicy.FullPaymentScheduleList.Items, redemptionPolicy.Lockups, noticeDays))
            {
                newRow.IsPerfect = false;
                cLiquidityReportData.ReportRows.Add(newRow);
                return; 
            }


            var lockupCalculator = new LockupCalculator(redemptionPolicy.Lockups, lockUpPeriodStartDate, redemptionPolicy.Schedule);

            var liquidityCalculator = new LiquidityDateCalculator(redemptionPolicy.Lockups, lockUpPeriodStartDate, redemptionPolicy.Schedule,
                liquidityTerm, newRow.ExecutionDate, custFreqDate, liquidityAsOf, parameters.AnalisysAsOfDate, isRedAfterLockup);

            //TODO: T.Zavorotnii CalculateLockUpAnalysisColumns and CalculateNextEligibleRedemption should be one method
            newRow.LiquidityTerm = liquidityTerm;
            CalculateLockUpAnalysisColumns(organization, newRow, fund, lockupCalculator, inv, parameters);
            
            CalculateNextEligibleRedemption(newRow, parameters.AnalisysAsOfDate, parameters.SessionNextEligible, liquidityCalculator, generalRedFee, redemptionPolicy.NoticePeriodSchedule);

            PopulateNoticeDateAndDays(newRow, redemptionPolicy.NoticePeriodSchedule, parameters.AnalisysAsOfDate);

            //TODO: The case of rolling lockup is considered as a soft lockup. This should be updated since rolling is indefinite lockup.
            var totalLockupExpiryDate = lockupCalculator.MoveLast() ? lockupCalculator.Current.CorrectedLockupExpiryDate : DateUtil.AddYearsMonthsDays(lockUpPeriodStartDate, redemptionPolicy.TotalLockup);
            
            //TODO T.Zavorotnii (ALPHA-508) Avoid using CRedemptionDate following todo marks from CalculateHardLockupFields method definition
            //newRow.HardLockupEligibleRedDate = LiquidityDateCalculator.CalculateHardLockupEligibleRedDate(newRow.MarketValue, totalLockupExpiryDate, executionDate, parameters.AnalisysAsOfDate, liquidityPolicyProperties);
            //newRow.HardLockupMvAfterRedFee  = ......

            var hardLockupCRedDate = new CRedemptionDate(totalLockupExpiryDate, liquidityTerm, executionDate, custFreqDate, liquidityAsOf);

            CalculateHardLockupFields(newRow, hardLockupCRedDate, redemptionPolicy, parameters.AnalisysAsOfDate, DateTime.MinValue);
            CalculateRedemptionDatesColumns(newRow, fund, true);
            var exchangeRate = FxRatesImpl.ExchangeRate(organization, inv.CurrencyIdLocal, parameters.CurrencyId, parameters.AnalisysAsOfDate);

            //get MaxRedemptionsRows here.
            var cLiquidityMaxRedemptionRows = CalculateMaxRedemptionRows(newRow, redemptionPolicy, parameters.AnalisysAsOfDate, liquidityCalculator, fund, hardLockupCRedDate);

            // Use the redemption RowsCollection to add to total Redemption Pct
            // If the TotalRedemptionPcts is 100, then it is a perfect investment, to use in graph generation
            foreach (var row in cLiquidityMaxRedemptionRows)
            {
                if (!generalRedFee.IsPercent && generalRedFee.Number > row.MarketValueAfterRedeemFee.Value)
                    continue;

                var totalRedemptionPct = row.RedemptionPaymentList.Sum(payment => payment.PmtPct);
                row.IsPerfect = totalRedemptionPct.Equals(100) && row.RedemptionPaymentList[0].PmtDate != DateTime.MinValue;
                if (row.IsPerfect)
                {
                    CalculatePaymentAmounts(row, exchangeRate);
                    cPerfectInvestments.Add(row);
                }
                cLiquidityReportData.ReportRows.Add(row);
            }
        }

        public static FundPropertiesBase GetEffectiveProperties(InvestableFund fund, string propertyName, DateTime effectiveDate)
        {
            if (fund.GsmFundId > 0 && fund.OrganizationEntity.FlowFromGsm)
            {
                var f = UnderlyingFund.GetFund(fund.GsmFundId) as InvestableFund;
                if (f != null)
                {
                    var props = f.InvestableFundPropeties;
                    var classPropertyExpression = Expression.Parse(propertyName);
                    var source = (FundPropertiesBase)classPropertyExpression.GetValue(props);

                    return source.GetActualApprovedValue(effectiveDate);
                    //return source.LastOrDefaultFromHistory(pair => pair.Key.Date <= effectiveDate);
                }
            }
            return null;
        }

        //HardLockupEligibleRedDate = (Date of the first eligible redemption after all lockups expired) - (NoticeDays)
        //HardLockupMvAfterRedFee = Market value after general redemption fee applied
        private static void CalculateHardLockupFields(CLiquidityReportRow newRow, CRedemptionDate hardLockupCRedDate, RedemptionPolicyProperties redemptionPolicy, DateTime dateSelected, DateTime previousRedemptionDate)
        {
            //TODO T.Zavorotnii (ALPHA-508) Move HardLockupEligibleRedDate calculation to LiquidityDateCalculator
            var generalRedFee = redemptionPolicy.GeneralRedemptionFee;
            CAmount mvAfterRedFee = newRow.MarketValue;
            var noticeDays = newRow.NoticeDays == -1 ? 0 : newRow.NoticeDays;

            if (hardLockupCRedDate != null && hardLockupCRedDate.MoveFirst())
            {
                var hardLockupEligibleRedDate = hardLockupCRedDate.Current;
                hardLockupEligibleRedDate = AddNoticeDays(hardLockupEligibleRedDate, -noticeDays, redemptionPolicy.NoticePeriodSchedule);

                while (hardLockupEligibleRedDate < dateSelected || hardLockupCRedDate.Current <= previousRedemptionDate)
                {
                    if (!hardLockupCRedDate.MoveNext())
                        break;

                    hardLockupEligibleRedDate = hardLockupCRedDate.Current;
                    hardLockupEligibleRedDate = AddNoticeDays(hardLockupEligibleRedDate, -noticeDays, redemptionPolicy.NoticePeriodSchedule);
                }
                newRow.HardLockupEligibleRedDate = hardLockupCRedDate.Current;
            }

            //TODO T.Zavorotnii (ALPHA-508) This calculation can be done in the only place HardLockupMvAfterRedFee is used.
            //After that HardLockupMvAfterRedFee becomes redundant
            if (generalRedFee != null && !double.IsNaN(generalRedFee.Number))
            {
                mvAfterRedFee = generalRedFee.IsPercent ? newRow.MarketValue - newRow.MarketValue * generalRedFee.Number / 100 : newRow.MarketValue - generalRedFee.Number;
            }
            newRow.HardLockupMvAfterRedFee = mvAfterRedFee;
        }

        private static void PopulateNoticeDateAndDays(CLiquidityReportRow row, string schedule, DateTime selectedDate)
        {
            var noticeDate = DateTime.MinValue;
            if (row.NextEligibleRedemDate != DateTime.MinValue)
            {
                noticeDate = schedule == "Business" ? DateUtil.AddBusinessDays(row.NextEligibleRedemDate, -row.NoticeDays) : row.NextEligibleRedemDate.AddDays(-row.NoticeDays);
            }
            row.DateToGiveNotice = noticeDate;
            row.DaysToGiveNotice = noticeDate == DateTime.MinValue ? -1 : noticeDate.Subtract(selectedDate).Days;
            row.NoticeDaysCalendar = row.NextEligibleRedemDate.Subtract(noticeDate).Days;
        }

        //TODO: T.Zavorotnii (ALPHA-508) move method to LiquidityDateCalculator to avoid using LockupCalculator here
        private void CalculateLockUpAnalysisColumns(Organization organization, CLiquidityReportRow newRow, InvestableFund fund, LockupCalculator lockupCalculator, Investment inv, LiquidityReportParameters parameters)
        {
            LoadRedemptionFeeGeneral(newRow, fund, parameters);

            if (!lockupCalculator.MoveFirst())
                return;

            //Looking for current or last lockup
            var lockupInfo = lockupCalculator.Current;
            if (lockupCalculator.IsWithinLockupPeriod(parameters.AnalisysAsOfDate))
            {
                while (lockupInfo.LockupExpiryDate < parameters.AnalisysAsOfDate)
                {
                    if (!lockupCalculator.MoveNext())
                        break;
                    lockupInfo = lockupCalculator.Current;
                }
            }
            else
            {
                lockupCalculator.MoveLast();
                lockupInfo = lockupCalculator.Current;
            }

            newRow.LockUpExpirationDate = lockupInfo.CorrectedLockupExpiryDate;
            newRow.LockUpExpired = newRow.LockUpExpirationDate < parameters.AnalisysAsOfDate ? "Y" : "N";
            if (CLockupType.LockupTypeDisplay.ContainsKey(lockupInfo.LockupDetails.Type))
                newRow.LockUpExpiredType = CLockupType.LockupTypeDisplay[lockupInfo.LockupDetails.Type];

            //DaysToLockUpExpiry
            if (newRow.LockUpExpirationDate <= parameters.AnalisysAsOfDate)
                newRow.DaysToLockUpExpiry = 0;
            else
            {
                var timeSpan = newRow.LockUpExpirationDate - parameters.AnalisysAsOfDate;
                newRow.DaysToLockUpExpiry = timeSpan.Days < 0 ? 0 : timeSpan.Days;
            }

            newRow.MarketValueAfterRedeemFee = newRow.MarketValue; //Initialize
            CalculateRedemptionFeeColumns(organization, newRow, inv, parameters.AnalisysAsOfDate, lockupInfo.LockupDetails, parameters);
        }

        private void LoadRedemptionFeeGeneral(CLiquidityReportRow newRow, InvestableFund fund, LiquidityReportParameters parameters)
        {
            var redemptionPolicy = GetRedemptionPolicyForInvestableFund(fund, parameters);
            if (parameters.RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_STANDARD_TYPE_ID || parameters.RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_ACCELERATED_TYPE_ID)
            {
                var fee = redemptionPolicy.GeneralRedemptionFee;
                if (fee != null && !double.IsNaN(fee.Number))
                    newRow.RedeemFeeGeneral = fee.IsPercent ? fee.Number : (fee.Number / newRow.MarketValue.Value) * 100;
                else
                    newRow.RedeemFeeGeneral = -1;
           }
        }

        //TODO: T.Zavorotnii (ALPHA-508) move method to LiquidityDateCalculator
        private  void CalculateRedemptionFeeColumns(Organization organization, CLiquidityReportRow newRow, Investment inv, DateTime dateSelected, 
            Lockup lockup, LiquidityReportParameters parameters)
        {
            if (lockup != null && lockup.Type == ELockupType.Hard && newRow.LockUpExpirationDate > dateSelected)
                return;

            CAmount mktValue = newRow.MarketValue;
            newRow.MarketValueAfterRedeemFee = mktValue; //Initialize

            double softLockFeePct = 0;
            if (lockup != null && null != lockup.Fee && !double.IsNaN(lockup.Fee.Number))
            {
                softLockFeePct += lockup.Fee.IsPercent ? lockup.Fee.Number
                    : (Rate.Convert(lockup.Fee.Number, organization, inv, dateSelected) / newRow.MarketValue.Value) * 100;
            }

            if (parameters.RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_STANDARD_TYPE_ID)
            {
                newRow.RedeemFeeSoftLockups = softLockFeePct;
            }
            else if (parameters.RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_ACCELERATED_TYPE_ID)
            {
                newRow.RedeemFeeAccelerated = softLockFeePct;
            }
            else
            {
                throw new ArgumentException(@"Cannot generate data for \'Hybrid\' redemption policy", "parameters");
            }
        }

        private static void CalculateRedemptionDatesColumns(CLiquidityReportRow newRow, InvestableFund fund, bool useFullRedemptionPaymentSchedule)
        {
            var properties = fund.InvestableFundPropeties.RedemptionPaymentPolicy;
            var paymentList = useFullRedemptionPaymentSchedule ? properties.FullPaymentScheduleList.Items : properties.PartialPaymentScheduleList.Items;

            var bf = fund.Basefund;
            if (bf == null)
                return;
            var fiscalMonth = bf.BaseFundProperties.BasicInformation.FiscalMonth;
            if (fiscalMonth <= 0)
                fiscalMonth = 12;
            var fiscalYearEnd = DateUtil.GetEndOfMonthDate(DateTime.Now.Year, fiscalMonth);
            newRow.RedemptionPaymentList = new List<RedemptionPaymentData>();

            if (paymentList != null)
            {
                foreach (var paymentSchedule in paymentList)
                {
                    var pmtDate = CalculatePaymentDate(paymentSchedule.PmtDays, newRow.NextEligibleRedemDate, properties.Schedule);
                    var hardLockupPmtDate = CalculatePaymentDate(paymentSchedule.PmtDays, newRow.HardLockupEligibleRedDate, properties.Schedule);
                    newRow.RedemptionPaymentList.Add(new RedemptionPaymentData(paymentSchedule.PmtPct, paymentSchedule.PmtDays, pmtDate, hardLockupPmtDate));
                }
            }

            var holdback = useFullRedemptionPaymentSchedule ? properties.FullRedHoldbackSchedule : properties.PartialRedHoldbackSchedule;
            if (holdback != null && !double.IsNaN(holdback.PmtPct))
            {
                //Add Holdback as an extra payment
                var pmtAfter = EnumValue.GetEnumValueName(holdback.PmtAfter);
                var pmtDate = CalculateHoldbackPaymentDate(newRow.NextEligibleRedemDate, holdback.PmtDays, pmtAfter,
                    properties.Schedule, properties.ExpectedAuditMonth, properties.ExpectedAuditDay, fiscalYearEnd);

                var hardLockupPmtDate = CalculateHoldbackPaymentDate(newRow.HardLockupEligibleRedDate, holdback.PmtDays, pmtAfter, 
                    properties.Schedule, properties.ExpectedAuditMonth, properties.ExpectedAuditDay, fiscalYearEnd);

                newRow.RedemptionPaymentList.Add(new RedemptionPaymentData(holdback.PmtPct, holdback.PmtDays, pmtDate, hardLockupPmtDate));
            }
        }

        private static IEnumerable<CLiquidityReportRow> CalculateMaxRedemptionRows(CLiquidityReportRow originalRow, RedemptionPolicyProperties redemptionPolicy,
            DateTime dateSelected, LiquidityDateCalculator liquidityCalc, InvestableFund fund, CRedemptionDate hardLockupCRedDate)
        {
            var maxRedRows = new List<CLiquidityReportRow>();
            var totalDeltaLocal = CAmount.Zero();
            var totalMarketValue = CAmount.Zero();
            var generalRedFee = redemptionPolicy.GeneralRedemptionFee;

            if (!double.IsNaN(redemptionPolicy.Maxredemption.Number) && liquidityCalc.MoveFirst())
            {
                var liquidityInfo = liquidityCalc.Current;

                while (liquidityInfo.RedemptionDate != DateTime.MinValue && liquidityInfo.RedemptionDate < originalRow.NextEligibleRedemDate)
                {
                    if (!liquidityCalc.MoveNext())
                        break;

                    liquidityInfo = liquidityCalc.Current;
                }

                var divisor = redemptionPolicy.Maxredemption.IsPercent ? 100 / redemptionPolicy.Maxredemption.Number : originalRow.MarketValue.Value / redemptionPolicy.Maxredemption.Number;
                var maxRedRowCount = 0;
                var divisorMinusOne = divisor - 1;

                while (maxRedRowCount < divisor)
                {
                    var newMaxRedRow = new CLiquidityReportRow(originalRow);
                    maxRedRows.Add(newMaxRedRow);

                    if (maxRedRowCount < divisorMinusOne)
                    {
                        newMaxRedRow.DeltaLocal = newMaxRedRow.DeltaLocal / divisor;
                        newMaxRedRow.MarketValue = newMaxRedRow.MarketValue / divisor;
                    }
                    else
                    {
                        newMaxRedRow.DeltaLocal = newMaxRedRow.DeltaLocal - totalDeltaLocal;
                        newMaxRedRow.MarketValue = newMaxRedRow.MarketValue - totalMarketValue;
                    }
                    totalDeltaLocal += newMaxRedRow.DeltaLocal;
                    totalMarketValue += newMaxRedRow.MarketValue;
                    maxRedRowCount++;

                    if (newMaxRedRow.NextEligibleRedemDate != DateTime.MinValue)
                        newMaxRedRow.NextEligibleRedemDate = liquidityInfo.RedemptionDate;
                    PopulateNoticeDateAndDays(newMaxRedRow, redemptionPolicy.NoticePeriodSchedule, dateSelected);

                    //Calculate new MarketValueAfterRedeemFee for chart
                    double totalFeePct = NormalizeToPercent(generalRedFee, newMaxRedRow.MarketValue);

                    if (liquidityCalc.ApplyFee())
                        totalFeePct += NormalizeToPercent(liquidityInfo.ActiveLockup.LockupDetails.Fee, newMaxRedRow.MarketValue);
                    else
                    {
                        switch (newMaxRedRow.RedemptionPolicyType)
                        {
                            case EnumValue.REDEMPTION_POLICY_STANDARD:
                                newMaxRedRow.RedeemFeeSoftLockups = -1;
                                break;
                            case EnumValue.REDEMPTION_POLICY_ACCELERATED:
                                newMaxRedRow.RedeemFeeAccelerated = -1;
                                break;
                        }
                    }
                    newMaxRedRow.MarketValueAfterRedeemFee = double.IsNaN(totalFeePct) ? newMaxRedRow.MarketValue
                        : newMaxRedRow.MarketValue - (newMaxRedRow.MarketValue * totalFeePct / 100);

                    liquidityCalc.MoveNext();
                    liquidityInfo = liquidityCalc.Current;
                }

                if (hardLockupCRedDate != null)
                {
                    var previousRedemptionDate = DateTime.MinValue;
                    hardLockupCRedDate.MoveFirst();
                    foreach (var row in maxRedRows)
                    {
                        CalculateHardLockupFields(row, hardLockupCRedDate, redemptionPolicy, dateSelected, previousRedemptionDate);
                        previousRedemptionDate = row.HardLockupEligibleRedDate;
                        CalculateRedemptionDatesColumns(row, fund, true);
                    }
                }
            }
            else
            {
                maxRedRows.Add(originalRow);   //No Need to Split the Rows.
            }
            return maxRedRows;
        }

        internal static void CalculatePaymentAmounts(CLiquidityReportRow row, double exchangeRate = 1)
        {
            foreach (var payment in row.RedemptionPaymentList.Where(p => !p.PmtPct.Equals(0)))
            {
                payment.PmtAmount = GetPaymentAmount(row.MarketValue, exchangeRate, payment.PmtPct); 
                payment.PmtAmountAfterRedeemFee = GetPaymentAmount(row.MarketValueAfterRedeemFee, exchangeRate, payment.PmtPct);
                payment.HardLockupPmtAmount = GetPaymentAmount(row.HardLockupMvAfterRedFee, exchangeRate, payment.PmtPct);
            }
        }

        private static CAmount GetPaymentAmount(CAmount mv, double exchangeRate, double paymentPercent)
        {
            return mv == null ? CAmount.Zero() : mv * exchangeRate * paymentPercent / 100;
        }

        public static DateTime CalcExecutionDate(Allocation allocation)
        {
            return allocation is AllocationExchangeIn ? ((AllocationExchangeIn)allocation).ExchangeMessageDate : allocation.ExecutionDate;
        }

        private static DateTime CalculatePaymentDate(double pmtDays, DateTime nextEligibleRedemptionDate, string schedule)
        {
            return schedule == "Business" ? DateUtil.AddBusinessDays(nextEligibleRedemptionDate, (int)pmtDays) : nextEligibleRedemptionDate.AddDays(pmtDays);
        }

        private static DateTime CalculateHoldbackPaymentDate(DateTime eligibleRedemptionDate, double paymentDays, string paymentDateType,
            string schedule, int expectedAuditMonth, int expectedAuditDay, DateTime fundFiscalYearEnd)
        {
            DateTime holdbackPaymentDate;
            switch (paymentDateType)
            {
                case EnumValue.END_DATE_CLASSIFICATION_AUDIT:
                    if (!DateUtil.CheckValidDateTime(eligibleRedemptionDate.Year, expectedAuditMonth, expectedAuditDay))
                    {
                        expectedAuditMonth = 3;
                        expectedAuditDay = 31;
                    }
                    var thisYearAuditDate = new DateTime(eligibleRedemptionDate.Year, expectedAuditMonth, expectedAuditDay);
                    holdbackPaymentDate = eligibleRedemptionDate <= fundFiscalYearEnd && fundFiscalYearEnd < thisYearAuditDate ? thisYearAuditDate : thisYearAuditDate.AddYears(1);
                    break;
                case EnumValue.END_DATE_CLASSIFICATION_YEAREND:
                    holdbackPaymentDate = new DateTime(eligibleRedemptionDate.Year, 12, 31);
                    break;
                case EnumValue.END_DATE_CLASSIFICATION_FISCAL_YEAREND:
                    fundFiscalYearEnd = fundFiscalYearEnd != DateTime.MinValue ? fundFiscalYearEnd : eligibleRedemptionDate;
                    holdbackPaymentDate = eligibleRedemptionDate < fundFiscalYearEnd ? fundFiscalYearEnd : fundFiscalYearEnd.AddYears(1);
                    break;
                default:
                    holdbackPaymentDate = eligibleRedemptionDate;
                    break;
            }

            return schedule == "Business" ? DateUtil.AddBusinessDays(holdbackPaymentDate, (int)paymentDays) : holdbackPaymentDate.AddDays(paymentDays);
        }

        private static CAmount CalculateCost(Allocation allocation, DateTime dateSelected)
        {
            //For Cost calculations, we should use the exchangeRate on the execution date
            return allocation.GetCostRemaining(dateSelected) / allocation.ExchangeRateForGlsMessage;
        }

        private static void CalculateNextEligibleRedemption(CLiquidityReportRow newRow, DateTime dateSelected,
            int sessionNextEligible, LiquidityDateCalculator liquidityCalculator, CDollarPercentTabNumber generalRedFee, string noticePeriodSchedule)
        {
            if (!liquidityCalculator.MoveFirst())
                return;

            var liquidityInfo = liquidityCalculator.Current;
            var noticeDays = newRow.NoticeDays == -1 ? 0 : newRow.NoticeDays;
            var redDateLessNoticeDays = AddNoticeDays(liquidityInfo.RedemptionDate, -noticeDays, noticePeriodSchedule);

            while (dateSelected > redDateLessNoticeDays)
            {
                if (!liquidityCalculator.MoveNext())
                    break;

                liquidityInfo = liquidityCalculator.Current;
                redDateLessNoticeDays = AddNoticeDays(liquidityInfo.RedemptionDate, -noticeDays, noticePeriodSchedule);
            }

            if (sessionNextEligible > 0)
            {
                for (int i = 1; i <= sessionNextEligible; i++)
                {
                    liquidityCalculator.MoveNext();
                }
            }

            liquidityInfo = liquidityCalculator.Current;
            newRow.NextEligibleRedemDate = liquidityInfo.RedemptionDate;

            double totalFeePct = NormalizeToPercent(generalRedFee, newRow.MarketValue);
            totalFeePct = double.IsNaN(totalFeePct) ? 0 : totalFeePct;
            if (liquidityCalculator.ApplyFee())
                totalFeePct += NormalizeToPercent(liquidityInfo.ActiveLockup.LockupDetails.Fee, newRow.MarketValue);
            else
            {
                if (newRow.RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_STANDARD)
                    newRow.RedeemFeeSoftLockups = -1;
                else if (newRow.RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_ACCELERATED)
                    newRow.RedeemFeeAccelerated = -1;
            }

            newRow.MarketValueAfterRedeemFee = newRow.MarketValue - (newRow.MarketValue * totalFeePct / 100);
        }

        private static double NormalizeToPercent(CDollarPercentTabNumber fee, CAmount amount)
        {
            double pct = 0;
            if (fee != null && !double.IsNaN(fee.Number))
            {
                pct = fee.IsPercent ? fee.Number : (fee.Number / amount.Value) * 100;
            }
            return pct;
        }

        private static DateTime AddNoticeDays(DateTime date, int days, string schedule)
        {
            return schedule == "Business" ? DateUtil.AddBusinessDays(date, days) : date.AddDays(days);
        }

        private RedemptionPolicyProperties GetRedemptionPolicyForInvestment(Investment investment, LiquidityReportParameters reportParameters)
        {
            ValidationRedemptionPolicy(reportParameters.RedemptionPolicyType);

            var fund = investment.Fund;

            var redemptionPolicyStandard =
                GetEffectiveProperties(fund, FundPropertiesBase.REDEMPTION_POLICY, reportParameters.AnalisysAsOfDate) as
                RedemptionPolicyProperties ??
                fund.InvestableFundPropeties.RedemptionPolicy;

            var redemptionPolicyAccelerated =
                GetEffectiveProperties(fund, FundPropertiesBase.REDEMPTION_POLICY_ACCELERATED,
                                       reportParameters.AnalisysAsOfDate) as RedemptionPolicyProperties ??
                fund.InvestableFundPropeties.RedemptionPolicyAccelerated;

            return SelectRedemptionPolicy(redemptionPolicyAccelerated, redemptionPolicyStandard, reportParameters);
        }

        private RedemptionPolicyProperties GetRedemptionPolicyForInvestableFund(InvestableFund fund, LiquidityReportParameters reportParameters)
        {
            ValidationRedemptionPolicy(reportParameters.RedemptionPolicyType);

            var redemptionPolicyStandard = fund.InvestableFundPropeties.RedemptionPolicy;

            var redemptionPolicyAccelerated = fund.InvestableFundPropeties.RedemptionPolicyAccelerated;

            return SelectRedemptionPolicy(redemptionPolicyAccelerated, redemptionPolicyStandard, reportParameters);
        }

        private RedemptionPolicyProperties SelectRedemptionPolicy(RedemptionPolicyProperties redemptionPolicyAccelerated, RedemptionPolicyProperties redemptionPolicyStandard, LiquidityReportParameters reportParameters)
        {
            GetCommonRedemptionpolicyProperties(redemptionPolicyAccelerated, redemptionPolicyStandard);
            RedemptionPolicyProperties redemptionPolicy;
            if (reportParameters.RedemptionPolicyType == EnumValue.REDEMPTION_POLICY_STANDARD_TYPE_ID)
                redemptionPolicy = redemptionPolicyStandard;
            else if (IsAccelaratedRedemtionPolicyPopulated(redemptionPolicyAccelerated))
            {
                redemptionPolicy = redemptionPolicyAccelerated;
            }
            else // when accelerated policy is not populated
            {
                redemptionPolicy = GetAcceleratedPolicyFromStandardPolicy(redemptionPolicyStandard);
            }
            return redemptionPolicy;
        }

        private static RedemptionPolicyProperties GetAcceleratedPolicyFromStandardPolicy(RedemptionPolicyProperties redemptionPolicyStandard)
        {
            var redemptionPolicy = (RedemptionPolicyProperties)redemptionPolicyStandard.Clone();
            redemptionPolicy.IsStandardPolicyCopy = true;
            return redemptionPolicy;
        }

        private void ValidationRedemptionPolicy(int policyType)
        {
            if (policyType == EnumValue.REDEMPTION_POLICY_HYBRID_TYPE_ID)
                throw new ArgumentException(@"Cannot generate data for \'Hybrid\' redemption policy", "policyType");
        }

        private static bool IsAccelaratedRedemtionPolicyPopulated(RedemptionPolicyProperties redemptionPolicyAccelerated)
        {
            return redemptionPolicyAccelerated.RedemptionLockupTerm != -1 &&
                   redemptionPolicyAccelerated.Liquidity != -1 &&
                   redemptionPolicyAccelerated.LiquidityAsOf != -1 &&
                   redemptionPolicyAccelerated.NoticePeriodFullDays != 0;
        }

        private static void GetCommonRedemptionpolicyProperties(RedemptionPolicyProperties redemptionPolicyAccelerated, RedemptionPolicyProperties redemptionPolicyStandard)
        {
            redemptionPolicyAccelerated.DistributedDeclaration = redemptionPolicyStandard.DistributedDeclaration;
            redemptionPolicyAccelerated.HolidaySchedule = redemptionPolicyStandard.HolidaySchedule;
            redemptionPolicyAccelerated.RedemptionCeiling = redemptionPolicyStandard.RedemptionCeiling;
            redemptionPolicyAccelerated.RedemptionSidePocketNotes = redemptionPolicyStandard.RedemptionSidePocketNotes;
            redemptionPolicyAccelerated.RedemptionGate = redemptionPolicyStandard.RedemptionGate;
            redemptionPolicyAccelerated.RedemptionGatePercent = redemptionPolicyStandard.RedemptionGatePercent;
            redemptionPolicyAccelerated.RedemptionGateNotes = redemptionPolicyStandard.RedemptionGateNotes;
        }

        #endregion
    }
}