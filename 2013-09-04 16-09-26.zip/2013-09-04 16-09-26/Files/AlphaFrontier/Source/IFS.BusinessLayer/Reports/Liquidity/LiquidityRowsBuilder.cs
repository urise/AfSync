﻿using System;
using IFS.Interfaces.Rounding;

namespace IFS.BusinessLayer.Reports.Liquidity
{
    public class LiquidityRowsBuilder
    {
        private CAmount _mv;
        private CAmount _deltalLocal;
        private readonly CAmount _maxRedeemingAmount;
        private readonly CAmount _maxRedeemingDeltalocal;
        private readonly LiquidityRows _rows = new LiquidityRows();
        private readonly LiquidityType _liquidityType;
        private readonly DateTime _startDate;
        private int loopCounter = 1000;

        public LiquidityRowsBuilder(MaxRedemptionTerms terms, LotInitialState state)
        {
            _mv = state.MarketValue;
            _deltalLocal = state.DeltaLocal?? CAmount.Zero();
            _startDate = state.Date;
            _maxRedeemingAmount = terms.GetMaxRedemptionAmount(_mv);
            _maxRedeemingDeltalocal = terms.GetMaxRedemptionAmount(_deltalLocal);
            _liquidityType = terms.Liquidity;
        }

        public LiquidityRows GetLiquidityRows()
        {
            while (!IsFullyRedeemed())
            {
                AddRedemption();
                CheckIfGeneratedTooManyEvents();
            }
            return _rows;
        }

        private void CheckIfGeneratedTooManyEvents()
        {
            if (loopCounter-- == 0)
                throw new ValidationException("Liquidity generated too many events", ValidationExceptionTypes.CIRCULAR_CALCS);
        }

        private void AddRedemption()
        {
            if (CanFullyRedeem())
                AddFullRedemption();
            else
                AddPartialRedemption();
        }

        public bool IsFullyRedeemed()
        {
            return _mv == CAmount.Zero();
        }

        public void AddPartialRedemption()
        {
            _rows.AddNewRow(new RedemptionEventRow {DeltaLocal  = _maxRedeemingDeltalocal, MarketValue = _maxRedeemingAmount, RedeemDate = _liquidityType.GetDate(_startDate, _rows.GetCount() + 1) });
            _mv -= _maxRedeemingAmount;
            _deltalLocal -= _maxRedeemingDeltalocal;
        }

        public void AddFullRedemption()
        {
            _rows.AddNewRow(new RedemptionEventRow { DeltaLocal = _deltalLocal, MarketValue = _mv, RedeemDate = _liquidityType.GetDate(_startDate, _rows.GetCount() + 1) });
            _mv = CAmount.Zero();
            _deltalLocal = CAmount.Zero();
        }

        public bool CanFullyRedeem()
        {
            return _mv <= _maxRedeemingAmount;
        }

        public CAmount GetAmountRemaining()
        {
            return _mv;
        }
    }
}