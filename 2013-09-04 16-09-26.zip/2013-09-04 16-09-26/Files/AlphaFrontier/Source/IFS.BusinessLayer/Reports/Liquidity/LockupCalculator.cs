﻿using System;
using System.Collections.Generic;
using IFS.BusinessLayer.FundProperty.Fund;
using IFS.BusinessLayer.Launchpad.Liquidity;
using IFS.BusinessLayer.Utilities;

namespace IFS.BusinessLayer.Reports.Liquidity
{
    public class LockupCalculator
    {
        private readonly List<Lockup> _feeDetails;
        private readonly DateTime _startDate;
        private bool _bReset;
        private readonly string _schedule;
        private int _counter;
        private readonly int _totalYears;
        private readonly int _totalMonths;
        private readonly int _totalDays;
        private readonly DateTime _allLockupsExpiryDate;

        public LockupCalculator(List<Lockup> feeDetails, DateTime startDate, string schedule)
        {
            _feeDetails = feeDetails;
            _startDate = startDate;
            _schedule = schedule;

            if (!AreDefaultVariablesPopulated())
                return;

            foreach (var details in _feeDetails)
            {
                _totalYears += details.Years;
                _totalMonths += details.Months;
                _totalDays += details.Days;
                if ((details.Years + details.Months + details.Days) == 0)
                    throw new ArgumentException("Lockup must have term defined(years, months or days)");
            }

            _allLockupsExpiryDate = _startDate != DateTime.MinValue
                                        ? DateUtil.AddYearsMonthsDays(_startDate, _totalYears, _totalMonths, _totalDays)
                                              .AddDays(-1)
                                        : DateTime.MinValue;
        }

        public bool MoveLast()
        {
            if (!AreDefaultVariablesPopulated())
                return false;

            var lockupInfo = new LockupInfo {LockupDetails = _feeDetails[_feeDetails.Count - 1]};
            if (lockupInfo.LockupDetails.Type == ELockupType.Rolling)
                return false;

            lockupInfo.LockupExpiryDate = _allLockupsExpiryDate;
            lockupInfo.CorrectedLockupExpiryDate = CorrectedDate(lockupInfo.LockupExpiryDate,_schedule);
            Current = lockupInfo;
            return true;
        }

        public bool MoveNext()
        {
            if (!AreDefaultVariablesPopulated())
                return false;

            if (_bReset)
                return MoveFirst();
            DateTime lockupExpiryDate;
            if (_counter < _feeDetails.Count - 1)
            {
                _counter++;
                Current.LockupDetails = _feeDetails[_counter];
                lockupExpiryDate = AddYearsMonthsDays(Current.LockupExpiryDate,
                                                                    Current.LockupDetails);
                if (lockupExpiryDate == Current.LockupExpiryDate)
                    throw new Exception("This exception has been thrown to avoid an infinite loop. " +
                        "The next lockup expiry date is  the same as current lockup expiry date. "+
                        "Please check your lockup details");
                Current.LockupExpiryDate = lockupExpiryDate;
                Current.CorrectedLockupExpiryDate = CorrectedDate(Current.LockupExpiryDate, _schedule);
                return true;
            }

            switch (_feeDetails[_feeDetails.Count - 1].Type)
            {
                case ELockupType.Rolling:
                case ELockupType.RollingHard:
                    break;
                default:
                    return false;
            }

            lockupExpiryDate = AddYearsMonthsDays(Current.LockupExpiryDate, Current.LockupDetails);

            if (lockupExpiryDate == Current.LockupExpiryDate)
                throw new Exception("This exception has been thrown to avoid an infinite loop. " +
                    "The next lockup expiry date is  the same as current lockup expiry date. " +
                    "Please check your lockup details");

            Current.LockupExpiryDate = lockupExpiryDate;
            Current.CorrectedLockupExpiryDate = CorrectedDate(Current.LockupExpiryDate, _schedule);
            return true;
        }

        public void Reset()
        {
            _bReset = true;
        }

        public LockupInfo Current { get; private set; }

        public bool AreDefaultVariablesPopulated()
        {
            var success = _feeDetails != null && _feeDetails.Count > 0 && _startDate != DateTime.MinValue;

            if(success)
            {
                foreach (var lockup in _feeDetails)
                {
                    success = lockup.Years + lockup.Months + lockup.Days != 0;
                    if(!success)
                        break;
                }
            }
            return success;
        }
        public bool MoveFirst()
        {

            if (!AreDefaultVariablesPopulated())
                return false;

            _bReset = false;
            _counter = 0;
            Current = new LockupInfo {LockupDetails = _feeDetails[_counter]};
            Current.LockupExpiryDate = AddYearsMonthsDays(_startDate, Current.LockupDetails).AddDays(-1);
            Current.CorrectedLockupExpiryDate = CorrectedDate(Current.LockupExpiryDate, _schedule);
            return true;
        }

        public bool IsWithinLockupPeriod(DateTime date)
        {
            return (_feeDetails == null || _feeDetails.Count == 0 ||
                    _feeDetails[_feeDetails.Count - 1].Type == ELockupType.Rolling ||
                    _feeDetails[_feeDetails.Count - 1].Type == ELockupType.RollingHard || date < _allLockupsExpiryDate);
        }

        private static DateTime CorrectedDate(DateTime date, string schedule)
        {
            switch (schedule)
            {
                case "Business":
                    return date.DayOfWeek == DayOfWeek.Saturday
                               ? date.AddDays(-1)
                               : (date.DayOfWeek == DayOfWeek.Sunday ? date.AddDays(-2) : date);
                default:
                    return date;
            }
        }

        private static DateTime AddYearsMonthsDays(DateTime date, Lockup lockup)
        {
            return DateUtil.AddYearsMonthsDays(date, lockup.Years, lockup.Months, lockup.Days);
        }

        public LockupInfo GetActiveLockup(DateTime asOfDate)
        {
            var expiryDate = _startDate;
            LockupInfo activeLockup = null;
            foreach (var details in _feeDetails)
            {
                var lockup = new LockupInfo { LockupDetails = details };
                lockup.LockupExpiryDate = AddYearsMonthsDays(expiryDate, lockup.LockupDetails).AddDays(-1);
                lockup.CorrectedLockupExpiryDate = CorrectedDate(lockup.LockupExpiryDate, _schedule);
                expiryDate = lockup.LockupExpiryDate;
                if (asOfDate <= expiryDate)
                {
                    activeLockup = lockup;
                    break;
                }
            }

            return activeLockup;
        }
    }

    public class LockupInfo
    {
        public Lockup LockupDetails { get; set; }
        public DateTime LockupExpiryDate { get; set; }
        public DateTime CorrectedLockupExpiryDate { get; set; }
    }
}
