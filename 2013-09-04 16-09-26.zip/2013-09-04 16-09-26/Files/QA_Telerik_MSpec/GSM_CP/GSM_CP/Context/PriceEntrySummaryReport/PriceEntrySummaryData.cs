﻿using System;
using System.Collections.Generic;
using ArtOfTest.WebAii.Controls.HtmlControls;
using Machine.Specifications;

namespace GSM_CP.Context.PriceEntrySummaryReport
{
    public class PriceEntrySummaryData
    {
        

        public PriceEntrySummaryData(HtmlTableRow tableRow)
        {
            ChildList = new List<PriceEntrySummaryData>();

            Id = tableRow.ChildNodes[1].CssClassAttributeValue.Split(' ')[0];
            Instrument = tableRow.Find.ByAttributes<HtmlDiv>("class=DBCellleft DBText").InnerText;
        }

        public PriceEntrySummaryData(string instrument = null,
                                      string pricingCount = null,
                                      string pendAppPricingCount = null,
                                      string rejPricingCount = null,
                                      string appPricingCount = null,
                                      string pendAppAttachementOfPenAppPricingCount = null,
                                      string pendAppAttachementOfAppPricingCount = null,
                                      string rejAttachementOfAppPricingCount = null,
                                      string rejAttachementOfRejPricingCount = null,
                                      string appAttachementOfAppPricingCount = null
            )
        {
            Instrument = instrument;
            PricingCount = pricingCount;
            PendAppPricingCount = pendAppPricingCount;
            AppPricingCount = appPricingCount;
            RejPricingCount = rejPricingCount;
            PendAppAttachementOfPenAppPricingCount = pendAppAttachementOfPenAppPricingCount;
            PendAppAttachementOfAppPricingCount = pendAppAttachementOfAppPricingCount;
            RejAttachementOfAppPricingCount = rejAttachementOfAppPricingCount;
            RejAttachementOfRejPricingCount = rejAttachementOfRejPricingCount;
            AppAttachementOfAppPricingCount = appAttachementOfAppPricingCount;
        }

        #region Properties
        public List<PriceEntrySummaryData> ChildList { get; private set; }

        public string Id { get; set; }
        public string Instrument { get; set; }

        public string PricingCount { get; set; }
        public string PendAppPricingCount { get; set; }
        public string AppPricingCount { get; set; }
        public string RejPricingCount { get; set; }

        public string PendAppAttachementOfPenAppPricingCount { get; set; }
        public string PendAppAttachementOfAppPricingCount { get; set; }
        public string RejAttachementOfAppPricingCount { get; set; }
        public string RejAttachementOfRejPricingCount { get; set; }
        public string AppAttachementOfAppPricingCount { get; set; }
        #endregion

        public void SetMidData(HtmlTableRow tableRow)
        {
            var testId = tableRow.ChildNodes[1].CssClassAttributeValue.Split(' ')[1];
            if (Id != testId)
                throw new Exception("Error is occured in grid parsing");

            PricingCount = tableRow.ChildNodes[1].ChildNodes[0].InnerText;
            PendAppPricingCount = tableRow.ChildNodes[2].ChildNodes[0].InnerText;
            RejPricingCount = tableRow.ChildNodes[3].ChildNodes[0].InnerText;
            AppPricingCount = tableRow.ChildNodes[4].ChildNodes[0].InnerText;

            PendAppAttachementOfPenAppPricingCount = tableRow.ChildNodes[5].ChildNodes[0].InnerText;
            PendAppAttachementOfAppPricingCount = tableRow.ChildNodes[6].ChildNodes[0].InnerText;
            RejAttachementOfAppPricingCount = tableRow.ChildNodes[7].ChildNodes[0].InnerText;
            RejAttachementOfRejPricingCount = tableRow.ChildNodes[8].ChildNodes[0].InnerText;
            AppAttachementOfAppPricingCount = tableRow.ChildNodes[9].ChildNodes[0].InnerText;
        }

        public void ShouldEqual(PriceEntrySummaryData data)
        {
            Instrument.ShouldEqual(data.Instrument);  
            PricingCount.ShouldEqual(data.PricingCount);  
            PendAppPricingCount.ShouldEqual(data.PendAppPricingCount); 
            AppPricingCount.ShouldEqual(data.AppPricingCount); 
            RejPricingCount.ShouldEqual(data.RejPricingCount);

            PendAppAttachementOfPenAppPricingCount.ShouldEqual(data.PendAppAttachementOfPenAppPricingCount);
            PendAppAttachementOfAppPricingCount.ShouldEqual(data.PendAppAttachementOfAppPricingCount);
            RejAttachementOfAppPricingCount.ShouldEqual(data.RejAttachementOfAppPricingCount);
            RejAttachementOfRejPricingCount.ShouldEqual(data.RejAttachementOfRejPricingCount);
            AppAttachementOfAppPricingCount.ShouldEqual(data.AppAttachementOfAppPricingCount); 
        }
    }
}
