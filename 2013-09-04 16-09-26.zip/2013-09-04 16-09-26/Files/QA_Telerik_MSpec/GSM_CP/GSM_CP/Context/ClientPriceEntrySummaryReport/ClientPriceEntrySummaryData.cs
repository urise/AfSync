﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using ArtOfTest.WebAii.Controls.HtmlControls;
using Machine.Specifications;

namespace GSM_CP.Context.ClientPriceEntrySummaryReport
{
    public class ClientPriceEntrySummaryData
    {
        private const string ROW_ID_PATTERN = "DBAFRowId_(.*?)\\s+";

        #region <<< Properties >>>
        public List<ClientPriceEntrySummaryData> ChildList { get; private set; }
        public string Id { get; set; }
        public string Instrument { get; set; }
        public string EnteredPriceCount { get; set; }
        public string PendingApprovalPriceCount { get; set; }
        public string RejectedPriceCount { get; set; }
        public string ApprovedPriceCount { get; set; }
        public string AcceptedPriceClientCount { get; set; }
        public string EditedPriceClientCount { get; set; }
        public string IgnoredPriceClientCount { get; set; }
        public string PendingApprovalAttachementOfPendingApprovalPriceCount { get; set; }
        public string PendingApprovalAttachementOfApprovalPriceCount { get; set; }
        public string RejectedAttachementOfApprovalPriceCount { get; set; }
        public string RejectedAttachementOfRejectedPriceCount { get; set; }
        public string AcceptedAttachementClientCount { get; set; }
        public string ApprovedAttachementOfApprovedPriceCount { get; set; }
        public string IgnoredAttachementClientCount { get; set; }
        public bool Completed { get; private set; }
        #endregion

        #region <<< Constructors >>>
        public ClientPriceEntrySummaryData(HtmlTableRow tableRow)
        {
            ChildList = new List<ClientPriceEntrySummaryData>();

            Id = tableRow.ChildNodes[1].CssClassAttributeValue.Split(' ')[0];
            Instrument = tableRow.Find.ByAttributes<HtmlDiv>("class=DBCellleft DBText").InnerText;
        }
        public ClientPriceEntrySummaryData(string instrument = null,
                                      string enteredPriceCount = null,
                                      string pendingApprovalPriceCount = null,
                                      string rejectedPriceCount = null,
                                      string approvedPriceCount = null,
                                      string acceptedPriceClientCount = null,
                                      string editedPriceClientCount = null,
                                      string ignoredPriceClientCount = null,
                                      string pendingApprovalAttachementOfPendingApprovalPriceCount = null,
                                      string pendingApprovalAttachementOfApprovalPriceCount = null,
                                      string rejectedAttachementOfApprovalPriceCount = null,
                                      string rejectedAttachementOfRejectedPriceCount = null,
                                      string acceptedAttachementClientCount = null,
                                      string approvedAttachementOfApprovedPriceCount = null,
                                      string ignoredAttachementClientCount = null
            )
        {
                Instrument = instrument;
                EnteredPriceCount = enteredPriceCount;
                PendingApprovalPriceCount = pendingApprovalPriceCount;
                RejectedPriceCount = rejectedPriceCount;
                ApprovedPriceCount = approvedPriceCount;
                AcceptedPriceClientCount = acceptedPriceClientCount;
                EditedPriceClientCount = editedPriceClientCount;
                IgnoredPriceClientCount = ignoredPriceClientCount;
                PendingApprovalAttachementOfPendingApprovalPriceCount = pendingApprovalAttachementOfPendingApprovalPriceCount;
                PendingApprovalAttachementOfApprovalPriceCount = pendingApprovalAttachementOfApprovalPriceCount;
                RejectedAttachementOfApprovalPriceCount = rejectedAttachementOfApprovalPriceCount;
                RejectedAttachementOfRejectedPriceCount = rejectedAttachementOfRejectedPriceCount;
                AcceptedAttachementClientCount = acceptedAttachementClientCount;
                ApprovedAttachementOfApprovedPriceCount = approvedAttachementOfApprovedPriceCount;
                IgnoredAttachementClientCount = ignoredAttachementClientCount;
        }

        #endregion

        #region <<< Methods >>>

        public void SetMidData(HtmlTableRow tableRow, bool isIdChecked = true)
        {
            var testId = tableRow.ChildNodes[1].CssClassAttributeValue.Split(' ')[1];
            if(!isIdChecked)
            {
                Id = testId;
            }
            if (Id != testId)
                throw new Exception("Error is occured in grid parsing");
            
            //Id = GetId(tableRow.ChildNodes[1].ChildNodes[0].CssClassAttributeValue);
            EnteredPriceCount = tableRow.ChildNodes[1].ChildNodes[0].InnerText;
            PendingApprovalPriceCount = tableRow.ChildNodes[2].ChildNodes[0].InnerText;
            RejectedPriceCount = tableRow.ChildNodes[3].ChildNodes[0].InnerText;
            ApprovedPriceCount = tableRow.ChildNodes[4].ChildNodes[0].InnerText;
            AcceptedPriceClientCount = tableRow.ChildNodes[5].ChildNodes[0].InnerText;
            EditedPriceClientCount = tableRow.ChildNodes[6].ChildNodes[0].InnerText;
            IgnoredPriceClientCount = tableRow.ChildNodes[7].ChildNodes[0].InnerText;
            PendingApprovalAttachementOfPendingApprovalPriceCount = tableRow.ChildNodes[8].ChildNodes[0].InnerText;
            PendingApprovalAttachementOfApprovalPriceCount = tableRow.ChildNodes[9].ChildNodes[0].InnerText;
            RejectedAttachementOfApprovalPriceCount = tableRow.ChildNodes[10].ChildNodes[0].InnerText;
            RejectedAttachementOfRejectedPriceCount = tableRow.ChildNodes[11].ChildNodes[0].InnerText;
            AcceptedAttachementClientCount = tableRow.ChildNodes[12].ChildNodes[0].InnerText;
            ApprovedAttachementOfApprovedPriceCount = tableRow.ChildNodes[13].ChildNodes[0].InnerText;
            IgnoredAttachementClientCount = tableRow.ChildNodes[14].ChildNodes[0].InnerText;
            Completed = true;
        }

        public string GetId(string cssClass)
        {
            if(string.IsNullOrEmpty(cssClass))
            {
                return string.Empty;
            }
            var rgx = new Regex(ROW_ID_PATTERN, RegexOptions.IgnoreCase);
            return rgx.Matches(cssClass)[0].Groups[1].Value;
        }

        public void ShouldEqual(ClientPriceEntrySummaryData data)
        {
            Instrument.ShouldEqual(data.Instrument);
            EnteredPriceCount.ShouldEqual(data.EnteredPriceCount);
            PendingApprovalPriceCount.ShouldEqual(data.PendingApprovalPriceCount);
            RejectedPriceCount.ShouldEqual(data.RejectedPriceCount);
            ApprovedPriceCount.ShouldEqual(data.ApprovedPriceCount);
            AcceptedPriceClientCount.ShouldEqual(data.AcceptedPriceClientCount);
            EditedPriceClientCount.ShouldEqual(data.EditedPriceClientCount);
            IgnoredPriceClientCount.ShouldEqual(data.IgnoredPriceClientCount);
            PendingApprovalAttachementOfPendingApprovalPriceCount.ShouldEqual(data.PendingApprovalAttachementOfPendingApprovalPriceCount);
            PendingApprovalAttachementOfApprovalPriceCount.ShouldEqual(data.PendingApprovalAttachementOfApprovalPriceCount);
            RejectedAttachementOfApprovalPriceCount.ShouldEqual(data.RejectedAttachementOfApprovalPriceCount);
            RejectedAttachementOfRejectedPriceCount.ShouldEqual(data.RejectedAttachementOfRejectedPriceCount);
            AcceptedAttachementClientCount.ShouldEqual(data.AcceptedAttachementClientCount);
            ApprovedAttachementOfApprovedPriceCount.ShouldEqual(data.ApprovedAttachementOfApprovedPriceCount);
            IgnoredAttachementClientCount.ShouldEqual(data.IgnoredAttachementClientCount);
        }
        #endregion
    }
}
