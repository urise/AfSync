using System.Collections.Generic;
using System.IO;
using GSM_CP.Context.ClientSidePages;
using GSM_CP.Context.CP;
using GSM_CP.Context.General;
using GSM_CP.Context.PriceLockdown;
using GSM_CP.Helpers.Client;
using GSM_CP.Helpers.CP;
using Machine.Specifications;

namespace GSM_CP.Tests.CP.CP_Attachments.CP_AttachmentsDelete
{
    [Subject("TC_CP_ATTDEL_08"), Tags("CP_AttachmentsDelete", "TC_CP_ATTDEL_08")]
    public class TC_CP_ATTDEL_08_Verify_negative_deleting_attachments_on_client_side : GsmCpTest
    {
        protected static DashboardPage DashboardClient;
        protected static AfHeaderPage AfHeader;
        protected static PriceLockdownPage PriceLockdown;

        protected static GsmHeaderPage GsmHeader;
        protected static CentralPricingPage CpPage;
        protected static ApprovalSummaryPage ApprovalSummary;
        protected static AttachmentPopupData AttachPopup;

        protected static readonly string TempDir = Path.GetTempPath();
        protected const string FILE_NAME1 = "file1(CP).pdf";
        protected const string FILE_NAME = "file(CP).pdf";

        private const string PORTFOLIO = "ATTDEL_08";
        private const string NAV_DATE = "01/01/2012";
        private const string FUND = "TC_CP_ATTDEL_08";
        private const string CLASS = "Class_ATTDEL_08";
        private const string FUND_CL = "TC_CP_ATTDEL_08_CL";
        private const string CLASS_CL = "Class_ATTDEL_08_CL";
        private const string LOCKDOWN_TABLE_NAME = FUND_CL + " - " + CLASS_CL;
        private const string EXP_SHOW_UPDATESBUTTON_TEXT1 = "Show Updates from CP (0 prices/1 attachments)";


        private static string _actShowUpdatesbuttonText1,
                              _actShowUpdatesbuttonText2;

        private static List<string> _uploadedFiles1, _uploadedFiles2;

        private Establish _context = () =>
        {
            GsmHeader = new GsmHeaderPage();
            CpPage = new CentralPricingPage();
            ApprovalSummary = new ApprovalSummaryPage();
            AfHeader = new AfHeaderPage();
            PriceLockdown = new PriceLockdownPage();
        };

        private Because _of = () =>
        {
            //new LoginPage().InitialLogin(MainLogin, Clients.Client1, AfPage.PriceLockdown);
            ////select dropdowns
            //PriceLockdown.SetPortfolio(PORTFOLIO);
            //PriceLockdown.SetNavDate(NAV_DATE);
            //PriceLockdown.SetFilter("All");
            //PriceLockdown.ClickShowUpdatesFromCp();
            //var priceTable = PriceLockdown.GetPriceTableByFundName(LOCKDOWN_TABLE_NAME);
            //priceTable.SelectLastPriceToApprove();
            //PriceLockdown.ClickSave();
            //new LoginPage().SwitchClient(Clients.GsmManager, GsmPage.CpPricing);

            new LoginPage().InitialLogin(MainLogin, Clients.GsmManager, GsmPage.CpPricing);
            CpPage.SetEffectiveDate(NAV_DATE);
            CpPage.InitiateSearch(FUND);
            GridHelperBase.GoToFundDetails(FUND);
            CpPage.Init();
            GridHelperBase.ExpandAll();
            GridHelperBase.Init(FUND, CLASS, CPTreeHelper.EMPTY_NAME, "Estimate1");
            GridHelperBase.DeleteAttachments(new List<string> { FILE_NAME1 }, isPricingTab: true);
            CpPage.ClickSave();

            new LoginPage().SwitchClient(Clients.Client1, AfPage.PriceLockdown);
            PriceLockdown.SetPortfolio(PORTFOLIO);
            PriceLockdown.SetNavDate(NAV_DATE);
            PriceLockdown.SetFilter("All");
            PriceLockdown.ClickShowUpdatesFromCp();
            var table = PriceLockdown.GetTableByFundNameWithPaging(LOCKDOWN_TABLE_NAME);
            
            table.AcceptAttachmentUpdates(new List<string> { FILE_NAME1 }, clickAccept:false);

            PriceLockdown.ClickShowUpdatesFromCp();
            _actShowUpdatesbuttonText1= PriceLockdown.GetShowUpdatesBtnText();
            table.Refresh();
            _uploadedFiles1 = table.GetUploadedFilesNames();

            PriceLockdown.ClickShowUpdatesFromCp();
            table.Refresh();
            table.AcceptAttachmentUpdates(new List<string> { FILE_NAME1 });
            
            AfHeaderMenuHelper.NavigateTo(AfPage.MaintainFund);
            AfHeaderMenuHelper.NavigateTo(AfPage.PriceLockdown);

            PriceLockdown.SetPortfolio(PORTFOLIO);
            PriceLockdown.SetNavDate(NAV_DATE);
            PriceLockdown.SetFilter("All");
            table.Refresh();
            _actShowUpdatesbuttonText2 = PriceLockdown.GetShowUpdatesBtnText();
            _uploadedFiles2 = table.GetUploadedFilesNames();
            
        };

        private It Is_correct_text1 = () => _actShowUpdatesbuttonText1.ShouldEqual(EXP_SHOW_UPDATESBUTTON_TEXT1);
        private It All_attachments_are_available_on_client_side = () => _uploadedFiles1.ShouldContainOnly(FILE_NAME1,FILE_NAME);

        private It Is_correct_text2 = () => _actShowUpdatesbuttonText2.ShouldEqual(EXP_SHOW_UPDATESBUTTON_TEXT1);
        private It Updates_performed_correctly = () => _uploadedFiles2.ShouldContainOnly(FILE_NAME1, FILE_NAME);
        private Cleanup _cleanup = () => { };
    }
}