using System.Collections.Generic;
using System.IO;
using GSM_CP.Context.ClientSidePages;
using GSM_CP.Context.CP;
using GSM_CP.Context.General;
using GSM_CP.Context.PriceLockdown;
using GSM_CP.Helpers.Client;
using GSM_CP.Helpers.Common;
using GSM_CP.Helpers.CP;
using Machine.Specifications;

namespace GSM_CP.Tests.CP.CP_Attachments.CP_AttachmentsDelete
{
    [Subject("TC_CP_ATTDEL_09"), Tags("CP_AttachmentsDelete", "TC_CP_ATTDEL_09")]
    public class TC_CP_ATTDEL_09_Verify_correct_appearance_of_attachment_updates_for_recreated_attachment_on_Price_Lockdown : GsmCpTest
    {
        protected static DashboardPage DashboardClient;
        protected static AfHeaderPage AfHeader;
        protected static PriceLockdownPage PriceLockdown;

        protected static GsmHeaderPage GsmHeader;
        protected static CentralPricingPage CpPage;
        protected static ApprovalSummaryPage ApprovalSummary;

        protected static readonly string TempDir = Path.GetTempPath();
        protected const string FILE_NAME1 = "file1(CP).pdf";
        protected const string FILE_NAME = "file(CP).pdf";

        private const string PORTFOLIO = "ATTDEL_09";
        private const string NAV_DATE = "01/01/2012";
        private const string FUND = "TC_CP_ATTDEL_09";
        private const string CLASS = "Class_ATTDEL_09";
        private const string FUND_CL = "TC_CP_ATTDEL_09_CL";
        private const string CLASS_CL = "Class_ATTDEL_09_CL";
        private const string LOCKDOWN_TABLE_NAME = FUND_CL + " - " + CLASS_CL;
        private const string EXP_SHOW_UPDATESBUTTON_TEXT1 = "Show Updates from CP (0 prices/2 attachments)",
                             EXP_SHOW_UPDATESBUTTON_TEXT2 = "Show Updates from CP (0 prices/1 attachments)",
                             EXP_SHOW_UPDATESBUTTON_TEXT3 = "Show Updates from CP (0 prices/0 attachments)";
        

        private static string _actShowUpdatesbuttonText1,
                              _actShowUpdatesbuttonText2,
                              _actShowUpdatesbuttonText3;

        private static List<string> _uploadedFiles1, _uploadedFiles2, _uploadedFiles3;
        public static List<AttachmentInfoClientUpdate> AttachmentInfo;

        private Establish _context = () =>
        {
            GsmHeader = new GsmHeaderPage();
            CpPage = new CentralPricingPage();
            ApprovalSummary = new ApprovalSummaryPage();
            AfHeader = new AfHeaderPage();
            PriceLockdown = new PriceLockdownPage();

            FileHelper.CreateFile(TempDir, FILE_NAME1);
            FileHelper.WriteStringToFile(TempDir, FILE_NAME1, "Version1");
        };

        private Because _of = () =>
        {
            //new LoginPage().InitialLogin(MainLogin, Clients.Client1, AfPage.PriceLockdown);
            //// select dropdowns
            //PriceLockdown.SetPortfolio(PORTFOLIO);
            //PriceLockdown.SetNavDate(NAV_DATE);
            //PriceLockdown.SetFilter("All");
            //PriceLockdown.ClickShowUpdatesFromCp();
            //var priceTable = PriceLockdown.GetPriceTableByFundName(LOCKDOWN_TABLE_NAME);
            //// Select update from CP and click Save (last update)
            //priceTable.SelectLastPriceToApprove();
            //PriceLockdown.ClickSave();
            //new LoginPage().SwitchClient(Clients.GsmManager, GsmPage.CpPricing);

            new LoginPage().InitialLogin(MainLogin, Clients.GsmManager, GsmPage.CpPricing);
            GridHelperBase.Init(FUND, CLASS, CPTreeHelper.EMPTY_NAME, CPTreeHelper.EMPTY_NAME);
            CpPage.SetEffectiveDate(NAV_DATE);
            CpPage.InitiateSearch(FUND);
            GridHelperBase.GoToFundDetails(FUND);
            CpPage.Init();
            GridHelperBase.ExpandAll();
            GridHelperBase.Init(FUND, CLASS, CPTreeHelper.EMPTY_NAME, "Estimate1");
            GridHelperBase.DeleteAttachments(new List<string> { FILE_NAME1 }, isPricingTab: true);
            CpPage.ClickSave();
            GridHelperBase.AttachAllowedFileToPrice(TempDir + FILE_NAME1);
            CpPage.ClickSave();

            new LoginPage().ReLogin(ApproverLogin, Clients.GsmManager, GsmPage.CpApproval);
            ApprovalSummary = new ApprovalSummaryPage();
            ApprovalSummary.InitiateSearch(FUND);
            GridHelperBase.GoToFundDetails(FUND);

            ApprovalSummary.SetEffDate(NAV_DATE);
            GridHelperBase.ExpandAll();
            ApprovalGridHelper.ApproveRejectAttachments(new List<string> { FILE_NAME1 });
            ApprovalSummary.ClickSaveApproval();
            ApprovalSummary.ClickBack();

            new LoginPage().SwitchClient(Clients.Client1, AfPage.PriceLockdown);
            PriceLockdown.SetPortfolio(PORTFOLIO);
            PriceLockdown.SetNavDate(NAV_DATE);
            PriceLockdown.SetFilter("All");
            var table = PriceLockdown.GetTableByFundNameWithPaging(LOCKDOWN_TABLE_NAME);

            _actShowUpdatesbuttonText1 = PriceLockdown.GetShowUpdatesBtnText();
            _uploadedFiles1 = table.GetUploadedFilesNames();
            
            PriceLockdown.ClickShowUpdatesFromCp();
            table.Refresh();
            AttachmentInfo = table.GetAttachmentInfoClientUpdateList();
            table.AcceptAttachmentUpdatesByType(ClientAttachmentUpdateType.DELETE);
            PriceLockdown.ClickSave();

            table.Refresh();
            _actShowUpdatesbuttonText2 = PriceLockdown.GetShowUpdatesBtnText();
            _uploadedFiles3 = table.GetUploadedFilesNames();

            PriceLockdown.ClickShowUpdatesFromCp();
            table.Refresh();
            table.AcceptAttachmentUpdatesByType(ClientAttachmentUpdateType.NEW);
            PriceLockdown.ClickSave();

            _actShowUpdatesbuttonText3 = PriceLockdown.GetShowUpdatesBtnText();
            table.Refresh();
            _uploadedFiles2 = table.GetUploadedFilesNames();
        };

        private It Is_accept_checkbox_enabled_for_remove_update = () => AttachmentInfo[0].IsAcceptEnabled.ShouldBeFalse();
        private It Is_accept_checkbox_enabled_for_create_update = () => AttachmentInfo[1].IsAcceptEnabled.ShouldBeTrue();

        private It Is_correct_update_type_for_recreated_attachment = () => AttachmentInfo[0].UpdateType.ShouldEqual(ClientAttachmentUpdateType.NEW);
        private It Is_correct_update_type_for_deleted_attachment = () => AttachmentInfo[1].UpdateType.ShouldEqual(ClientAttachmentUpdateType.DELETE);

        private It Is_correct_text1 = () => _actShowUpdatesbuttonText1.ShouldEqual(EXP_SHOW_UPDATESBUTTON_TEXT1);
        private It Correct_attachment1_is_available_on_client_side = () => _uploadedFiles1.ShouldContainOnly(FILE_NAME1,FILE_NAME);

        private It Is_correct_text2 = () => _actShowUpdatesbuttonText2.ShouldEqual(EXP_SHOW_UPDATESBUTTON_TEXT2);
        private It No_attachments_are_available_on_client_side = () => _uploadedFiles3.ShouldContainOnly(FILE_NAME);

        private It Is_correct_text3 = () => _actShowUpdatesbuttonText3.ShouldEqual(EXP_SHOW_UPDATESBUTTON_TEXT3);
        private It Correct_attachment2_is_available_on_client_side = () => _uploadedFiles2.ShouldContainOnly(FILE_NAME1,FILE_NAME);

        private Cleanup _cleanup = () => { };
    }
}