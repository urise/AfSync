﻿using System;
using ArtOfTest.Common.UnitTesting;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.UIControls.Context;
using IFS.AF.UIControls.Helpers;
using Machine.Specifications;

namespace IFS.AF.UIControls.Tests.NAVCloseVsLiveModifyAmount

{
    public class ModifyTransferIfsToIfsAmount : EstablishModifyAmount

    {
        protected static BaseTransaction.Transaction ReturnEdition;
        protected static BaseTransaction.Transaction InTransactionInActivityReport, InTransaction;
        protected static string ToPortfolio;
        
        private static string _toDate, _transactionDate, _lockdownDate, _sharesIn, _sharesOut;
        
        Establish _context = () =>

        {
            Edition = new BaseTransaction.Transaction
            {
                AmountToBePaid = StringTransform.ConvertToCurrencyNumber("100000")
            };
            
            _toDate = "2/28/2010 (L)";
            _transactionDate = "2/1/2010";
            _lockdownDate = "2/28/2010";

            TransactionReportLiveValues = new TransactionReport.TransactionReportValues();
            TransactionReportNavCloseValues = new TransactionReport.TransactionReportValues();
            ExpectedTransactionReportLiveValues = new TransactionReport.TransactionReportValues
            {
                Quantity = "(91.43398)",
                LocalMv = "(100,000.00)",
                BaseMv = "(100,000.00)",
                LocalCost = "(99,009.90)",
                BaseCost = "(99,009.90)"
            };
            ExpectedTransactionReportNavCloseValues = new TransactionReport.TransactionReportValues
            {
                Quantity = "(180.00000)",
                LocalMv = "(196,863.35)",
                BaseMv = "(196,863.35)",
                LocalCost = "(194,914.21)",
                BaseCost = "(194,914.21)"
            };
            
            IaAndFofReportLiveValues = new IafofReport.IaAndFofReportValues();
            IaAndFofReportNavCloseValues = new IafofReport.IaAndFofReportValues();
            ExpectedIaAndFofReportLiveValues = new IafofReport.IaAndFofReportValues
            {
                CapitalActivity = "(100,000.00)",
                ShareActivity = "(91.43398)",
                OpeningShares = "18,378.23047",
                EndingMv = "20,301,000.00",
                OpeningMv = "20,100,000.00",
                CurrentMonthUpdatedIncome = "201,000.00",
                CurrentMonthNavCloseIncome = "201,000.00",
                CurrentCost = "19,900,990.10"
            };
            ExpectedIaAndFofReportNavCloseValues = new IafofReport.IaAndFofReportValues
            {
                CapitalActivity = "(196,863.35)",
                ShareActivity = "(180.00000)",
                OpeningShares = "18,289.66445",
                EndingMv = "20,203,168.02",
                OpeningMv = "20,003,136.65",
                CurrentMonthUpdatedIncome = "200,031.37",
                CurrentMonthNavCloseIncome = "200,031.37",
                CurrentCost = "19,805,085.79"
            };

        };

        Because _of = () =>
        {
            Dashboard = UserAction.LoginAsAccountant(TestData.Client, Portfolio);

            //Pretest cleanup
            SetInitialAmount();

            Dashboard.VerifyPresetDashboard(DashboardValuesExpected);
            
            ModifyTransactionAndGetResult();

            #region Getting Live and NAV Close values from Dashboard
            Dashboard.PortfolioName.Select(Portfolio);
            BrowserPool.WaitUntilPageLoaded();
            Dashboard.ToDate.Select(_toDate);
            BrowserPool.AjaxPostBackWait();
            Dashboard.Expand(BaseFund);
            BrowserPool.WaitUntilPageLoaded();
            
            //Getting the actual Dashboard values for Live View
            for (int i = 0; i < DashboardValuesGoldenLive.GetLength(0); i++)
            {
                DashboardValuesActualLive[i, 1] = Dashboard.GetValue(DashboardValuesGoldenLive[i, 0], Header.MARKET_VALUE);
                DashboardValuesActualLive[i, 2] = Dashboard.GetValue(DashboardValuesGoldenLive[i, 0], Header.CURRENT_SHARES);
            }

            //Switching to NAV Close View
            Dashboard.SwitchToNAVClose();
            Dashboard.Expand(BaseFund);
            //Getting the Instrument ID
            TestData.InstrumentId = Dashboard.GetInstrumentId(InvestableFund);
            //Getting the actual Dashboard values for NAV Close View
            for (int i = 0; i < DashboardValuesGoldenNAVClose.GetLength(0); i++)
            {
                DashboardValuesActualNAVClose[i, 1] = Dashboard.GetValue(DashboardValuesGoldenNAVClose[i, 0], Header.MARKET_VALUE);
                DashboardValuesActualNAVClose[i, 2] = Dashboard.GetValue(DashboardValuesGoldenNAVClose[i, 0], Header.CURRENT_SHARES);
            }
            #endregion

            TransactionRep = Dashboard.GoToTransactionReport();
            TransactionRep.GetValues(InvestableFund, TestData.InstrumentId, ref TransactionReportLiveValues, ref TransactionReportNavCloseValues);
            TransactionRep.Close();

            //Needed to be refactored
            IaFofRep = AsPage<IafofReport>();
            IaFofRep.GetValues(InvestableFund, _transactionDate, _lockdownDate, ref IaAndFofReportLiveValues, ref IaAndFofReportNavCloseValues);

            _sharesOut = UpdatedTransactionActivityReport.SharesQty;
            UpdatedTransactionActivityReport.SharesQty = _sharesOut.Substring(0, 5);

            _sharesIn = InTransactionInActivityReport.SharesQty;
            InTransactionInActivityReport.SharesQty = _sharesIn.Substring(0, 5);
          };
        Cleanup _clean = () =>
        {
            try
            {
                Dashboard.MakeLogout();
                UserAction.LoginAsAdmin(TestData.Client, Portfolio);
                SetInitialAmount();
            }
            catch (Exception ex)
            {
                Assert.IsNotNull(ex.Message, ex.Message);
            }
        };

        protected static void SetInitialAmount()
        {
            ActivityReport = Dashboard.GoToViewActivity(StartTransaction.BaseFund, StartTransaction.InvestableFund);
            var returnTransaction = EditTransaction(UpdatedTransaction, "Getting values back", ReturnEdition);
            ActivityReport.Close();
        }
        protected static void ModifyTransactionAndGetResult()
        {
            StartTransactionActivityReport = GetStartTransactionFromActivityReport();
            var transferTransaction = EditTransaction(StartTransaction, "Amount Update", Edition);
            UpdatedTransaction = transferTransaction.TransactionSDO;
            UpdatedTransactionActivityReport = ActivityReport.GetTransactionInfo(UpdatedTransaction);

            InTransaction = transferTransaction.TransactionSRI;
            ActivityReport.Close();
            Dashboard.PortfolioName.Select(ToPortfolio);
            BrowserPool.WaitUntilPageLoaded();

            ActivityReport = Dashboard.GoToViewActivity(InTransaction.BaseFund, InTransaction.InvestableFund);
            InTransactionInActivityReport = ActivityReport.GetTransactionInfo(InTransaction);
            ActivityReport.Close();
        }

        protected static TransferIFStoIFS EditTransaction(BaseTransaction.Transaction oldTransaction, string comment, BaseTransaction.Transaction edition)
        {
            //ActivityReport.EditTransaction(oldTransaction);
            ActivityReport.InvokeTransactionByIndex(2); //transaction is opened by index to make pretest cleanup possible
            //Transfer IFS to IFS popup
            var browserId = BrowserPool.IePopupOpen(PageUrl.ALLOCATION_TRANSFER, TransferPage.TITLE);
            var transferIFStoIFS = AsPage<TransferPage>();
            transferIFStoIFS.Comments.Text = comment;
            ToPortfolio = transferIFStoIFS.ToPortfolioSelector.SelectedOption.Text;
            var resultTransaction = transferIFStoIFS.AllocationTransferIFSToIFS(null, edition.AmountToBePaid);
            BrowserPool.IePopupClose(browserId.ClientId);

            return resultTransaction;
        }
    }
    
}
