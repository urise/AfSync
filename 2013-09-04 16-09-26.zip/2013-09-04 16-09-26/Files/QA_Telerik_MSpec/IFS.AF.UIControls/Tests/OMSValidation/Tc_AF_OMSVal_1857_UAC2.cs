﻿using System;
using ArtOfTest.Common.UnitTesting;
using IFS.AF.BaseContext;
using IFS.AF.UIControls.Context;
using IFS.AF.UIControls.Helpers;
using Machine.Specifications;

/* ALPHA-1857 OMS - Base Fund trade orders 
* UAC2 verify trade order without class specified can't be approved
* Created by: NKudlai
*/

namespace IFS.AF.UIControls.Tests.OMSValidation
{
    [Subject("Tc_AF_OMSVal_1857_UAC2"), Tags("OMSValidation", "Tc_AF_OMSVal_1857_UAC2")]
    public class Verify_UAC2_Trade_order_without_class_specified_cant_be_approved : AfWebTest
    {
        protected static TradeActivityPage TradeActivity;
        protected static DashboardPage Dashboard;
        protected static TradeSubscriptionPage TradeSubscription;
        protected static TransactionsPage Transactions;
        protected static ActivityReportPage ActivityReport;

        protected const string TRADE_DATE = "08/01/2013";
        protected const string TRANSACTION_ID = "OMSClass2";
        private static BaseTransaction.Transaction _tradeInViewActivity;
        private static SubscriptionFields2Pass _subTradeOrderValues;
        protected static OmsTradeTransaction SubTradeOrderTransaction;

        private static string _alertApproveText;
        private static bool _isTradeOrderPresentAfterApproveTry;

        Establish _context = () =>
        {
            
            #region Test data and trades
            TestData = new TestDataSet()
            {
                Client = "Automation OMS Validation",
                Portfolio = "OMS Class Approve",
                BaseFund = "OMSClassApproveFund",
                InvestableFund = "OMSClassApproveFund - A - 1",
                Currency = "USD",
                //FundIssueDate = "01/01/2010",
                Clearer = "OMS Class Clearer"
            };

            _subTradeOrderValues = new SubscriptionFields2Pass
            {
                FundField = "Unassigned",
                EffectiveDate = TRADE_DATE,
                PaymentDate = TRADE_DATE,
                DocumentsDate = TRADE_DATE,
                Amount = "1,000,000.00",
                Clearer = TestData.Clearer,
                TransactionId = TRANSACTION_ID,
                Type = TransactionType.TRADE_ORDER_SUBSCRIPTION,
                BkdTypes = SubscriptionFields2Pass.BookedTypes.Amount,
                ActTypes = OmsTradeTransaction.ActionTypes.Submit
            };

            _tradeInViewActivity = new BaseTransaction.Transaction()
            {
                EffectiveDate = _subTradeOrderValues.EffectiveDate,
                Type = TransactionType.ADDITIONAL_SUBSCRIPTION,
                AmountToBePaid = _subTradeOrderValues.Amount,
                Currency = TestData.Currency
            };

            SubTradeOrderTransaction = new OmsTradeTransaction()
            {
                Security = TestData.BaseFund,
                EffectiveDate = _subTradeOrderValues.EffectiveDate,
                TradePaymentDate = _subTradeOrderValues.PaymentDate,
                Amount = _subTradeOrderValues.Amount,
                Portfolio = TestData.Portfolio,
                TradeType = TransactionType.TRADE_ORDER_SUBSCRIPTION,
            };

            #endregion

            Dashboard = UserAction.LoginAsAdmin(TestData.Client, TestData.Portfolio);
            Assert.IsTrue(Dashboard.IsFundVisible(TestData.BaseFund),
                "Pretest data are incorrect, please add initial subscription");
            TradeActivity = Dashboard.GoToTradeActivity();
            TradeActivity.SelectPortfolio(TestData.Portfolio);
            TradeActivity.SetFromDate(TRADE_DATE);
            if (!TradeActivity.FindTransaction(SubTradeOrderTransaction))
            {
                Dashboard = Dashboard.GoToDashboard();
                TradeSubscription = Dashboard.GoToCreateBaseFundTransaction(TestData.BaseFund,
                    TransactionType.SUBSCRIPTION, TransactionType.TRADE_ORDER_SUBSCRIPTION) as TradeSubscriptionPage;
                SubTradeOrderTransaction = TradeSubscription.
                    TradeSubscription(_subTradeOrderValues, TestData.Portfolio, TestData.BaseFund);
            }

            Dashboard.MakeLogout();
        };

        private Because _of = () =>
        {
            Dashboard = UserAction.LoginAsOmsApprover(TestData.Client, TestData.Portfolio);
            TradeActivity = Dashboard.GoToTradeActivity();
            TradeActivity.SelectPortfolio(TestData.Portfolio);
            TradeActivity.SetFromDate(TRADE_DATE);

            _alertApproveText = TradeActivity.ApproveTransactionErrorHandle(ref SubTradeOrderTransaction);
            _isTradeOrderPresentAfterApproveTry = TradeActivity.FindTransaction(SubTradeOrderTransaction);

        };

        It _1_Trade_order_cant_be_approved = () =>
            _alertApproveText.ShouldEqual(TestData.BaseFund+
            " - Trade Order cannot be approved unless the class/series has been specified\n");

        It _2_Trade_order_should_be_present_after_trade_order_false_approve_try = () =>
            _isTradeOrderPresentAfterApproveTry.ShouldBeTrue();


        private Cleanup _clean = () =>
        {
            try
            {
                if ((String.IsNullOrEmpty(_alertApproveText)))
                {
                    Dashboard = Dashboard.GoToDashboard();
                    ActivityReport = Dashboard.GoToViewActivity(TestData.BaseFund, TestData.InvestableFund);
                    if (ActivityReport.TransactionExists(_tradeInViewActivity))
                        ActivityReport.DeleteTransaction(_tradeInViewActivity);
                    ActivityReport.Close();
                }
            }
            catch (Exception)
            {
                
                throw;
            }

        };
    }
}
