﻿//UAC3
using System;
using ArtOfTest.Common.UnitTesting;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.UIControls.Helpers;
using Machine.Specifications;

namespace IFS.AF.UIControls.Tests.CancelledTradesOnTransactionReport
{
    [Subject("AF_CT_03_ClientCancelledTrade"), Tags("AF_CT_03_ClientCancelledTrade", "CancelTrades")]
    public class UAC3_ClientCancelledTrade : EstablishCancelTrades
    {
        protected static BaseTransaction.Transaction FirstSubTransactionData, FirstSubTransaction, CancelledFirstSubTransaction;
        protected static BaseTransaction.Transaction SecondSubTransactionData, SecondSubTransaction, CancelledSecondSubTransaction;

        Establish _context = () =>
        {
            FirstSubTransactionData = new BaseTransaction.Transaction
            {
                BaseFund = TestData.BaseFund,
                EffectiveDate = "01/02/2012",
                InvestableFund = TestData.InvestableFund,
                Type = TransactionType.SUBSCRIPTION,
                AmountToBePaid = StringTransform.ConvertToCurrencyNumber("2000000"),
                Currency = "USD"
             };

            SecondSubTransactionData = new BaseTransaction.Transaction
            {
                BaseFund = TestData.BaseFund,
                EffectiveDate = "02/01/2012",
                InvestableFund = TestData.InvestableFund,
                Type = TransactionType.ADDITIONAL_SUBSCRIPTION,
                AmountToBePaid = StringTransform.ConvertToCurrencyNumber("3000000"),
                Currency = "USD"
            };
        };

        Because _of = () =>
        {
            UserAction.LoginAsAdmin(TestData.Client, TestData.Portfolio);
            //cleanup
            TransactionAction.CreateFirstTradeSubscription(FirstSubTransactionData); 
            Dashboard.Expand(BaseFund);
            Dashboard.DeleteTransactionsForFund(InvestableFund);
            //test
            FirstSubTransaction = TransactionAction.CreateFirstTradeSubscription(FirstSubTransactionData);
            SecondSubTransaction = TransactionAction.CreateTradeSubscription(SecondSubTransactionData);
            CancelledSecondSubTransaction = TransactionAction.CancelTradeSubscription(SecondSubTransaction);
            CancelledSecondSubTransaction.Type = TransactionType.SUBSCRIPTION;
            CancelledFirstSubTransaction = TransactionAction.CancelTradeSubscription(FirstSubTransaction, false);

            var report = Dashboard.GoToHistoricalTransactionReport();
            EffectiveReportTransactionList = report.GetAllTransactionsFromHistoricalTransactionReport(InvestableFund, FirstSubTransaction.EffectiveDate, SecondSubTransaction.EffectiveDate);
            
        };

        It report_should_show_1_row = () => EffectiveReportTransactionList.Count.ShouldEqual(1);
        Behaves_like<first_transaction_should_be_in_first_row_and_has_expected_format> original_version_should_be_in_first_row;
        
        Cleanup _clean = () =>
        {
            try
            {
                //Dashboard.ShowFullyRedeemed();
                TransactionAction.CreateFirstTradeSubscription(FirstSubTransactionData); 
                Dashboard.Expand(BaseFund);
                Dashboard.DeleteTransactionsForFund(InvestableFund);
            }
            catch (Exception ex)
            {
                Assert.IsNotNull(ex.Message, ex.Message);
            }
        };

        [Behaviors]
        public class first_transaction_should_be_in_first_row_and_has_expected_format
        {
            It effective_date = () => EffectiveReportTransactionList[0].EffectiveDate.ShouldEqual(CancelledSecondSubTransaction.EffectiveDate);
            It Transaction_Type = () => EffectiveReportTransactionList[0].TransactionType.ShouldEqual(CancelledSecondSubTransaction.Type);
            It Quantity = () => EffectiveReportTransactionList[0].Quantity.ShouldEqual(CancelledSecondSubTransaction.SharesQty);
            It Price = () => EffectiveReportTransactionList[0].VerifyPrice(CancelledSecondSubTransaction.Price);
            It font_is_grey = () => EffectiveReportTransactionList[0].VerifyFontColor(SpecificGray);
            It font_is_italic = () => EffectiveReportTransactionList[0].VerifyFontStyle("italic");
        }
    }
}