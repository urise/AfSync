﻿using System;
using System.Collections.Generic;
using ArtOfTest.Common.UnitTesting;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.UIControls.Context;
using IFS.AF.UIControls.Helpers;
using IFS.AF.UIControls.Tests.Behaviors;
using IFS.AF.UIControls.Tests.GLS;
using Machine.Specifications;

namespace IFS.AF.UIControls.Tests.Subscriptions
{
    [Subject("AF_Sub_1_3a"), Tags("Subscription", "AF_Sub_1_3a")]
    public class AF_Sub_1_3a : EstablishGLSParent
    {

        protected static BaseTransaction.Transaction StartTransactionViewActivity;
        protected static BaseTransaction.Transaction edition;
        protected static BaseTransaction.Transaction oldEdition;
        private static string _allocationID;

        Establish _context = () =>
        {
            TestData = new TestDataSet()
            {
                Client = "Automation Subscription",
                Portfolio = "Automation Subscription 3",
                BaseFund = "Auto Fund 1",
                InvestableFund = "Auto Fund 1 - Class Fund 1",
                Currency = "USD",
                FundIssueDate = "01/01/2006",
                Clearer = "Automation Clearer 1"
            };

            EtalonXml1 = @"\XML Etalons\Subscription1\1 - inanyc5021.dev.imsi.com_11.xml";
            EtalonXml2 = @"\XML Etalons\Subscription1\2 - inanyc5021.dev.imsi.com_14.xml";

            /*MV, CS, CN*/
            DashboardPrepareValuesExpected = new[,] 
            {   
                //{"Auto Fund - LLC", "1,000,000.0000","0.00040", "400.00"},
                //{"Auto Fund - Partnership", "1,000.0000","1.40000", "1,400.00"},
                {"Auto Fund 1", "1,000.0000","3.00000", "3,000.00"}		
            };
            DashboardValuesActual = new string
               [DashboardPrepareValuesExpected.GetLength(0),
               DashboardPrepareValuesExpected.GetLength(1)];

           
            BaseFund = TestData.BaseFund;
            InvestableFund = TestData.InvestableFund;


            StartTransaction = new BaseTransaction.Transaction
            {
                BaseFund = TestData.BaseFund,
                EffectiveDate = "02/01/2007",
                InvestableFund = TestData.InvestableFund,
                Type = TransactionType.SUBSCRIPTION,
                AmountToBePaid = StringTransform.ConvertToCurrencyNumber("5000"),
                Clearer = TestData.Clearer,
                Currency = "USD",
            };
            edition = new BaseTransaction.Transaction
                {
                    Type = TransactionType.SUBSCRIPTION,
                    AmountToBePaid = StringTransform.ConvertToCurrencyNumber("7000"),
                    Comment = "UPDATE"
                };
            oldEdition = new BaseTransaction.Transaction
            {
                Type = TransactionType.SUBSCRIPTION,
                AmountToBePaid = StartTransaction.AmountToBePaid,
                Comment = "Return to back"
            };
            //_investableFund = StringTransform.GetTailInvestableFund(_firstTransaction.InvestableFund, _firstTransaction.BaseFund);
        };

        Because _of = () =>
            {
                Dashboard = UserAction.LoginAsAdmin(TestData.Client, TestData.Portfolio);

                Dashboard.Expand(BaseFund);
                if (Dashboard.GetValue(StartTransaction.InvestableFund, Header.CURRENT_SHARES) != "3.00000")
                // Dashboard.VerifyPresetDashboard(DashboardPrepareValuesExpected);
                {
                    
                    TransactionAction.EditTransaction(new BaseTransaction.Transaction
                    {
                        BaseFund = StartTransaction.BaseFund,
                        InvestableFund = StartTransaction.InvestableFund,
                        EffectiveDate =StartTransaction.EffectiveDate,
                        Type = TransactionType.SUBSCRIPTION,
                        AmountToBePaid = edition.AmountToBePaid,
                        Currency = StartTransaction.Currency
                    }, oldEdition,
                                                               out StartTransactionActivityReport,
                                                               out UpdatedTransactionActivityReport);
                };
                
                CurrentSharesBeforeTransaction = Dashboard.GetValue(StartTransaction.InvestableFund, Header.CURRENT_SHARES);
            MarketValueBeforeTransaction = Dashboard.GetValue(StartTransaction.InvestableFund, Header.MARKET_VALUE);
            TestData.InstrumentId = Dashboard.GetInstrumentId(StartTransaction.InvestableFund);

            //Dashboard.GoToViewActivity(TestData.BaseFund, TestData.InvestableFund);
            //BrowserId = BrowserPool.IePopupOpen(PageUrl.ACTIVITY_REPORT, ActivityReportPage.TITLE);
            //ActivityReport = AsPage<ActivityReportPage>();
            //_allocationID = ActivityReport.GetAllocationId(_firstTransaction);
            //StartTransactionActivityReport = ActivityReport.GetTransactionInfo(_firstTransaction);
            ////edit transaction
            //ActivityReport.EditTransaction(_firstTransaction);
            ////Subscription popup
            //var browserId = BrowserPool.IePopupOpen(PageUrl.ALLOCATION_SUBSCRIPTION, SubscriptionPage.TITLE);
            //Subscription = AsPage<SubscriptionPage>();
            //Subscription.Comments.Text = "UPDATE";
            //UpdatedTransaction = Subscription.AllocationSubscription("7000").Transaction;
            //BrowserPool.IePopupClose(browserId.ClientId);

            //UpdatedTransactionActivityReport = ActivityReport.GetTransactionInfo(UpdatedTransaction);
            //ActivityReport.Close();
            //BrowserPool.IePopupClose(BrowserId.ClientId);
            UpdatedTransaction = TransactionAction.EditTransaction(StartTransaction,
                                                                   edition,
                                                               out StartTransactionActivityReport,
                                                               out UpdatedTransactionActivityReport);
            Dashboard.Expand(BaseFund);
            CurrentSharesAfterUpdateTransaction = Dashboard.GetValue(StartTransaction.InvestableFund, Header.CURRENT_SHARES);
            MarketValueAfterUpdateTransaction = Dashboard.GetValue(StartTransaction.InvestableFund, Header.MARKET_VALUE);

            Dashboard.GoToTransactions();
            Transactions.SelectTranscationsByInstrumentId(TestData.Client, TestData.InstrumentId, TransactionsPage.CANCEL_REBOOK_TRANSACTION_TYPE);
            Transactions.TransactionsGrid.Rows[0].BtnSonicMessage.MouseClick();
            XmlMessage1 = GetXMLMessage();

            Transactions.TransactionsGrid.Rows[1].BtnSonicMessage.MouseClick();
            XmlMessage2 = GetXMLMessage();
            Dashboard.GoToDashboard();
            
        };
        private Behaves_like<updated_transaction_correctly_appears_in_activity_report>
   updated_subscription_correctly_appears_in_activity_report;

        It XML_value1_should_match_as_expected_file = () =>
                                                AfXmlComparer.IsEqualForNodes(
                                                    CurrentDirectoryPath + EtalonXml1,
                                                    XmlMessage1, new List<string> { XPathMessages.TRADE_TXN_CODE_XPATH }).ShouldBeTrue();
        It XML_value2_should_match_as_expected_file = () =>
                                        AfXmlComparer.IsEqualForNodes(
                                            CurrentDirectoryPath + EtalonXml2,
                                            XmlMessage2, new List<string> { XPathMessages.TRADE_TXN_CODE_XPATH }).ShouldBeTrue();
        
        Cleanup _clean = () =>
        {
            try
            {
                TransactionAction.EditTransaction(UpdatedTransaction, oldEdition,
                                                               out StartTransactionViewActivity,
                                                               out UpdatedTransactionActivityReport);
            }
            catch (Exception ex)
            {
                Assert.IsNotNull(ex.Message, ex.Message);
            }
        };
    }
}
