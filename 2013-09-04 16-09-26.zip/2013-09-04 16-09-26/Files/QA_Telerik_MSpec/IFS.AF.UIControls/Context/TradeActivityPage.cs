﻿using System;
using System.Collections.Generic;
using ArtOfTest.Common.UnitTesting;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Core;
using IFS.AF.BaseContext;
using IFS.AF.BaseContext.Helpers;
using IFS.AF.UIControls.Helpers;
using Machine.Specifications.Annotations;

namespace IFS.AF.UIControls.Context
{

    [UsedImplicitly]
    public class TradeActivityPage : BaseFindManager
    {
        private bool _isOnlyOneRow;
        private TradeActivityGrid _tradeActivityGrid;

        public TradeActivityPage(Find find)
            : base(find)
        { }
        
        #region IDs
        //Page properties
        public const string TITLE = "Trade Activity";
        private const string PORTFOLIO_DROPDOWN_ID = "~ddlPortfolios";
        private const string TRADE_ACTIVITY_TBL_ID = "~bgvTradeActvity";
        private const string FROM_DATE_DATE_CONTROL = "~dpFromDate";
        private const string TO_DATE_DATE_CONTROL = "~dpToDate";
        private const string BTN_EXPORT_CONTROL = "~btnExport";
        private const string TYPE_DROPDOWN_ID = "~ddlTransactionType";
        private const string STATUS_DROPDOWN_ID = "~ddlStatus";
        private const string APPROVAL_BTN_ID = "~btnBulkApproval";
        private const string CANCEL_BTN_ID = "~btnCancel";
        private const string APPROVE_REJECT_BTN_ID = "~btnApproveReject";
        private const string CANCEL_APPROVE_BTN_ID = "~tbnAppCancel";
        private const string APPROVE_COMMENT_TXT_ID = "~txtApprovalComment";
        private const string DELETE_COMMENT_TXT_ID = "~txtReasonForDelete";
        private const string EDIT_COMMENT_TXT_ID = "~txtReasonForEdit";
        private const string DELETE_BTN_ID = "~btnDelete";
        private const string EDIT_BTN_ID = "~btnEdit";
        //
        #endregion

        #region Controls

        private HtmlTable TradeActivityTable
        {
            get
            {
                return ElementManager.GetElementById(TRADE_ACTIVITY_TBL_ID).As<HtmlTable>();
            }
        }

        private HtmlSelect PortfolioDropdown
        {
            get
            {
                return ElementManager.GetElementById(PORTFOLIO_DROPDOWN_ID).As<HtmlSelect>();
            }
        }

        private HtmlInputText FromDateBox
        {
            get
            {
                return ElementManager.GetElementById(FROM_DATE_DATE_CONTROL).As<HtmlInputText>();
            }
        }

        private HtmlInputText ToDateBox
        {
            get
            {
                return ElementManager.GetElementById(TO_DATE_DATE_CONTROL).As<HtmlInputText>();
            }
        }

        private HtmlSelect TypeDropDown
        {
            get
            {
                return ElementManager.GetElementById(TYPE_DROPDOWN_ID).As<HtmlSelect>();
            }
        }

        private HtmlSelect StatusDropDown
        {
            get
            {
                return ElementManager.GetElementById(STATUS_DROPDOWN_ID).As<HtmlSelect>();
            }
        }
        public HtmlInputButton ApproveButton
        {
            get
            {
                return ElementManager.GetElementById(APPROVAL_BTN_ID).As<HtmlInputButton>();
            }
        }
        public HtmlInputButton CancelButton
        {
            get
            {
                return ElementManager.GetElementById(CANCEL_BTN_ID).As<HtmlInputButton>();
            }
        }

        public HtmlInputSubmit ApproveRejectCommentButton
        {
            get
            {
                return ElementManager.GetElementById(APPROVE_REJECT_BTN_ID).As<HtmlInputSubmit>();
            }
        }
        private HtmlInputSubmit DeleteButton
        {
            get
            {
                return ElementManager.GetElementById(DELETE_BTN_ID).As<HtmlInputSubmit>();
            }
        }
        private HtmlInputSubmit EditButton
        {
            get
            {
                return ElementManager.GetElementById(EDIT_BTN_ID).As<HtmlInputSubmit>();
            }
        }
        private HtmlInputButton CancelCommentButton
        {
            get
            {
                return ElementManager.GetElementById(CANCEL_APPROVE_BTN_ID).As<HtmlInputButton>();
            }
        }
        private HtmlInputImage ExportToExcelBtn
        {
            get
            {
                return ElementManager.GetElementById(BTN_EXPORT_CONTROL).As<HtmlInputImage>();
            }
        }
        public HtmlTextArea CommentApprove
        {
            get
            {
                return ElementManager.GetElementById(APPROVE_COMMENT_TXT_ID).As<HtmlTextArea>();
            }
        }
        public HtmlTextArea CommentDelete
        {
            get
            {
                return ElementManager.GetElementById(DELETE_COMMENT_TXT_ID).As<HtmlTextArea>();
            }
        }
        private HtmlTextArea CommentEdit
        {
            get
            {
                return ElementManager.GetElementById(EDIT_COMMENT_TXT_ID).As<HtmlTextArea>();
            }
        }
        public TradeActivityGrid TradeActGrid
        {
            get { return _tradeActivityGrid ?? (_tradeActivityGrid = new TradeActivityGrid(TradeActivityTable)); }
        }

        #region Set Properties

        public void SelectTransactionType(string value)
        {
            TypeDropDown.Select(value);
        }
        public void SelectStatus(string text)
        {
            StatusDropDown.Select(text);
        }

        public void SelectPortfolio(string text)
        {
            PortfolioDropdown.Select(text);
        }
        
        public void SetFromDate(DateTime dateTime)
        {
            FromDateBox.TypeText(dateTime.ToString(DateTransform.CustomDatePattern));
        }

        public void SetFromDate(string value)
        {
            FromDateBox.TypeText(value);
        }

        public void SetToDate(DateTime dateTime)
        {
            ToDateBox.TypeText(dateTime.ToString(DateTransform.CustomDatePattern));
        }

        public void SetToDate(string value)
        {
            ToDateBox.TypeText(value);
        }

        public void ExportToExcel(string exportFileName)
        {
            DialogMonitoring.InitDownloadHandling(exportFileName);
            DialogMonitoring.StartMonitoring();
            ExportToExcelBtn.ButtonClick();
            DialogMonitoring.WaitForDownloadToComplete();
            DialogMonitoring.RemoveDownloadHandling();
        }

        #endregion
        #endregion

        #region methods

        private TradeActivityGrid.ActivityGridRow GetRowByTransaction(OmsTradeTransaction transaction)
        {
            var date = transaction.TradeType == TransactionType.TRADE_ORDER_SUBSCRIPTION
                           ? transaction.EffectiveDate
                           : transaction.TradePaymentDate;
            var amount = transaction.TradeType == TransactionType.TRADE_ORDER_SUBSCRIPTION
                           ? StringTransform.ConvertToCurrencyNumber(transaction.Amount)
                           : transaction.Amount; 
            var rows = TradeActivityTable.Find.AllByExpression<HtmlTableRow>
                (new HtmlFindExpression("InnerText=^" + date + transaction.Security +
                   transaction.TradeType + transaction.Portfolio + amount + transaction.Quantity + transaction.Status));
            Assert.IsNotNull(rows);
            Assert.IsTrue(rows.Count.Equals(1));
            return GetActivityRow(rows[0]);
        }

        private static TradeActivityGrid.ActivityGridRow GetActivityRow(HtmlTableRow _row)
        {
            return new TradeActivityGrid.ActivityGridRow(_row);
        }

        public void SetFilters(OmsTradeTransaction transaction)
        {
            SetFromDate(transaction.EffectiveDate);
            SelectTransactionType(transaction.TradeType);
            SelectStatus(transaction.Status);
        }

        public bool FindTransaction(OmsTradeTransaction transaction)
        {
            //SetFilters(transaction);
            return GetRowByTransaction(transaction) != null;
        }
        public TradeHistoryPage ShowHistory(OmsTradeTransaction transaction)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            GetRowByTransaction(transaction).LnkHistory.MouseClick();
            var browser = BrowserPool.IePopupOpen(PageUrl.TRADE_HISTORY_REPORT, TradeHistoryPage.TITLE);
            return new TradeHistoryPage(Manager.Current.ActiveBrowser.Find, browser);
        }

        public bool FindTransactionInHistory(OmsTradeTransaction gridTransaction, OmsTradeTransaction historyTransaction)
        {
            var tradeHistory = ShowHistory(gridTransaction);
            var doesTransExistInHistory = tradeHistory.FindTransaction(historyTransaction);
            tradeHistory.ClosePopup();
            return doesTransExistInHistory;
        }

        public bool AreAllTransactionsInHistory(OmsTradeTransaction gridTransaction, 
            List<OmsTradeTransaction> historyTransactions)
        {
            var tradeHistory = ShowHistory(gridTransaction);
            var doTransExistInHistory = true;
            foreach (var omsTradeTransaction in historyTransactions)
            {
                if (!tradeHistory.DoesTransactionExist(omsTradeTransaction)) doTransExistInHistory = false;
            }
            tradeHistory.ClosePopup();
            return doTransExistInHistory;
        }

        public TradeSubscriptionPage OpenTransaction(OmsTradeTransaction transaction)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            GetRowByTransaction(transaction).LnkDate.MouseClick();
            Manager.Current.ActiveBrowser.RefreshDomTree();
            return PopupWaiter.WaitTransactionPageAndGetInstance
                (TransactionType.TRADE_ORDER_SUBSCRIPTION) as TradeSubscriptionPage;
        }


        private void InvokeDelete(OmsTradeTransaction transaction)
        {
            //SetFilters(transaction);
            Manager.Current.ActiveBrowser.RefreshDomTree();
            GetRowByTransaction(transaction).LnkDelete.MouseClick();
        }
        public void DeleteTransaction(OmsTradeTransaction transaction)
        {
            InvokeDelete(transaction);
            CommentDelete.Text = transaction.Comment = "deleted";
            transaction.SetOmsTransaction(OmsTradeTransaction.State.DELETED, OmsTradeTransaction.Action.APPROVED_ACTION);
            DeleteButton.ButtonClick();
        }

        public void AddCommentAfterEdit()
        {
            CommentEdit.Text = "edited";
            EditButton.ButtonClick();
        }
        public bool AreTransactionsAbsent()
        {
            return (TradeActGrid.Rows.Count == 1);
        }

        public void DeleteAllTransactions()
        {
            var downArray = TradeActGrid.Rows.ToArray();
            for (int i = downArray.Length-1; i >= 0; i--)
            {
                Manager.Current.ActiveBrowser.RefreshDomTree();
                if (downArray[i].LnkDelete != null)
                {
                    downArray[i].LnkDelete.MouseClick();
                    BrowserPool.WaitUntilPageLoaded();
                    Manager.Current.ActiveBrowser.RefreshDomTree();
                    CommentDelete.Text = "deleted";
                    DeleteButton.ButtonClick();
                }

            }
        }

        public string ApproveTransactionErrorHandle(ref OmsTradeTransaction transaction)
        {
            CheckApprove(transaction);
            ApproveButton.ButtonClick();
            CommentApprove.Text = transaction.Comment = "approved";
            var alertText = ApproveRejectCommentButton.ClickAlertHandle();
            BrowserPool.WaitUntilPageLoaded();
            return alertText;
        }

        public void ApproveTransaction(ref OmsTradeTransaction transaction)
        {
            CheckApprove(transaction);
            ApproveButton.ButtonClick();
            CommentApprove.Text = transaction.Comment = "approved";
            transaction.SetOmsTransaction(OmsTradeTransaction.State.BOOKED, OmsTradeTransaction.Action.APPROVED_ACTION);
            ApproveRejectCommentButton.ButtonClick();
            BrowserPool.WaitUntilPageLoaded();
        }

        public void CheckApprove(OmsTradeTransaction transaction)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            GetRowByTransaction(transaction).Approve.Check(true, true);
        }

        public void CheckReject(OmsTradeTransaction transaction)
        {
            Manager.Current.ActiveBrowser.RefreshDomTree();
            GetRowByTransaction(transaction).Reject.Check(true, true);
        }

        public void RejectTransaction(ref OmsTradeTransaction transaction)
        {
            CheckReject(transaction);
            ApproveButton.ButtonClick();
            CommentApprove.Text = transaction.Comment = "Rejected";
            //transaction.SetOmsTransaction(OmsTradeTransaction.State.REJECTED, OmsTradeTransaction.Action.R);
            ApproveRejectCommentButton.ButtonClick();
        }

        #endregion
    }

    public class TradeActivityGrid
    {
        private List<ActivityGridRow> _rows;

        public List<ActivityGridRow> Rows
        {
            get { return _rows ?? (_rows = new List<ActivityGridRow>()); }
        }

        public TradeActivityGrid(HtmlTable table)
        {
            if (table.Rows.Count <= 1)
                return;

            for (int i = 1; i < table.Rows.Count; i++)
            {
                var row = table.Rows[i];
                var newRow = new ActivityGridRow(row);
                Rows.Add(newRow);
            }
        }

        public class ActivityGridRow
        {
            private readonly HtmlTableRow _row;
            private const string APPROVE_CHK_ID = "~chkApprove";
            private const string REJECT_CHK_ID = "~chkReject";
            private const string FORCE_RUN_ID = "~lnkAdminUsage";
            private const string DELETE_ID = "~lnkDelete";
            private const string HISTORY_ID = "~lnkHistory";

            public ActivityGridRow(HtmlTableRow row)
            {
                _row = row;
            }

            public HtmlAnchor LnkDate
            { get { return _row.Cells[0].ChildNodes[0].As<HtmlAnchor>(); } }

            public string Security
            {
                get { return _row.Cells[1].InnerText; }
            }

            public string TransactionType
            {
                get { return _row.Cells[2].InnerText; }
            }

            public string Portfolio
            {
                get { return _row.Cells[3].InnerText; }
            }

            public string Amount
            {
                get { return _row.Cells[4].InnerText; }
            }

            public string Quantity
            {
                get { return _row.Cells[5].InnerText; }
            }

            public string Percentage
            {
                get { return _row.Cells[6].InnerText; }
            }

            public string CurrentState
            {
                get { return _row.Cells[7].InnerText; }
            }

            public string EnteredBy
            {
                get { return _row.Cells[8].InnerText; }
            }

            public HtmlAnchor LnkDelete
            {
                get { return _row.Find.ById<HtmlAnchor>(DELETE_ID); }
            }

            public HtmlAnchor LnkHistory
            {
                get
                {
                    return _row.Find.ById(HISTORY_ID).As<HtmlAnchor>();
                }
            }
            public string ApprovalLevel
            {
                get { return _row.Cells[11].InnerText; }
            }
            public HtmlInputCheckBox Approve
            {
                get { return _row.Find.ById(APPROVE_CHK_ID).As<HtmlInputCheckBox>(); }
            }
            public HtmlInputCheckBox Reject
            {
                get { return _row.Find.ById(REJECT_CHK_ID).As<HtmlInputCheckBox>(); }
            }
            public HtmlAnchor ForceRun
            {
                get { return _row.Find.ById(FORCE_RUN_ID).As<HtmlAnchor>(); }
            }
        }
    }
}
